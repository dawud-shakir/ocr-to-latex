#!/usr/bin/env python3
# Scene Text Recognition Model Hub
# Copyright 2022 Darwin Bautista
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
import math
from pathlib import Path

import hydra
from hydra.core.hydra_config import HydraConfig
from omegaconf import DictConfig, open_dict

import torch

from pytorch_lightning import Trainer
# SWA is intentionally not imported by default for this custom handwriting fine-tuning script.
# To disable SWA, comment this import:
from pytorch_lightning.callbacks import ModelCheckpoint, StochasticWeightAveraging
from pytorch_lightning.loggers import TensorBoardLogger
from pytorch_lightning.strategies import DDPStrategy
from pytorch_lightning.utilities.model_summary import summarize

from strhub.data.module import SceneTextDataModule
from strhub.models.base import BaseSystem
from strhub.models.utils import get_pretrained_weights


# Copied from OneCycleLR
def _annealing_cos(start, end, pct):
    'Cosine anneal from `start` to `end` as pct goes from 0.0 to 1.0.'
    cos_out = math.cos(math.pi * pct) + 1
    return end + (start - end) / 2.0 * cos_out


def get_swa_lr_factor(warmup_pct, swa_epoch_start, div_factor=25, final_div_factor=1e4) -> float:
    """Get the SWA LR factor for the given `swa_epoch_start`. Assumes OneCycleLR Scheduler."""
    total_steps = 1000  # Can be anything. We use 1000 for convenience.
    start_step = int(total_steps * warmup_pct) - 1
    end_step = total_steps - 1
    step_num = int(total_steps * swa_epoch_start) - 1
    pct = (step_num - start_step) / (end_step - start_step)
    return _annealing_cos(1, 1 / (div_factor * final_div_factor), pct)


@hydra.main(config_path='configs', config_name='main', version_base='1.2')
def main(config: DictConfig):
    trainer_strategy = 'auto'
    train_without_val = bool(config.get('train_without_val', False))

    with open_dict(config):
        # Resolve absolute path to data.root_dir
        config.data.root_dir = hydra.utils.to_absolute_path(config.data.root_dir)

        # Optional train-only mode. This is useful for quick experiments or a final
        # train-on-everything run where root_dir/val is intentionally absent.
        # Normal behavior is unchanged when train_without_val is false.
        config.data.allow_missing_val = bool(config.data.get('allow_missing_val', False) or train_without_val)
        if train_without_val:
            config.trainer.limit_val_batches = 0
            config.trainer.num_sanity_val_steps = 0

        # Special handling for GPU-affected config
        gpu = config.trainer.get('accelerator') == 'gpu'
        devices = config.trainer.get('devices', 0)
        if gpu:
            # Use mixed-precision training
            config.trainer.precision = 'bf16-mixed' if torch.get_autocast_gpu_dtype() is torch.bfloat16 else '16-mixed'
        if gpu and devices > 1:
            # Use DDP with optimizations
            trainer_strategy = DDPStrategy(find_unused_parameters=False, gradient_as_bucket_view=True)
            # Scale steps-based config
            if not train_without_val and config.trainer.get('val_check_interval') is not None:
                config.trainer.val_check_interval //= devices
            if config.trainer.get('max_steps', -1) > 0:
                config.trainer.max_steps //= devices

    # Special handling for PARseq
    if config.model.get('perm_mirrored', False):
        assert config.model.perm_num % 2 == 0, 'perm_num should be even if perm_mirrored = True'

    model: BaseSystem = hydra.utils.instantiate(config.model)
    # If specified, use pretrained weights to initialize the model
    if config.pretrained is not None:
        m = model.model if config.model._target_.endswith('PARSeq') else model

        # The pretrained PARSeq checkpoint was trained with its original charset.
        # For handwriting fine-tuning, we may use a custom charset containing spaces,
        # math symbols, Greek letters, etc. Changing the charset changes the shape of
        # charset-dependent layers such as:
        #
        #   - head.weight / head.bias
        #   - text_embed.embedding.weight
        #
        # A strict load_state_dict() would fail on those shape mismatches. Instead,
        # load only the pretrained tensors whose names and shapes still match the
        # current model. This keeps the useful pretrained encoder/decoder weights,
        # while leaving the resized charset-specific layers randomly initialized so
        # they can learn the custom handwriting symbols during fine-tuning. 
        # (dawud, 2026-05-17)

        # m.load_state_dict(get_pretrained_weights(config.pretrained))
        pretrained = get_pretrained_weights(config.pretrained)
        current = m.state_dict()

        compatible = {
            k: v for k, v in pretrained.items()
            if k in current and v.shape == current[k].shape
        }

        skipped = [
            k for k, v in pretrained.items()
            if k in current and v.shape != current[k].shape
        ]

        print("Skipped pretrained layers due to shape mismatch:", skipped)

        m.load_state_dict(compatible, strict=False)

    print(summarize(model, max_depth=2))

    datamodule: SceneTextDataModule = hydra.utils.instantiate(config.data)

    if train_without_val:
        # Train-only mode: validation metrics will not exist, so checkpoint by
        # epoch-aggregated training loss instead of val_NED.
        checkpoint = ModelCheckpoint(
            monitor='train_loss',
            mode='min',
            save_top_k=3,
            save_last=True,
            save_on_train_epoch_end=True,
            filename='{epoch}-{step}-{train_loss:.4f}',
        )
        if trainer_strategy == 'auto':
            print(
                "Training without validation: checkpointing by train_loss. "
                "No val_accuracy/val_NED metrics will be logged.",
                flush=True,
            )
    else:
        # Select checkpoints by validation NED instead of exact-match accuracy. (dawud 2026-05-19)
        checkpoint = ModelCheckpoint(
            monitor='val_NED',
            mode='max',
            save_top_k=3,
            save_last=True,
            filename='{epoch}-{step}-{val_accuracy:.4f}-{val_NED:.4f}',
        )
    # checkpoint = ModelCheckpoint(
    #     monitor='val_accuracy',
    #     mode='max',
    #     save_top_k=3,
    #     save_last=True,
    #     filename='{epoch}-{step}-{val_accuracy:.4f}-{val_NED:.4f}',
    # )


    # SWA / Stochastic Weight Averaging note:
    #
    # SWA can be useful because it averages model weights from the late part of training.
    # On many larger or more stable datasets, that averaging can land the model in a smoother
    # region of the loss surface and improve generalization compared with one noisy final
    # checkpoint.
    #
    # For this small custom handwriting/PARSeq fine-tuning setup, SWA is disabled for now.
    # The validation logs showed the model often reached its best recognition metrics before
    # the SWA phase, then became noisier or worse after Lightning swapped OneCycleLR for SWALR.
    # With a small validation set and charset-dependent output layers being trained from
    # scratch, the averaged late weights can smooth away a good specialized checkpoint rather
    # than improve it.
    #
    # To enable SWA, uncomment the three lines below, restore the import above, and
    # change callbacks=[checkpoint] to callbacks=[checkpoint, swa].  (dawud, 2026-05-19)
    #
    swa_epoch_start = 0.75
    swa_lr = config.model.lr * get_swa_lr_factor(config.model.warmup_pct, swa_epoch_start)
    swa = StochasticWeightAveraging(swa_lr, swa_epoch_start)
    cwd = (
        HydraConfig.get().runtime.output_dir
        if config.ckpt_path is None
        else str(Path(config.ckpt_path).parents[1].absolute())
    )
    trainer: Trainer = hydra.utils.instantiate(
        config.trainer,
        logger=TensorBoardLogger(cwd, '', '.'),
        strategy=trainer_strategy,
        enable_model_summary=False,
        callbacks=[checkpoint, swa],
        # If SWA is disabled above, use this instead:
        # callbacks=[checkpoint],
        
    )
    trainer.fit(model, datamodule=datamodule, ckpt_path=config.ckpt_path)


if __name__ == '__main__':
    main()
