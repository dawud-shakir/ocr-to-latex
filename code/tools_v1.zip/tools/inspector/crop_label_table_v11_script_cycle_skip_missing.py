#!/usr/bin/env python3
"""Table/editor support for inspect_crops_craft_curator.

This module keeps the crop label table, label editor delegate, and table
navigation/update behavior separate from the main image/CRAFT/PARSeq window.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from PyQt6.QtCore import QObject, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QAction, QColor, QKeyEvent
from PyQt6.QtWidgets import (
    QAbstractItemView,
    QApplication,
    QCheckBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QPushButton,
    QStyledItemDelegate,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


def _clamp_int(value: int, lo: int, hi: int) -> int:
    return max(lo, min(hi, value))


# Unicode characters that have practical subscript/superscript equivalents.
# Characters without a Unicode equivalent are left unchanged, so selections like
# "A1" can still become "A₁" on the subscript pass and "ᴬ¹" on the superscript
# pass. Pressing Cmd/Ctrl++ repeatedly while the transformed text stays selected
# cycles: normal-ish -> subscript-ish -> superscript-ish -> normal.
NORMAL_TO_SUBSCRIPT = {
    "0": "₀", "1": "₁", "2": "₂", "3": "₃", "4": "₄",
    "5": "₅", "6": "₆", "7": "₇", "8": "₈", "9": "₉",
    "+": "₊", "-": "₋", "=": "₌", "(": "₍", ")": "₎",
    ",": "‚", ".": "．",
    "a": "ₐ", "e": "ₑ", "o": "ₒ", "x": "ₓ",
    "ə": "ₔ", "h": "ₕ", "i": "ᵢ", "j": "ⱼ", "k": "ₖ",
    "l": "ₗ", "m": "ₘ", "n": "ₙ", "p": "ₚ", "r": "ᵣ",
    "s": "ₛ", "t": "ₜ", "u": "ᵤ", "v": "ᵥ",
    # Unicode only has practical subscript forms for a few Greek letters.
    "β": "ᵦ", "ρ": "ᵨ", "φ": "ᵩ", "χ": "ᵪ",
}

NORMAL_TO_SUPERSCRIPT = {
    "0": "⁰", "1": "¹", "2": "²", "3": "³", "4": "⁴",
    "5": "⁵", "6": "⁶", "7": "⁷", "8": "⁸", "9": "⁹",
    "+": "⁺", "-": "⁻", "=": "⁼", "(": "⁽", ")": "⁾",
    "A": "ᴬ", "B": "ᴮ", "D": "ᴰ", "E": "ᴱ", "G": "ᴳ",
    "H": "ᴴ", "I": "ᴵ", "J": "ᴶ", "K": "ᴷ", "L": "ᴸ",
    "M": "ᴹ", "N": "ᴺ", "O": "ᴼ", "P": "ᴾ", "R": "ᴿ",
    "T": "ᵀ", "U": "ᵁ", "V": "ⱽ", "W": "ᵂ",
    "a": "ᵃ", "b": "ᵇ", "c": "ᶜ", "d": "ᵈ", "e": "ᵉ",
    "f": "ᶠ", "g": "ᵍ", "h": "ʰ", "i": "ⁱ", "j": "ʲ",
    "k": "ᵏ", "l": "ˡ", "m": "ᵐ", "n": "ⁿ", "o": "ᵒ",
    "p": "ᵖ", "r": "ʳ", "s": "ˢ", "t": "ᵗ", "u": "ᵘ",
    "v": "ᵛ", "w": "ʷ", "x": "ˣ", "y": "ʸ", "z": "ᶻ",
    # Unicode has superscript/modifier forms for several lowercase Greek letters.
    "α": "ᵅ", "β": "ᵝ", "γ": "ᵞ", "δ": "ᵟ", "ε": "ᵋ",
    "θ": "ᶿ", "ι": "ᶥ", "φ": "ᵠ", "χ": "ᵡ",
}

SUBSCRIPT_TO_NORMAL = {v: k for k, v in NORMAL_TO_SUBSCRIPT.items()}
SUPERSCRIPT_TO_NORMAL = {v: k for k, v in NORMAL_TO_SUPERSCRIPT.items()}
SCRIPT_NEUTRAL_CHARS = set(" \t_{}[]|/\\:;<>→←↑↓⇒↔∅∈∉⊆⊂∪∩∀∃ΣΓΔΛΠΩηκμνξοπρσςτυψωϑ≤≥≠≡∧∨¬⊢⊨⊥±×÷√°·…⋅•⇓")


def _normalize_script_text(text: str) -> str:
    """Convert known subscript/superscript characters back to normal text."""
    chars: list[str] = []
    for ch in text:
        chars.append(SUBSCRIPT_TO_NORMAL.get(ch, SUPERSCRIPT_TO_NORMAL.get(ch, ch)))
    return "".join(chars)


def _script_selection_state(text: str) -> str:
    """Return 'subscript', 'superscript', or 'normal' for the selected text."""
    has_sub = False
    has_sup = False
    has_normal_convertible = False

    for ch in text:
        if ch in SUBSCRIPT_TO_NORMAL:
            has_sub = True
        elif ch in SUPERSCRIPT_TO_NORMAL:
            has_sup = True
        elif ch in NORMAL_TO_SUBSCRIPT or ch in NORMAL_TO_SUPERSCRIPT:
            has_normal_convertible = True
        elif ch in SCRIPT_NEUTRAL_CHARS:
            continue
        else:
            # Unsupported characters are neutral for detection. They will be
            # preserved during conversion rather than preventing a useful cycle.
            continue

    # Treat mixed normal+subscript text like "x₁" as subscript-ish so the
    # next press advances to superscript instead of trying to re-subscript it.
    # Same idea for mixed normal+superscript text like "x¹".
    if has_sub and not has_sup:
        return "subscript"
    if has_sup and not has_sub:
        return "superscript"
    return "normal"


def _convert_script_text(text: str, target: str) -> str:
    """Convert selected text to the requested script style when Unicode exists."""
    normal = _normalize_script_text(text)
    if target == "normal":
        return normal
    if target == "subscript":
        return "".join(NORMAL_TO_SUBSCRIPT.get(ch, ch) for ch in normal)
    if target == "superscript":
        return "".join(NORMAL_TO_SUPERSCRIPT.get(ch, ch) for ch in normal)
    return text


def _script_conversion_matches_target(converted: str, target: str) -> bool:
    """Return True when conversion actually reached the requested script style."""
    if target == "normal":
        return _script_selection_state(converted) == "normal"
    return _script_selection_state(converted) == target


def _next_script_conversion(text: str) -> tuple[Optional[str], str]:
    """Return the next usable script-cycle target and converted text.

    The cycle is normal -> subscript -> superscript -> normal, but unavailable
    styles are skipped. For example, selected "A" skips subscript because there
    is no Unicode subscript A and goes directly to superscript "ᴬ". Selected
    "ₔ" skips superscript because there is no Unicode superscript schwa and
    goes directly back to normal "ə".
    """
    state = _script_selection_state(text)
    if state == "subscript":
        targets = ["superscript", "normal"]
    elif state == "superscript":
        targets = ["normal"]
    else:
        targets = ["subscript", "superscript"]

    for target in targets:
        converted = _convert_script_text(text, target)
        if converted != text and _script_conversion_matches_target(converted, target):
            return target, converted
    return None, text


class LabelLineEdit(QLineEdit):
    """Single-line label editor used by the crop table delegate."""

    commitMoveRequested = pyqtSignal(int)  # 0 = stay, -1 = previous row, 1 = next row
    toggleKeepRequested = pyqtSignal()
    symbolPopupRequested = pyqtSignal(object)  # editor requesting SymbolPopup
    shortcutRequested = pyqtSignal(str)  # undo/redo/find shortcuts while editor has focus
    scriptCycleApplied = pyqtSignal(object)  # editor text changed by Cmd/Ctrl++ script cycle

    @staticmethod
    def is_cmd_i(event: QKeyEvent) -> bool:
        # On macOS, Qt often reports Command as ControlModifier. Keep Meta as
        # a fallback for other Qt/platform combinations.
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_I
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        )

    @staticmethod
    def is_cmd_v(event: QKeyEvent) -> bool:
        # On macOS, Qt often reports Command as ControlModifier. Keep Meta as
        # a fallback for other Qt/platform combinations.
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_V
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        )

    @staticmethod
    def is_cmd_s(event: QKeyEvent) -> bool:
        # On macOS, Qt often reports Command as ControlModifier. Keep Meta as
        # a fallback for other Qt/platform combinations.
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_S
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
        )


    @staticmethod
    def is_cmd_z(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_Z
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    @staticmethod
    def is_cmd_y(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_Y
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    @staticmethod
    def is_cmd_f(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_F
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    @staticmethod
    def is_cmd_h(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_H
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    @staticmethod
    def is_cmd_g(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_G
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    @staticmethod
    def is_cmd_o(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() == Qt.Key.Key_O
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & (Qt.KeyboardModifier.AltModifier | Qt.KeyboardModifier.ShiftModifier))
        )

    @staticmethod
    def is_cmd_plus(event: QKeyEvent) -> bool:
        mods = event.modifiers()
        return (
            event.key() in (Qt.Key.Key_Plus, Qt.Key.Key_Equal)
            and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
            and not bool(mods & Qt.KeyboardModifier.AltModifier)
        )

    def cycle_selected_script(self) -> bool:
        """Cycle selected text: normal -> subscript -> superscript -> normal.

        Returns True when Cmd/Ctrl++ was handled as a script conversion. If no
        text is selected, callers should let QLineEdit keep its normal Select
        All behavior.
        """
        if not self.hasSelectedText():
            return False

        start = self.selectionStart()
        selected = self.selectedText()
        if start < 0 or not selected:
            return False

        target, converted = _next_script_conversion(selected)
        if target is None:
            QApplication.beep()
            return True

        text = self.text()
        self.setText(text[:start] + converted + text[start + len(selected):])
        self.setSelection(start, len(converted))
        self.scriptCycleApplied.emit(self)
        return True

    def keyPressEvent(self, event: QKeyEvent) -> None:
        key = event.key()
        if self.is_cmd_plus(event) and self.cycle_selected_script():
            event.accept()
            return
        if self.is_cmd_z(event):
            self.shortcutRequested.emit("redo" if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else "undo")
            event.accept()
            return
        if self.is_cmd_y(event):
            self.shortcutRequested.emit("redo")
            event.accept()
            return
        if self.is_cmd_f(event):
            self.shortcutRequested.emit("find")
            event.accept()
            return
        if self.is_cmd_g(event):
            self.shortcutRequested.emit("find_previous" if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else "find_next")
            event.accept()
            return
        if self.is_cmd_h(event):
            self.shortcutRequested.emit("replace")
            event.accept()
            return
        if self.is_cmd_v(event):
            # Explicitly handle paste in the delegate editor. This keeps Cmd+V
            # working even on Qt/macOS builds where Command is reported as
            # ControlModifier instead of the platform paste shortcut.
            self.paste()
            event.accept()
            return
        if self.is_cmd_i(event):
            self.symbolPopupRequested.emit(self)
            event.accept()
            return
        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
            self.commitMoveRequested.emit(0)
            event.accept()
            return
        if key == Qt.Key.Key_Up:
            self.commitMoveRequested.emit(-1)
            event.accept()
            return
        if key == Qt.Key.Key_Down:
            self.commitMoveRequested.emit(1)
            event.accept()
            return
        if key == Qt.Key.Key_Delete:
            self.toggleKeepRequested.emit()
            event.accept()
            return
        super().keyPressEvent(event)


class LabelDelegate(QStyledItemDelegate):
    """Delegate that supports fast label entry and row-to-row navigation."""

    commitMove = pyqtSignal(int, int)  # row, direction
    toggleKeep = pyqtSignal(int)  # row
    symbolPopupRequested = pyqtSignal(object)  # active LabelLineEdit
    shortcutRequested = pyqtSignal(str)  # undo/redo/find shortcuts from an active editor

    def createEditor(self, parent, option, index):  # type: ignore[override]
        editor = LabelLineEdit(parent)
        editor.setProperty("row", index.row())
        editor.commitMoveRequested.connect(lambda direction, ed=editor: self._commit_from_editor(ed, direction))
        editor.toggleKeepRequested.connect(lambda ed=editor: self._toggle_keep_from_editor(ed))
        editor.symbolPopupRequested.connect(self.symbolPopupRequested.emit)
        editor.shortcutRequested.connect(lambda action, ed=editor: self._shortcut_from_editor(ed, action))
        editor.scriptCycleApplied.connect(lambda _editor_obj, ed=editor: self._script_cycle_from_editor(ed))
        return editor

    def _commit_from_editor(self, editor: LabelLineEdit, direction: int) -> None:
        row = int(editor.property("row"))
        self.commitData.emit(editor)
        self.closeEditor.emit(editor, QStyledItemDelegate.EndEditHint.NoHint)
        self.commitMove.emit(row, direction)

    def _toggle_keep_from_editor(self, editor: LabelLineEdit) -> None:
        row = int(editor.property("row"))
        self.commitData.emit(editor)
        self.toggleKeep.emit(row)

    def _shortcut_from_editor(self, editor: LabelLineEdit, action: str) -> None:
        # Commit the in-progress edit first so app-level undo/redo operates on
        # the table history instead of being swallowed by QLineEdit's internal
        # edit stack. Closing the editor also keeps the visible cell in sync.
        self.commitData.emit(editor)
        self.closeEditor.emit(editor, QStyledItemDelegate.EndEditHint.NoHint)
        self.shortcutRequested.emit(str(action))

    def _script_cycle_from_editor(self, editor: LabelLineEdit) -> None:
        # Keep the table item/crop record synchronized immediately while the
        # editor stays open. Do not close/recreate the delegate editor here:
        # doing so steals focus and collapses the selected range to the end of
        # the line after Cmd/Ctrl++. Updating the table item directly still
        # routes through the controller's itemChanged handler, so the crop
        # record, undo stack, thumbnails, and dirty/export state stay in sync.
        try:
            row = int(editor.property("row"))
        except Exception:
            row = -1

        start = editor.selectionStart()
        length = len(editor.selectedText()) if start >= 0 else 0
        new_text = editor.text()

        table = self.parent()
        if isinstance(table, QTableWidget) and row >= 0:
            item = table.item(row, 2)
            if item is not None and item.text() != new_text:
                item.setText(new_text)
        else:
            self.commitData.emit(editor)

        def restore_selection() -> None:
            try:
                if start >= 0 and editor.isVisible():
                    editor.setFocus(Qt.FocusReason.ShortcutFocusReason)
                    editor.setSelection(start, length)
            except RuntimeError:
                pass

        # Restore both immediately and after Qt finishes processing the item
        # update. The zero-delay pass handles platforms where QTableWidget
        # briefly refreshes focus/selection after itemChanged.
        restore_selection()
        QTimer.singleShot(0, restore_selection)


@dataclass
class TableChange:
    row: int
    old_label: Optional[str] = None
    new_label: Optional[str] = None
    old_keep: Optional[bool] = None
    new_keep: Optional[bool] = None


@dataclass
class TableEditAction:
    description: str
    changes: list[TableChange]


class CropTableController(QObject):
    """Owns the crop table widget and all direct table/delegate behavior.

    The main window remains the source of truth for `crops`, selection, image
    refreshes, and the symbol popup. This controller only handles table rows,
    label editing, keep checkboxes, and keyboard-friendly table navigation.
    """

    def __init__(self, owner: Any) -> None:
        super().__init__(owner)
        self.owner = owner
        self.table: Optional[QTableWidget] = None
        self.label_delegate: Optional[LabelDelegate] = None
        self.find_edit: Optional[QLineEdit] = None
        self.replace_edit: Optional[QLineEdit] = None
        self.match_case_checkbox: Optional[QCheckBox] = None
        self.find_status_label: Optional[QLabel] = None
        self.undo_btn: Optional[QPushButton] = None
        self.redo_btn: Optional[QPushButton] = None
        self.undo_action: Optional[QAction] = None
        self.redo_action: Optional[QAction] = None
        self.undo_stack: list[TableEditAction] = []
        self.redo_stack: list[TableEditAction] = []
        self._applying_history = False
        self._history_limit = 200
        self._last_find_needle = ""
        self._last_find_match_case = False
        self._last_find_row: Optional[int] = None
        self._last_find_pos: Optional[int] = None

    def create_find_replace_bar(self, parent: Any) -> QWidget:
        """Create a compact table toolbar for undo/redo and label find/replace."""
        bar = QWidget(parent)
        outer = QVBoxLayout(bar)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(3)

        row1 = QHBoxLayout()
        row1.setContentsMargins(0, 0, 0, 0)
        row1.setSpacing(4)
        row2 = QHBoxLayout()
        row2.setContentsMargins(0, 0, 0, 0)
        row2.setSpacing(4)
        outer.addLayout(row1)
        outer.addLayout(row2)

        self.undo_btn = QPushButton("Undo")
        self.undo_btn.setToolTip("Undo the last table label/keep edit (Cmd/Ctrl+Z)")
        self.redo_btn = QPushButton("Redo")
        self.redo_btn.setToolTip("Redo the last undone table edit (Cmd/Ctrl+Y or Cmd/Ctrl+Shift+Z)")
        self.undo_btn.clicked.connect(self.undo)
        self.redo_btn.clicked.connect(self.redo)

        self.find_edit = QLineEdit()
        self.find_edit.setPlaceholderText("Find label…")
        self.find_edit.setClearButtonEnabled(True)
        self.find_edit.setMaximumWidth(180)
        self.find_edit.returnPressed.connect(self.find_next)

        self.replace_edit = QLineEdit()
        self.replace_edit.setPlaceholderText("Replace…")
        self.replace_edit.setClearButtonEnabled(True)
        self.replace_edit.setMaximumWidth(180)
        self.replace_edit.returnPressed.connect(self.replace_current)

        prev_btn = QPushButton("Prev")
        next_btn = QPushButton("Next")
        replace_btn = QPushButton("Replace")
        replace_all_btn = QPushButton("All")
        prev_btn.setToolTip("Find previous matching label")
        next_btn.setToolTip("Find next matching label")
        replace_btn.setToolTip("Replace one match in the selected/current matching label")
        replace_all_btn.setToolTip("Replace all matches in table labels")
        prev_btn.clicked.connect(self.find_previous)
        next_btn.clicked.connect(self.find_next)
        replace_btn.clicked.connect(self.replace_current)
        replace_all_btn.clicked.connect(self.replace_all)

        self.match_case_checkbox = QCheckBox("Case")
        self.match_case_checkbox.setToolTip("Match case while finding/replacing")
        self.find_status_label = QLabel("")
        self.find_status_label.setMinimumWidth(90)
        self.find_status_label.setStyleSheet("QLabel { color: #555; }")

        row1.addWidget(self.undo_btn)
        row1.addWidget(self.redo_btn)
        row1.addSpacing(8)
        row1.addWidget(QLabel("Find"))
        row1.addWidget(self.find_edit, 1)
        row1.addWidget(prev_btn)
        row1.addWidget(next_btn)
        row1.addWidget(self.match_case_checkbox)

        row2.addWidget(QLabel("Replace"))
        row2.addWidget(self.replace_edit, 1)
        row2.addWidget(replace_btn)
        row2.addWidget(replace_all_btn)
        row2.addWidget(self.find_status_label)
        row2.addStretch(1)

        self._update_history_buttons()
        return bar

    def create_table(self, parent: Any) -> QTableWidget:
        table = QTableWidget(0, 3, parent)
        table.setHorizontalHeaderLabels(["index", "keep", "label"])
        table.verticalHeader().setVisible(False)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setEditTriggers(
            QAbstractItemView.EditTrigger.DoubleClicked
            | QAbstractItemView.EditTrigger.SelectedClicked
            | QAbstractItemView.EditTrigger.EditKeyPressed
        )
        table.setAlternatingRowColors(False)
        table.setStyleSheet(
            "QTableWidget { background: white; color: #111; gridline-color: #bbb; }"
            "QTableWidget::item:selected { background-color: #e6e6e6; color: #111; }"
        )
        header = table.horizontalHeader()
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        table.setMinimumHeight(260)

        delegate = LabelDelegate(table)
        table.setItemDelegateForColumn(2, delegate)
        delegate.commitMove.connect(self.on_label_delegate_commit_move)
        delegate.toggleKeep.connect(self.on_label_delegate_toggle_keep)
        delegate.symbolPopupRequested.connect(self.owner.show_symbol_popup_for_editor)
        delegate.shortcutRequested.connect(self.handle_shortcut_action)
        table.itemChanged.connect(self.on_table_item_changed)
        table.currentCellChanged.connect(self.on_table_current_cell_changed)

        self.table = table
        self.label_delegate = delegate
        return table

    def _table(self) -> QTableWidget:
        if self.table is None:
            raise RuntimeError("Crop table has not been created yet")
        return self.table

    def clear_history(self) -> None:
        self.undo_stack.clear()
        self.redo_stack.clear()
        self._update_history_buttons()

    def _update_history_buttons(self) -> None:
        can_undo = bool(self.undo_stack)
        can_redo = bool(self.redo_stack)
        if self.undo_btn is not None:
            self.undo_btn.setEnabled(can_undo)
        if self.redo_btn is not None:
            self.redo_btn.setEnabled(can_redo)
        if self.undo_action is not None:
            self.undo_action.setEnabled(can_undo)
        if self.redo_action is not None:
            self.redo_action.setEnabled(can_redo)

    def set_history_actions(self, undo_action: QAction, redo_action: QAction) -> None:
        self.undo_action = undo_action
        self.redo_action = redo_action
        self._update_history_buttons()

    def _push_action(self, action: TableEditAction) -> None:
        if self._applying_history or self.owner._updating_ui:
            return
        action.changes = [change for change in action.changes if self._change_is_meaningful(change)]
        if not action.changes:
            return
        self.undo_stack.append(action)
        if len(self.undo_stack) > self._history_limit:
            self.undo_stack = self.undo_stack[-self._history_limit:]
        self.redo_stack.clear()
        self._update_history_buttons()

    def _change_is_meaningful(self, change: TableChange) -> bool:
        if change.old_label is not None or change.new_label is not None:
            if str(change.old_label or "") != str(change.new_label or ""):
                return True
        if change.old_keep is not None or change.new_keep is not None:
            if bool(change.old_keep) != bool(change.new_keep):
                return True
        return False

    def _set_find_status(self, text: str) -> None:
        if self.find_status_label is not None:
            self.find_status_label.setText(text)
        try:
            if text:
                self.owner.statusBar().showMessage(text)
        except Exception:
            pass

    def _match_case(self) -> bool:
        return bool(self.match_case_checkbox is not None and self.match_case_checkbox.isChecked())

    def _find_text(self) -> str:
        return self.find_edit.text() if self.find_edit is not None else ""

    def _replace_text(self) -> str:
        return self.replace_edit.text() if self.replace_edit is not None else ""

    def _index_in_label(self, label: str, needle: str) -> int:
        return self._index_in_label_from(label, needle, 0)

    def _index_in_label_from(self, label: str, needle: str, start: int = 0) -> int:
        """Find needle in label at/after start using the current case setting."""
        if not needle:
            return -1
        start = _clamp_int(int(start), 0, len(label))
        if self._match_case():
            return label.find(needle, start)
        return label.lower().find(needle.lower(), start)

    def _rindex_in_label_before(self, label: str, needle: str, end: Optional[int] = None) -> int:
        """Find the last needle in label strictly before end using current case setting."""
        if not needle:
            return -1
        if end is None:
            end = len(label)
        end = _clamp_int(int(end), 0, len(label))
        if self._match_case():
            return label.rfind(needle, 0, end)
        return label.lower().rfind(needle.lower(), 0, end)

    def _replace_first_in_label(self, label: str, needle: str, replacement: str) -> Optional[str]:
        idx = self._index_in_label(label, needle)
        if idx < 0:
            return None
        return label[:idx] + replacement + label[idx + len(needle):]

    def _replace_all_in_label(self, label: str, needle: str, replacement: str) -> str:
        if not needle:
            return label
        if self._match_case():
            return label.replace(needle, replacement)

        # Case-insensitive replace that preserves the replacement text exactly.
        out: list[str] = []
        lower_label = label.lower()
        lower_needle = needle.lower()
        start = 0
        n = len(needle)
        while True:
            idx = lower_label.find(lower_needle, start)
            if idx < 0:
                out.append(label[start:])
                break
            out.append(label[start:idx])
            out.append(replacement)
            start = idx + n
        return "".join(out)

    def _apply_label_to_row(self, row: int, text: str, *, refresh: bool) -> None:
        table = self._table()
        if not (0 <= row < len(self.owner.crops)):
            return
        self.owner.crops[row].label = text
        item = table.item(row, 2)
        self.owner._updating_ui = True
        try:
            if item is not None:
                item.setText(text)
        finally:
            self.owner._updating_ui = False
        if refresh:
            self.owner.refresh_crop_visuals(row)

    def _apply_keep_to_row(self, row: int, keep: bool, *, refresh: bool) -> None:
        table = self._table()
        if not (0 <= row < len(self.owner.crops)):
            return
        self.owner.crops[row].keep = bool(keep)
        item = table.item(row, 1)
        self.owner._updating_ui = True
        try:
            if item is not None:
                item.setCheckState(Qt.CheckState.Checked if keep else Qt.CheckState.Unchecked)
        finally:
            self.owner._updating_ui = False
        if refresh:
            self.owner.refresh_crop_visuals(row)

    def _apply_action(self, action: TableEditAction, *, use_new: bool) -> None:
        self._applying_history = True
        try:
            changed_rows: set[int] = set()
            for change in action.changes:
                row = int(change.row)
                if not (0 <= row < len(self.owner.crops)):
                    continue
                if change.old_label is not None or change.new_label is not None:
                    value = change.new_label if use_new else change.old_label
                    self._apply_label_to_row(row, str(value or ""), refresh=False)
                    changed_rows.add(row)
                if change.old_keep is not None or change.new_keep is not None:
                    value = change.new_keep if use_new else change.old_keep
                    self._apply_keep_to_row(row, bool(value), refresh=False)
                    changed_rows.add(row)

            for row in sorted(changed_rows):
                self.owner.refresh_crop_visuals(row)
            if changed_rows:
                self.owner.select_crop(min(changed_rows), focus=False)
        finally:
            self._applying_history = False

    def populate(self) -> None:
        table = self._table()
        self.owner._updating_ui = True
        try:
            table.setRowCount(len(self.owner.crops))
            for row, crop in enumerate(self.owner.crops):
                index_item = QTableWidgetItem(str(crop.index))
                index_item.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsSelectable)

                keep_item = QTableWidgetItem()
                keep_item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsSelectable
                    | Qt.ItemFlag.ItemIsUserCheckable
                )
                keep_item.setCheckState(Qt.CheckState.Checked if crop.keep else Qt.CheckState.Unchecked)

                label_item = QTableWidgetItem(crop.label)
                label_item.setFlags(
                    Qt.ItemFlag.ItemIsEnabled
                    | Qt.ItemFlag.ItemIsSelectable
                    | Qt.ItemFlag.ItemIsEditable
                )

                table.setItem(row, 0, index_item)
                table.setItem(row, 1, keep_item)
                table.setItem(row, 2, label_item)

            if self.owner.selected_pos is not None and 0 <= self.owner.selected_pos < len(self.owner.crops):
                table.setCurrentCell(self.owner.selected_pos, 2)
            else:
                table.clearSelection()
        finally:
            self.owner._updating_ui = False
        self.clear_history()
        self.refresh_colors()

    def _row_colors(self, row: int) -> tuple[QColor, QColor]:
        if not (0 <= row < len(self.owner.crops)):
            return QColor(255, 255, 255), QColor(20, 20, 20)
        crop = self.owner.crops[row]
        if row == self.owner.selected_pos:
            bg = QColor(230, 230, 230) if crop.keep else QColor(255, 220, 228)
        elif not crop.keep:
            bg = QColor(255, 220, 228)
        else:
            bg = QColor(255, 255, 255)
        return bg, QColor(20, 20, 20)

    def refresh_row_color(self, row: int) -> None:
        table = self._table()
        if not (0 <= row < table.rowCount()):
            return
        bg, fg = self._row_colors(row)
        self.owner._updating_ui = True
        try:
            for col in range(table.columnCount()):
                item = table.item(row, col)
                if item is not None:
                    item.setBackground(bg)
                    item.setForeground(fg)
        finally:
            self.owner._updating_ui = False

    def refresh_colors(self) -> None:
        for row in range(len(self.owner.crops)):
            self.refresh_row_color(row)

    def set_current_cell(self, row: int, column: int = 2) -> None:
        table = self._table()
        self.owner._updating_ui = True
        try:
            table.setCurrentCell(row, column)
        finally:
            self.owner._updating_ui = False

    def set_label_text(
        self,
        row: int,
        text: str,
        *,
        sync_crop: bool = True,
        record_undo: bool = True,
        refresh: bool = False,
    ) -> None:
        if not (0 <= row < len(self.owner.crops)):
            return
        old_text = self.owner.crops[row].label
        new_text = str(text)
        if old_text == new_text:
            return
        if record_undo and sync_crop:
            self._push_action(TableEditAction(
                "Set label",
                [TableChange(row=row, old_label=old_text, new_label=new_text)],
            ))
        if sync_crop:
            self._apply_label_to_row(row, new_text, refresh=refresh)
        else:
            table = self._table()
            item = table.item(row, 2)
            self.owner._updating_ui = True
            try:
                if item is not None:
                    item.setText(new_text)
            finally:
                self.owner._updating_ui = False

    def on_table_current_cell_changed(self, current_row: int, current_col: int, previous_row: int, previous_col: int) -> None:
        if self.owner._updating_ui:
            return
        if 0 <= current_row < len(self.owner.crops):
            self.owner.select_crop(current_row, focus=True)

    def on_table_item_changed(self, item: QTableWidgetItem) -> None:
        if self.owner._updating_ui:
            return
        row = item.row()
        col = item.column()
        if not (0 <= row < len(self.owner.crops)):
            return
        crop = self.owner.crops[row]
        if col == 1:
            old_keep = bool(crop.keep)
            new_keep = item.checkState() == Qt.CheckState.Checked
            if old_keep != new_keep:
                self._push_action(TableEditAction(
                    "Toggle keep",
                    [TableChange(row=row, old_keep=old_keep, new_keep=new_keep)],
                ))
                crop.keep = new_keep
        elif col == 2:
            old_label = crop.label
            new_label = item.text()
            if old_label != new_label:
                self._push_action(TableEditAction(
                    "Edit label",
                    [TableChange(row=row, old_label=old_label, new_label=new_label)],
                ))
                crop.label = new_label
        self.owner.refresh_crop_visuals(row)

    def begin_label_edit(
        self,
        initial_text: Optional[str] = None,
        *,
        select_all: bool = True,
        selection: Optional[tuple[int, int]] = None,
    ) -> None:
        if self.owner.selected_pos is None or not (0 <= self.owner.selected_pos < len(self.owner.crops)):
            return
        table = self._table()
        row = self.owner.selected_pos
        item = table.item(row, 2)
        if item is None:
            return

        table.setFocus(Qt.FocusReason.ShortcutFocusReason)
        table.setCurrentCell(row, 2)

        if initial_text is not None:
            self.set_label_text(row, initial_text, record_undo=True, refresh=True)

        table.editItem(item)

        def adjust_editor() -> None:
            fw = QApplication.focusWidget()
            if isinstance(fw, QLineEdit):
                if selection is not None:
                    start, length = selection
                    start = _clamp_int(int(start), 0, len(fw.text()))
                    length = max(0, min(int(length), len(fw.text()) - start))
                    fw.setFocus(Qt.FocusReason.ShortcutFocusReason)
                    fw.setSelection(start, length)
                elif select_all and initial_text is None:
                    fw.selectAll()
                else:
                    fw.setCursorPosition(len(fw.text()))

        QTimer.singleShot(0, adjust_editor)

    def paste_clipboard_into_selected_label(self) -> None:
        """Paste clipboard text into the selected crop's label cell.

        When a label editor already has focus, LabelLineEdit handles Cmd+V
        directly. This method covers the common curator workflow where a crop is
        selected in the viewer/table/thumbnails but the label cell is not yet in
        edit mode. In that case, paste appends to the selected crop's current
        label and immediately opens the label editor with the cursor at the end.
        """
        if self.owner.selected_pos is None or not (0 <= self.owner.selected_pos < len(self.owner.crops)):
            return
        clipboard = QApplication.clipboard()
        text = clipboard.text() if clipboard is not None else ""
        if text is None:
            text = ""
        # QLineEdit is single-line; keep pasted labels single-line too.
        text = str(text).replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
        current_label = self.owner.crops[self.owner.selected_pos].label
        self.begin_label_edit(initial_text=f"{current_label}{text}", select_all=False)

    def on_label_delegate_commit_move(self, row: int, direction: int) -> None:
        table = self._table()
        if 0 <= row < len(self.owner.crops):
            item = table.item(row, 2)
            if item is not None:
                self.owner.crops[row].label = item.text()
                self.owner.refresh_crop_visuals(row)

        if direction == 0:
            return

        if not self.owner.crops:
            return
        new_row = _clamp_int(row + direction, 0, len(self.owner.crops) - 1)
        self.owner.select_crop(int(new_row), focus=True)
        # Continue label-editing on the next/previous row to support fast labeling.
        QTimer.singleShot(0, lambda: self.begin_label_edit(select_all=True))

    def on_label_delegate_toggle_keep(self, row: int) -> None:
        table = self._table()
        if 0 <= row < len(self.owner.crops):
            self.owner.selected_pos = row
            label_item = table.item(row, 2)
            if label_item is not None:
                self.owner.crops[row].label = label_item.text()
            self.toggle_keep_at_row(row)

    def toggle_keep_at_row(self, row: int) -> None:
        if not (0 <= row < len(self.owner.crops)):
            return
        old_keep = bool(self.owner.crops[row].keep)
        new_keep = not old_keep
        self._push_action(TableEditAction(
            "Toggle keep",
            [TableChange(row=row, old_keep=old_keep, new_keep=new_keep)],
        ))
        self._apply_keep_to_row(row, new_keep, refresh=True)

    def commit_active_label_editor(self) -> bool:
        fw = QApplication.focusWidget()
        if not isinstance(fw, LabelLineEdit):
            return False
        if self.label_delegate is not None:
            self.label_delegate.commitData.emit(fw)
            self.label_delegate.closeEditor.emit(fw, QStyledItemDelegate.EndEditHint.NoHint)
            return True
        return False

    def handle_shortcut_action(self, action: str) -> bool:
        action = str(action)
        if action == "undo":
            self.undo()
            return True
        if action == "redo":
            self.redo()
            return True
        if action == "find":
            self.focus_find()
            return True
        if action == "find_next":
            self.find_next()
            return True
        if action == "find_previous":
            self.find_previous()
            return True
        if action == "replace":
            self.focus_replace()
            return True
        return False

    def undo(self) -> None:
        if not self.undo_stack:
            self._set_find_status("Nothing to undo")
            return
        action = self.undo_stack.pop()
        self._apply_action(action, use_new=False)
        self.redo_stack.append(action)
        self._update_history_buttons()
        self._set_find_status(f"Undid: {action.description}")

    def redo(self) -> None:
        if not self.redo_stack:
            self._set_find_status("Nothing to redo")
            return
        action = self.redo_stack.pop()
        self._apply_action(action, use_new=True)
        self.undo_stack.append(action)
        self._update_history_buttons()
        self._set_find_status(f"Redid: {action.description}")

    def handle_global_key(self, event: QKeyEvent) -> bool:
        if LabelLineEdit.is_cmd_z(event):
            self.commit_active_label_editor()
            return self.handle_shortcut_action("redo" if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else "undo")
        if LabelLineEdit.is_cmd_y(event):
            self.commit_active_label_editor()
            return self.handle_shortcut_action("redo")
        if LabelLineEdit.is_cmd_f(event):
            self.commit_active_label_editor()
            return self.handle_shortcut_action("find")
        if LabelLineEdit.is_cmd_g(event):
            self.commit_active_label_editor()
            return self.handle_shortcut_action("find_previous" if event.modifiers() & Qt.KeyboardModifier.ShiftModifier else "find_next")
        if LabelLineEdit.is_cmd_h(event):
            self.commit_active_label_editor()
            return self.handle_shortcut_action("replace")
        return False

    def focus_find(self) -> None:
        if self.find_edit is None:
            return
        self.find_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self.find_edit.selectAll()
        self._set_find_status("Find labels")

    def focus_replace(self) -> None:
        if self.replace_edit is None:
            return
        self.replace_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self.replace_edit.selectAll()
        self._set_find_status("Replace labels")

    def _current_find_key(self) -> tuple[str, bool]:
        return self._find_text(), self._match_case()

    def _find_text_changed_since_last_match(self) -> bool:
        needle, match_case = self._current_find_key()
        return needle != self._last_find_needle or match_case != self._last_find_match_case

    def _matching_row_from(self, *, start: int, step: int) -> Optional[tuple[int, int]]:
        """Find the first matching row, starting at row start and wrapping."""
        needle = self._find_text()
        if not needle:
            self._set_find_status("Find text is empty")
            return None
        count = len(self.owner.crops)
        if count <= 0:
            self._set_find_status("No rows")
            return None
        for offset in range(count):
            row = (start + step * offset) % count
            label = self.owner.crops[row].label
            match_pos = self._index_in_label(label, needle)
            if match_pos >= 0:
                return row, match_pos
        self._set_find_status("No matches")
        return None

    def _matching_position_after(self, row: int, pos: int) -> Optional[tuple[int, int]]:
        """Find the next match after (row, pos), including later matches in the same label."""
        needle = self._find_text()
        if not needle:
            self._set_find_status("Find text is empty")
            return None
        count = len(self.owner.crops)
        if count <= 0:
            self._set_find_status("No rows")
            return None

        row = _clamp_int(int(row), 0, count - 1)
        pos = _clamp_int(int(pos), 0, len(self.owner.crops[row].label))
        next_start = pos + len(needle)

        # First keep searching the same textbox after the selected match.
        same_label = self.owner.crops[row].label
        match_pos = self._index_in_label_from(same_label, needle, next_start)
        if match_pos >= 0:
            return row, match_pos

        # Then move through following rows.
        for i in range(1, count):
            r = (row + i) % count
            match_pos = self._index_in_label(self.owner.crops[r].label, needle)
            if match_pos >= 0:
                return r, match_pos

        # Finally, if this is the only matching row, wrap to an earlier match
        # in the same textbox instead of reporting "no matches".
        match_pos = self._index_in_label_from(same_label, needle, 0)
        if match_pos >= 0:
            return row, match_pos

        self._set_find_status("No matches")
        return None

    def _matching_position_before(self, row: int, pos: int) -> Optional[tuple[int, int]]:
        """Find the previous match before (row, pos), including earlier matches in the same label."""
        needle = self._find_text()
        if not needle:
            self._set_find_status("Find text is empty")
            return None
        count = len(self.owner.crops)
        if count <= 0:
            self._set_find_status("No rows")
            return None

        row = _clamp_int(int(row), 0, count - 1)
        pos = _clamp_int(int(pos), 0, len(self.owner.crops[row].label))

        # First keep searching the same textbox before the selected match.
        same_label = self.owner.crops[row].label
        match_pos = self._rindex_in_label_before(same_label, needle, pos)
        if match_pos >= 0:
            return row, match_pos

        # Then move through previous rows, using the last match in each label.
        for i in range(1, count):
            r = (row - i) % count
            label = self.owner.crops[r].label
            match_pos = self._rindex_in_label_before(label, needle, len(label))
            if match_pos >= 0:
                return r, match_pos

        # Finally, if this is the only matching row, wrap to a later match
        # in the same textbox.
        match_pos = self._rindex_in_label_before(same_label, needle, len(same_label))
        if match_pos >= 0:
            return row, match_pos

        self._set_find_status("No matches")
        return None

    def _select_found_match(self, row: int, match_pos: int) -> None:
        needle = self._find_text()
        self._last_find_needle = needle
        self._last_find_match_case = self._match_case()
        self._last_find_row = int(row)
        self._last_find_pos = int(match_pos)

        self.owner.select_crop(row, focus=True)
        self.set_current_cell(row, 2)
        self._set_find_status(f"Found row {row + 1}/{len(self.owner.crops)}")

        # Open the label editor and select the exact matched text. editItem()
        # creates the delegate editor asynchronously, so begin_label_edit() uses
        # a zero-delay timer before calling QLineEdit.setSelection().
        self.begin_label_edit(
            select_all=False,
            selection=(int(match_pos), len(needle)),
        )

    def find_next(self) -> None:
        if not self.owner.crops:
            self._set_find_status("No rows")
            return

        # A new search starts at the first row. Continuing the same search must
        # search after the current match inside the same textbox before moving
        # to the next row.
        focus_widget = QApplication.focusWidget()
        if focus_widget is self.find_edit or self._find_text_changed_since_last_match() or self._last_find_row is None or self._last_find_pos is None:
            match = self._matching_row_from(start=0, step=1)
        else:
            match = self._matching_position_after(self._last_find_row, self._last_find_pos)

        if match is not None:
            row, match_pos = match
            self._select_found_match(row, match_pos)

    def find_previous(self) -> None:
        if not self.owner.crops:
            self._set_find_status("No rows")
            return

        # Continue backward within the same textbox first, then move to
        # previous rows. A changed/new search starts at the last row.
        focus_widget = QApplication.focusWidget()
        if focus_widget is self.find_edit or self._find_text_changed_since_last_match() or self._last_find_row is None or self._last_find_pos is None:
            match = self._matching_row_from(start=len(self.owner.crops) - 1, step=-1)
        else:
            match = self._matching_position_before(self._last_find_row, self._last_find_pos)

        if match is not None:
            row, match_pos = match
            self._select_found_match(row, match_pos)

    def replace_current(self) -> None:
        needle = self._find_text()
        if not needle:
            self._set_find_status("Find text is empty")
            return
        replacement = self._replace_text()
        row = self.owner.selected_pos if self.owner.selected_pos is not None else None

        if row is None or not (0 <= row < len(self.owner.crops)) or self._index_in_label(self.owner.crops[row].label, needle) < 0:
            match = self._matching_row_from(start=0 if row is None else int(row) + 1, step=1)
            if match is None:
                return
            row, _match_pos = match

        old_label = self.owner.crops[row].label
        new_label = self._replace_first_in_label(old_label, needle, replacement)
        if new_label is None or new_label == old_label:
            self._set_find_status("No replacement made")
            return
        self.set_label_text(row, new_label, record_undo=True, refresh=True)
        self.owner.select_crop(row, focus=True)
        self.set_current_cell(row, 2)
        if replacement:
            repl_pos = self._index_in_label(new_label, replacement)
            if repl_pos >= 0:
                self.begin_label_edit(select_all=False, selection=(repl_pos, len(replacement)))
            else:
                self.begin_label_edit(select_all=False)
        else:
            self.begin_label_edit(select_all=False)
        self._set_find_status(f"Replaced row {row + 1}")

    def replace_all(self) -> None:
        needle = self._find_text()
        if not needle:
            self._set_find_status("Find text is empty")
            return
        replacement = self._replace_text()
        changes: list[TableChange] = []
        for row, crop in enumerate(self.owner.crops):
            old_label = crop.label
            if self._index_in_label(old_label, needle) < 0:
                continue
            new_label = self._replace_all_in_label(old_label, needle, replacement)
            if new_label != old_label:
                changes.append(TableChange(row=row, old_label=old_label, new_label=new_label))

        if not changes:
            self._set_find_status("No matches")
            return

        action = TableEditAction("Replace all", changes)
        self._push_action(action)
        self._apply_action(action, use_new=True)
        self._set_find_status(f"Replaced {len(changes)} row(s)")

    def toggle_selected_keep(self) -> None:
        if self.owner.selected_pos is None:
            return
        self.toggle_keep_at_row(self.owner.selected_pos)

    def navigate_selection_by_key(self, key: int, *, columns: int) -> None:
        if not self.owner.crops:
            return
        pos = self.owner.selected_pos if self.owner.selected_pos is not None else 0
        if key == Qt.Key.Key_Left:
            pos -= 1
        elif key == Qt.Key.Key_Right:
            pos += 1
        elif key == Qt.Key.Key_Up:
            pos -= columns
        elif key == Qt.Key.Key_Down:
            pos += columns
        pos = _clamp_int(int(pos), 0, len(self.owner.crops) - 1)
        self.owner.select_crop(pos, focus=True)
