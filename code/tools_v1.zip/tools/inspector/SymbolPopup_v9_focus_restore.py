import sys

from PyQt6.QtCore import Qt, QPoint, QEvent, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QGridLayout,
    QPushButton,
    QLineEdit,
    QLabel,
    QFrame,
    QTabWidget,
)


# model:
#   charset_train: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ->|,.:;()[]{}$λε→°←↑↓⇒↔∅∈∉⊆⊂∪∩∀∃ΣΓΔδαβγ≤≥≠≡∧∨¬⊢⊨⊥±×÷√₀₁₂³⁰ⁱ²·…⋅•⇓"
#   charset_test: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ->|,.:;()[]{}$λε→°←↑↓⇒↔∅∈∉⊆⊂∪∩∀∃ΣΓΔδαβγ≤≥≠≡∧∨¬⊢⊨⊥±×÷√₀₁₂³⁰ⁱ²·…⋅•⇓"


# ...existing code...

SYMBOL_CATEGORIES = [
    (
        "Arrows",
        [
            ("→", "right arrow"),
            ("←", "left arrow"),
            ("↑", "up arrow"),
            ("↓", "down arrow"),
            ("⇓", "double down arrow"),
            ("⇒", "implies"),
            ("↔", "iff / bidirectional"),
        ],
    ),
    (
        "Sets",
        [
            ("∅", "empty set"),
            ("∈", "element of"),
            ("∉", "not element of"),
            ("⊆", "subset or equal"),
            ("⊂", "proper subset"),
            ("∪", "union"),
            ("∩", "intersection"),
            ("𝔼", "expected value"),
            ("ℝ", "real numbers"),
            ("ℤ", "integers"),
            ("ℕ", "natural numbers"),
            ("ℂ", "complex numbers"),
            ("ℚ", "rationals"),
        ],
    ),
    (
        "Logic",
        [
            ("λ", "lambda / empty string"),
            ("ε", "epsilon / empty string"),
            ("∀", "for all"),
            ("∃", "there exists"),
            ("∧", "and"),
            ("∨", "or"),
            ("¬", "not"),
            ("⊢", "turnstile"),
            ("⊨", "models"),
            ("⊥", "bottom / contradiction"),
        ],
    ),
    (
        "Greek",
        [
            ("Α", "capital alpha"),
            ("Β", "capital beta"),
            ("Γ", "capital gamma"),
            ("Δ", "capital delta"),
            ("Ε", "capital epsilon"),
            ("Ζ", "capital zeta"),
            ("Η", "capital eta"),
            ("Θ", "capital theta"),
            ("Ι", "capital iota"),
            ("Κ", "capital kappa"),
            ("Λ", "capital lambda"),
            ("Μ", "capital mu"),
            ("Ν", "capital nu"),
            ("Ξ", "capital xi"),
            ("Ο", "capital omicron"),
            ("Π", "capital pi"),
            ("Ρ", "capital rho"),
            ("Σ", "capital sigma"),
            ("Τ", "capital tau"),
            ("Υ", "capital upsilon"),
            ("Φ", "capital phi"), 
            ("Χ", "capital chi"), 
            ("Ψ", "capital psi"), 
            ("Ω", "capital omega"),

            ("α", "alpha"), 
            ("β", "beta"), 
            ("γ", "gamma"), 
            ("δ", "delta"),
            ("ε", "epsilon"), 
            ("ζ", "zeta"), 
            ("η", "eta"), 
            ("θ", "theta"),
            ("ι", "iota"), 
            ("κ", "kappa"), 
            ("λ", "lambda"), 
            ("μ", "mu"),
            ("ν", "nu"), 
            ("ξ", "xi"), 
            ("ο", "omicron"), 
            ("π", "pi"),
            ("ρ", "rho"), 
            ("σ", "sigma"), 
            ("ς", "final sigma"), 
            ("τ", "tau"),
            ("υ", "upsilon"), 
            ("φ", "phi"), 
            ("χ", "chi"), 
            ("ψ", "psi"), 
            ("ω", "omega"),
            ("ϑ", "theta symbol"),
        ],
    ),
    (
        "Relations",
        [
            ("<", "less than"),
            (">", "greater than"),
            ("⟨", "left angle bracket"),
            ("⟩", "right angle bracket"),
            ("≤", "less than or equal"),
            ("≥", "greater than or equal"),
            ("≠", "not equal"),
            ("≡", "equivalent"),
        ],
    ),
    (
        "Math",
        [
            ("±", "plus-minus"),
            ("×", "times / multiplication"),
            ("⋅", "times / multiplication"),
            ("÷", "division"),
            ("√", "square root"),
            ("⎯", "overline / vinculum"), 
            ("°", "degree"),
            ("∞", "infinity"),
        ],
    ),
    (
        "Linear Algebra",
        [
            ("‖", "norm / double vertical bar"),        # \max_{\lVert x\rVert=1}
            ("⋅", "dot product"),
            ("⊗", "tensor product"),
            ("⊕", "direct sum"),
            ("⊙", "Hadamard product"),
            ("⟂", "orthogonal"),
            ("∥", "parallel"),
            ("∇", "nabla / gradient"),
            ("∂", "partial derivative"),
            ("†", "conjugate transpose"),
            ("√", "square root"),
        ],
    ),
    (
        "Subscripts",
        [
            ("₍", "subscript left parenthesis"),
            ("₎", "subscript right parenthesis"),
            ("₊", "subscript plus"),
            ("₋", "subscript minus"),
            ("₌", "subscript equals"),

            ("ₐ", "subscript a"),
            ("ₑ", "subscript e"),
            ("ₕ", "subscript h"),
            ("ᵢ", "subscript i"),
            ("ⱼ", "subscript j"),
            ("ₖ", "subscript k"),
            ("ₗ", "subscript l"),
            ("ₘ", "subscript m"),
            ("ₙ", "subscript n"),
            ("ₒ", "subscript o"),
            ("ₚ", "subscript p"),
            ("ᵣ", "subscript r"),
            ("ₛ", "subscript s"),
            ("ₜ", "subscript t"),
            ("ᵤ", "subscript u"),
            ("ᵥ", "subscript v"),
            ("ₓ", "subscript x"),
            ("ᵧ", "subscript y"),
            ("ₔ", "subscript schwa"),

            ("ᵦ", "subscript beta"),
            ("ᵨ", "subscript rho"),
            ("ᵩ", "subscript phi"),
            ("ᵪ", "subscript chi"),

            ("₀", "subscript 0"),
            ("₁", "subscript 1"),
            ("₂", "subscript 2"),
            ("₃", "subscript 3"),
            ("₄", "subscript 4"),
            ("₅", "subscript 5"),
            ("₆", "subscript 6"),
            ("₇", "subscript 7"),
            ("₈", "subscript 8"),
            ("₉", "subscript 9"),
        ],
    ),
    (
        "Superscripts",
        [
            ("⁻¹", "superscript -1 / inverse"),
            ("ᵀ", "superscript transpose"),
            ("ᵗʰ", "superscript th"),
            ("ᴬ", "superscript A"),
            ("ᴮ", "superscript B"),
            ("ᴰ", "superscript D"),
            ("ᴱ", "superscript E"),
            ("ᴳ", "superscript G"),
            ("ᴴ", "superscript H"),
            ("ᴵ", "superscript I"),
            ("ᴶ", "superscript J"),
            ("ᴷ", "superscript K"),
            ("ᴸ", "superscript L"),
            ("ᴹ", "superscript M"),
            ("ᴺ", "superscript N"),
            ("ᴼ", "superscript O"),
            ("ᴾ", "superscript P"),
            ("ᴿ", "superscript R"),
            ("ᵁ", "superscript U"),
            ("ⱽ", "superscript V"),
            ("ᵂ", "superscript W"),

            ("ᵃ", "superscript a"),
            ("ᵇ", "superscript b"),
            ("ᶜ", "superscript c"),
            ("ᵈ", "superscript d"),
            ("ᵉ", "superscript e"),
            ("ᶠ", "superscript f"),
            ("ᵍ", "superscript g"),
            ("ʰ", "superscript h"),
            ("ⁱ", "superscript i"),
            ("ʲ", "superscript j"),
            ("ᵏ", "superscript k"),
            ("ˡ", "superscript l"),
            ("ᵐ", "superscript m"),
            ("ⁿ", "superscript n"),
            ("ᵒ", "superscript o"),
            ("ᵖ", "superscript p"),
            ("ʳ", "superscript r"),
            ("ˢ", "superscript s"),
            ("ᵗ", "superscript t"),
            ("ᵘ", "superscript u"),
            ("ᵛ", "superscript v"),
            ("ʷ", "superscript w"),
            ("ˣ", "superscript x"),
            ("ʸ", "superscript y"),
            ("ᶻ", "superscript z"),

            ("ᵅ", "superscript alpha"),
            ("ᵝ", "superscript beta"),
            ("ᵞ", "superscript gamma"),
            ("ᵟ", "superscript delta"),
            ("ᵋ", "superscript epsilon"),
            ("ᶿ", "superscript theta"),
            ("ᶥ", "superscript iota"),
            ("ᵠ", "superscript phi"),
            ("ᵡ", "superscript chi"),

            ("⁽", "superscript left parenthesis"),
            ("⁾", "superscript right parenthesis"),
            ("⁺", "superscript plus"),
            ("⁻", "superscript minus"),
            ("⁼", "superscript equals"),

            ("⁰", "superscript 0"),
            ("¹", "superscript 1"),
            ("²", "superscript 2"),
            ("³", "superscript 3"),
            ("⁴", "superscript 4"),
            ("⁵", "superscript 5"),
            ("⁶", "superscript 6"),
            ("⁷", "superscript 7"),
            ("⁸", "superscript 8"),
            ("⁹", "superscript 9"),
        ],
    ),
    (
        "Dots",
        [
            ("·", "middle dot / interpunct"),
            ("∙", "bullet operator"),
            ("⋅", "dot operator / multiplication"),
            ("•", "bullet"),
            ("◦", "white bullet"),
            ("∘", "ring operator / composition"),
            ("˙", "dot above"),
            ("…", "horizontal ellipsis"),
            ("⋯", "midline horizontal ellipsis"),
            ("⋮", "vertical ellipsis"),
            ("⋰", "up-right diagonal ellipsis"),
            ("⋱", "down-right diagonal ellipsis"),
        ],
    ),
]

class SymbolPopup(QFrame):
    COLS = 5
    closed = pyqtSignal()

    def __init__(self, insert_callback, parent=None, initial_symbol=None):
        super().__init__(parent)

        self.insert_callback = insert_callback
        self.initial_symbol = initial_symbol
        self.symbol_buttons = []
        self.grids = []
        self.tab_pages = []
        self.current_symbol_index = None
        self._closed_signal_emitted = False

        # Makes it act like a real popup.
        # Clicking outside the popup closes it automatically.
        self.setWindowFlags(Qt.WindowType.Popup)

        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            QFrame {
                background: #f8f8f8;
                border: 1px solid #999;
                border-radius: 8px;
            }

            QLineEdit {
                padding: 6px;
                border: 1px solid #aaa;
                border-radius: 6px;
                background: white;
                font-size: 13px;
            }

            QTabWidget::pane {
                border: 1px solid #c8c8c8;
                border-radius: 6px;
                background: #f8f8f8;
                margin-top: -1px;
            }

            QTabBar::tab {
                padding: 5px 10px;
                border: 1px solid #c8c8c8;
                background: #eeeeee;
                border-top-left-radius: 5px;
                border-top-right-radius: 5px;
                margin-right: 2px;
            }

            QTabBar::tab:selected {
                background: white;
                border-bottom-color: white;
            }

            QTabBar::tab:disabled {
                color: #aaaaaa;
                background: #f1f1f1;
            }

            QPushButton {
                font-size: 18px;
                padding: 6px 10px;
                border: 1px solid #ccc;
                border-radius: 6px;
                background: white;
            }

            QPushButton:hover {
                background: #e8f0ff;
            }

            QPushButton:focus {
                border: 2px solid #4b8cff;
                background: #e8f0ff;
            }

            QPushButton[eligible="false"] {
                color: #aaa;
                background: #eeeeee;
                border-color: #dddddd;
            }

            QLabel {
                color: #444;
                border: none;
                background: transparent;
            }
        """)

        self.main_layout = QVBoxLayout(self)
        self.main_layout.setContentsMargins(10, 10, 10, 10)
        self.main_layout.setSpacing(8)

        title = QLabel("Search and click a symbol")
        self.main_layout.addWidget(title)

        self.search_box = QLineEdit()
        self.search_box.setPlaceholderText("Search: lambda, arrow, subset, ∈ ...")
        self.search_box.textChanged.connect(self.update_symbol_buttons)
        self.search_box.installEventFilter(self)
        self.main_layout.addWidget(self.search_box)

        self.tabs = QTabWidget()
        self.tabs.currentChanged.connect(self.on_tab_changed)
        self.main_layout.addWidget(self.tabs)

        self.no_matches_label = QLabel("No matching symbols")
        self.no_matches_label.hide()
        self.main_layout.addWidget(self.no_matches_label)

        self.build_symbol_panes()

    def showEvent(self, event):  # type: ignore[override]
        self._closed_signal_emitted = False
        super().showEvent(event)

    def hideEvent(self, event):  # type: ignore[override]
        super().hideEvent(event)
        if not self._closed_signal_emitted:
            self._closed_signal_emitted = True
            self.closed.emit()

    def focus_initial_symbol(self):
        """Open to the last-used symbol, if one was provided."""
        if not self.initial_symbol:
            self.search_box.setFocus()
            return

        for i, info in enumerate(self.symbol_buttons):
            if info["symbol"] == self.initial_symbol and info["button"].isEnabled():
                self.focus_button(i)
                return

        self.search_box.setFocus()

    def build_symbol_panes(self):
        """Build all tab panes once so positions stay stable while searching."""
        for tab_index, (category_name, symbols) in enumerate(SYMBOL_CATEGORIES):
            page = QWidget()
            page_layout = QVBoxLayout(page)
            page_layout.setContentsMargins(8, 8, 8, 8)

            grid = QGridLayout()
            grid.setSpacing(6)
            page_layout.addLayout(grid)
            page_layout.addStretch(1)

            self.tabs.addTab(page, category_name)
            self.tab_pages.append(page)
            self.grids.append(grid)

            for local_index, (symbol, description) in enumerate(symbols):
                button = QPushButton(symbol)
                button.setToolTip(description)
                button.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
                button.installEventFilter(self)
                button.clicked.connect(
                    lambda checked=False, s=symbol: self.choose_symbol(s)
                )

                row = local_index // self.COLS
                col = local_index % self.COLS
                grid.addWidget(button, row, col)

                global_index = len(self.symbol_buttons)
                self.symbol_buttons.append(
                    {
                        "button": button,
                        "symbol": symbol,
                        "description": description,
                        "tab_index": tab_index,
                        "local_index": local_index,
                        "row": row,
                        "col": col,
                        "global_index": global_index,
                    }
                )

        self.update_symbol_buttons()

    def eventFilter(self, obj, event):
        if event.type() != QEvent.Type.KeyPress:
            return super().eventFilter(obj, event)

        key = event.key()

        if obj is self.search_box:
            if key == Qt.Key.Key_Down:
                self.focus_first_enabled_button()
                return True

            # Left/Right switch symbol panes while keeping focus in search.
            if key == Qt.Key.Key_Left:
                self.switch_tab_from_search(direction=-1)
                return True

            if key == Qt.Key.Key_Right:
                self.switch_tab_from_search(direction=1)
                return True

            # Optional convenience: Enter in the search box selects the first match.
            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                self.choose_first_enabled_button()
                return True

            if key == Qt.Key.Key_Escape:
                self.close()
                return True

            return super().eventFilter(obj, event)

        button_indexes = {
            info["button"]: i
            for i, info in enumerate(self.symbol_buttons)
        }

        if obj in button_indexes:
            self.current_symbol_index = button_indexes[obj]

            if key in (
                Qt.Key.Key_Up,
                Qt.Key.Key_Down,
                Qt.Key.Key_Left,
                Qt.Key.Key_Right,
            ):
                self.move_symbol_focus(key)
                return True

            if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter):
                symbol = self.symbol_buttons[self.current_symbol_index]["symbol"]
                self.choose_symbol(symbol)
                return True

            if key == Qt.Key.Key_Escape:
                self.search_box.setFocus()
                return True

        return super().eventFilter(obj, event)

    def on_tab_changed(self, _tab_index):
        # Reset symbol focus when switching panes. Down from search will enter
        # the current pane, or the first pane with a match if this pane has none.
        self.current_symbol_index = None

    def update_symbol_buttons(self):
        """Disable non-matching symbols without rebuilding/reflowing each pane."""
        query = self.search_box.text().strip().lower()
        total_matches = 0
        tab_match_counts = [0 for _ in SYMBOL_CATEGORIES]

        for info in self.symbol_buttons:
            button = info["button"]
            symbol = info["symbol"]
            description = info["description"]
            tab_index = info["tab_index"]

            searchable = f"{symbol} {description}".lower()
            is_match = query in searchable

            button.setEnabled(is_match)
            button.setProperty("eligible", "true" if is_match else "false")
            button.style().unpolish(button)
            button.style().polish(button)

            if is_match:
                total_matches += 1
                tab_match_counts[tab_index] += 1

        # Keep all panes visible when no query is typed.
        # While searching, disable panes that have no matches.
        for tab_index, count in enumerate(tab_match_counts):
            self.tabs.setTabEnabled(tab_index, query == "" or count > 0)

            base_name = SYMBOL_CATEGORIES[tab_index][0]
            if query:
                self.tabs.setTabText(tab_index, f"{base_name} ({count})")
            else:
                self.tabs.setTabText(tab_index, base_name)

        self.no_matches_label.setVisible(total_matches == 0)

        if query and total_matches > 0:
            current_tab = self.tabs.currentIndex()
            if current_tab < 0 or tab_match_counts[current_tab] == 0:
                self.tabs.setCurrentIndex(self.first_tab_with_match(tab_match_counts))

        # If the focused symbol becomes disabled because of the search text,
        # move focus back to the search box. Down will re-enter a matching pane.
        focused = QApplication.focusWidget()
        if focused is not None:
            focused_is_disabled_symbol = any(
                focused is info["button"] and not info["button"].isEnabled()
                for info in self.symbol_buttons
            )
            if focused_is_disabled_symbol:
                self.search_box.setFocus()
                self.current_symbol_index = None

    def first_tab_with_match(self, tab_match_counts):
        for tab_index, count in enumerate(tab_match_counts):
            if count > 0:
                return tab_index
        return 0

    def enabled_indexes(self, tab_index=None):
        if tab_index is None:
            tab_index = self.tabs.currentIndex()

        return [
            i
            for i, info in enumerate(self.symbol_buttons)
            if info["tab_index"] == tab_index and info["button"].isEnabled()
        ]

    def all_enabled_indexes(self):
        return [
            i
            for i, info in enumerate(self.symbol_buttons)
            if info["button"].isEnabled()
        ]

    def focus_button(self, index):
        info = self.symbol_buttons[index]
        button = info["button"]

        if not button.isEnabled():
            return

        self.current_symbol_index = index

        if self.tabs.currentIndex() != info["tab_index"]:
            self.tabs.setCurrentIndex(info["tab_index"])

        button.setFocus()

    def focus_first_enabled_button(self):
        current_tab_matches = self.enabled_indexes(self.tabs.currentIndex())
        if current_tab_matches:
            self.focus_button(current_tab_matches[0])
            return

        all_matches = self.all_enabled_indexes()
        if all_matches:
            self.focus_button(all_matches[0])

    def choose_first_enabled_button(self):
        current_tab_matches = self.enabled_indexes(self.tabs.currentIndex())
        if current_tab_matches:
            symbol = self.symbol_buttons[current_tab_matches[0]]["symbol"]
            self.choose_symbol(symbol)
            return

        all_matches = self.all_enabled_indexes()
        if all_matches:
            symbol = self.symbol_buttons[all_matches[0]]["symbol"]
            self.choose_symbol(symbol)

    def move_symbol_focus(self, key):
        if self.current_symbol_index is None:
            self.focus_first_enabled_button()
            return

        current_info = self.symbol_buttons[self.current_symbol_index]
        current_tab = current_info["tab_index"]
        enabled = self.enabled_indexes(current_tab)

        if not enabled:
            self.search_box.setFocus()
            self.current_symbol_index = None
            return

        if self.current_symbol_index not in enabled:
            self.focus_button(enabled[0])
            return

        current = self.current_symbol_index

        if key == Qt.Key.Key_Left:
            target = self.find_horizontal_target(current, direction=-1)
            if target is None:
                self.switch_tab_from_symbol(direction=-1, edge="last")
            else:
                self.focus_button(target)
            return

        if key == Qt.Key.Key_Right:
            target = self.find_horizontal_target(current, direction=1)
            if target is None:
                self.switch_tab_from_symbol(direction=1, edge="first")
            else:
                self.focus_button(target)
            return

        if key == Qt.Key.Key_Up:
            target = self.find_vertical_target(current, direction=-1)
            if target is None:
                self.search_box.setFocus()
                self.current_symbol_index = None
            else:
                self.focus_button(target)
            return

        if key == Qt.Key.Key_Down:
            target = self.find_vertical_target(current, direction=1)
            if target is not None:
                self.focus_button(target)
            return

    def find_horizontal_target(self, current, direction):
        """Find previous/next enabled button inside the current pane.

        Returns None at the edge so Left/Right can switch panes instead
        of wrapping inside the same pane.
        """
        current_tab = self.symbol_buttons[current]["tab_index"]
        enabled = self.enabled_indexes(current_tab)

        if direction < 0:
            candidates = [i for i in enabled if i < current]
            return candidates[-1] if candidates else None

        candidates = [i for i in enabled if i > current]
        return candidates[0] if candidates else None

    def enabled_tab_indexes(self):
        return [
            tab_index
            for tab_index in range(self.tabs.count())
            if self.tabs.isTabEnabled(tab_index)
        ]

    def next_enabled_tab(self, current_tab, direction):
        enabled_tabs = self.enabled_tab_indexes()
        if not enabled_tabs:
            return None

        if current_tab not in enabled_tabs:
            return enabled_tabs[0]

        pos = enabled_tabs.index(current_tab)
        next_pos = (pos + direction) % len(enabled_tabs)
        return enabled_tabs[next_pos]

    def switch_tab_from_search(self, direction):
        """Left/Right from the search box switches panes but keeps search focused."""
        target_tab = self.next_enabled_tab(self.tabs.currentIndex(), direction)
        if target_tab is None:
            return

        self.tabs.setCurrentIndex(target_tab)
        self.search_box.setFocus()

    def switch_tab_from_symbol(self, direction, edge):
        """Left/Right at the edge of a pane switches to the next/previous pane."""
        current_tab = self.tabs.currentIndex()
        target_tab = self.next_enabled_tab(current_tab, direction)
        if target_tab is None or target_tab == current_tab:
            return

        self.tabs.setCurrentIndex(target_tab)

        indexes = self.enabled_indexes(target_tab)
        if not indexes:
            self.search_box.setFocus()
            self.current_symbol_index = None
            return

        if edge == "last":
            self.focus_button(indexes[-1])
        else:
            self.focus_button(indexes[0])

    def find_vertical_target(self, current, direction):
        """Find the nearest enabled button one visual row up/down in the same pane."""
        current_info = self.symbol_buttons[current]
        current_tab = current_info["tab_index"]
        current_col = current_info["col"]
        current_row = current_info["row"]

        same_tab = [
            info
            for info in self.symbol_buttons
            if info["tab_index"] == current_tab
        ]

        max_row = max(info["row"] for info in same_tab)
        next_row = current_row + direction

        while 0 <= next_row <= max_row:
            row_infos = [
                info
                for info in same_tab
                if info["row"] == next_row
            ]

            # Prefer same column, then nearest column in that row.
            row_infos.sort(key=lambda info: abs(info["col"] - current_col))

            for info in row_infos:
                if info["button"].isEnabled():
                    return info["global_index"]

            next_row += direction

        return None

    def choose_symbol(self, symbol):
        self.insert_callback(symbol)
        self.close()


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Clickable Symbol Popup Demo")
        self.resize(620, 220)

        self.symbol_popup = None
        self.last_symbol_used = None

        layout = QVBoxLayout(self)
        layout.setSpacing(10)

        label = QLabel("Type a label, then press Cmd+I to open the symbol popup:")
        layout.addWidget(label)

        row = QHBoxLayout()
        layout.addLayout(row)

        self.line_edit = QLineEdit()
        self.line_edit.setPlaceholderText("Example: q0 → q1, λ, ε, etc.")
        row.addWidget(self.line_edit)

        self.symbol_button = QPushButton("Symbols…")
        self.symbol_button.clicked.connect(self.toggle_symbol_popup)
        row.addWidget(self.symbol_button)

        hint = QLabel(
            "Shortcut: Cmd+I toggles the popup. "
            "Down leaves search, arrows navigate symbols/panes, Enter inserts."
        )
        layout.addWidget(hint)

        # App-level event filter lets Cmd+I work even when the popup search box has focus.
        QApplication.instance().installEventFilter(self)

    def eventFilter(self, obj, event):
        if event.type() == QEvent.Type.KeyPress:
            if self.is_cmd_i(event):
                self.toggle_symbol_popup()
                return True

        return super().eventFilter(obj, event)

    def is_cmd_i(self, event):
        # On macOS, Qt usually reports the Command key as ControlModifier.
        return (
            event.key() == Qt.Key.Key_I
            and bool(event.modifiers() & Qt.KeyboardModifier.ControlModifier)
        )

    def insert_symbol(self, symbol):
        self.last_symbol_used = symbol
        self.line_edit.insert(symbol)
        self.line_edit.setFocus()

    def toggle_symbol_popup(self):
        if self.symbol_popup is not None and self.symbol_popup.isVisible():
            self.symbol_popup.close()
            return

        self.symbol_popup = SymbolPopup(
            insert_callback=self.insert_symbol,
            parent=self,
            initial_symbol=self.last_symbol_used,
        )
        self.symbol_popup.closed.connect(self.line_edit.setFocus)

        # Open under the MAIN textbox, not under the popup search box
        # and not under the Symbols button.
        global_pos = self.line_edit.mapToGlobal(
            QPoint(0, self.line_edit.height())
        )

        self.symbol_popup.move(global_pos)

        # Optional: make popup at least as wide as the main textbox.
        popup_width = max(520, self.line_edit.width())
        self.symbol_popup.resize(
            popup_width,
            self.symbol_popup.sizeHint().height(),
        )

        self.symbol_popup.show()
        self.symbol_popup.focus_initial_symbol()


def main():
    app = QApplication(sys.argv)

    window = MainWindow()
    window.show()

    sys.exit(app.exec())


if __name__ == "__main__":
    main()
