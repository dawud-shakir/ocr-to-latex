#!/usr/bin/env python3
"""EasyOCR/CRAFT helper process for inspect_crops_craft_curator_rotate_shift_v5.py.

This file intentionally owns all EasyOCR/CRAFT loading, detection preprocessing,
and newline-delimited JSON stdin/stdout protocol handling. Keeping this code in
a separate process/file prevents torch/EasyOCR initialization from interfering
with the main Qt GUI process and native file dialogs.
"""

from __future__ import annotations

import inspect
import json
import math
import sys
import traceback
from typing import Any

import numpy as np

# Hardcoded CRAFT/EasyOCR detection settings requested by the user.
CRAFT_DETECT_KWARGS: dict[str, Any] = {
    "min_size": 0,
    "text_threshold": 0.36,
    "low_text": 0.18,
    "link_threshold": 0.18,
    "canvas_size": 1280,
    "mag_ratio": 1.0,
    "slope_ths": 0.1,
    "ycenter_ths": 0.5,
    "height_ths": 0.0,
    "width_ths": 0.0,
    "add_margin": 0.12,
    "reformat": True,
    "threshold": 0.0,
    "bbox_min_score": 0.0,
    "bbox_min_size": 0,
    "max_candidates": 0,
}

# Match the previous craft_labeling_studio detection path defaults.
# These are intentionally not exposed as a large settings UI in this small curator.
DETECT_USE_PREPROCESS = True              # studio: preprocessing checkbox checked
DETECT_UPSAMPLE_ENABLED = False           # studio: upsample checkbox unchecked
DETECT_UPSAMPLE_SCALE = 2.0               # studio default combo value, unused unless enabled
DETECT_HORIZONTALIZE_ENABLED = False      # studio: horizontalize checkbox unchecked
DETECT_HORIZONTALIZE_AUTO = True
DETECT_HORIZONTALIZE_MANUAL_ANGLE = 0.0



# ---------------------------------------------------------------------------
# Detection geometry and preprocessing helpers
# ---------------------------------------------------------------------------

def affine_to_homography(matrix: np.ndarray) -> np.ndarray:
    m = np.asarray(matrix, dtype=np.float32)
    if m.shape == (2, 3):
        return np.vstack([m, np.array([0, 0, 1], dtype=np.float32)])
    if m.shape == (3, 3):
        return m
    raise ValueError(f"Expected 2x3 or 3x3 affine matrix, got {m.shape}")


def compose_affine(next_matrix: np.ndarray, current_matrix: np.ndarray) -> np.ndarray:
    composed = affine_to_homography(next_matrix) @ affine_to_homography(current_matrix)
    return composed[:2].astype(np.float32)


def transform_points_affine(points: Any, matrix: np.ndarray) -> np.ndarray:
    pts = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    ones = np.ones((pts.shape[0], 1), dtype=np.float32)
    hom = np.hstack([pts, ones])
    mapped = hom @ np.asarray(matrix, dtype=np.float32).T
    return mapped.reshape(np.asarray(points, dtype=np.float32).shape)


def resize_with_matrix(image: np.ndarray, scale: float) -> tuple[np.ndarray, np.ndarray]:
    import cv2  # type: ignore

    scale = float(scale)
    if abs(scale - 1.0) < 1e-6:
        return image.copy(), np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32)
    h, w = image.shape[:2]
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))
    interp = cv2.INTER_CUBIC if scale > 1.0 else cv2.INTER_AREA
    resized = cv2.resize(image, (new_w, new_h), interpolation=interp)
    matrix = np.array([[scale, 0, 0], [0, scale, 0]], dtype=np.float32)
    return resized, matrix


def rotate_bound_with_matrix(image: np.ndarray, angle_degrees: float) -> tuple[np.ndarray, np.ndarray]:
    import cv2  # type: ignore

    angle_degrees = float(angle_degrees)
    if abs(angle_degrees) < 1e-6:
        return image.copy(), np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32)

    h, w = image.shape[:2]
    center = (w / 2.0, h / 2.0)
    matrix = cv2.getRotationMatrix2D(center, angle_degrees, 1.0).astype(np.float32)
    cos = abs(matrix[0, 0])
    sin = abs(matrix[0, 1])
    new_w = int(round((h * sin) + (w * cos)))
    new_h = int(round((h * cos) + (w * sin)))
    matrix[0, 2] += (new_w / 2.0) - center[0]
    matrix[1, 2] += (new_h / 2.0) - center[1]
    rotated = cv2.warpAffine(
        image,
        matrix,
        (new_w, new_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )
    return rotated, matrix


def estimate_text_angle_degrees(image: np.ndarray) -> float:
    import cv2  # type: ignore

    if image is None or image.size == 0:
        return 0.0
    if image.ndim == 2:
        gray = image.copy()
    elif image.ndim == 3 and image.shape[2] == 4:
        gray = cv2.cvtColor(cv2.cvtColor(image, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2GRAY)
    else:
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    long_side = max(gray.shape[:2])
    if long_side > 1200:
        scale = 1200.0 / long_side
        gray_small = cv2.resize(gray, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
    else:
        gray_small = gray

    gray_small = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8)).apply(gray_small)
    edges = cv2.Canny(gray_small, 50, 150, apertureSize=3)
    min_len = max(20, int(0.08 * min(gray_small.shape[:2])))
    lines = cv2.HoughLinesP(
        edges,
        rho=1,
        theta=np.pi / 180.0,
        threshold=max(20, int(0.02 * min(gray_small.shape[:2]))),
        minLineLength=min_len,
        maxLineGap=max(6, int(0.02 * min(gray_small.shape[:2]))),
    )
    angles: list[float] = []
    if lines is not None:
        for line in lines.reshape(-1, 4):
            x1, y1, x2, y2 = line.astype(float)
            dx = x2 - x1
            dy = y2 - y1
            length = math.hypot(dx, dy)
            if length < min_len:
                continue
            angle = math.degrees(math.atan2(dy, dx))
            while angle <= -90:
                angle += 180
            while angle > 90:
                angle -= 180
            if -35 <= angle <= 35:
                angles.append(angle)

    if angles:
        return float(np.median(np.array(angles, dtype=np.float32)))

    try:
        blur = cv2.GaussianBlur(gray_small, (3, 3), 0)
        _, th = cv2.threshold(blur, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        if np.mean(th) > 127:
            th = 255 - th
        coords = np.column_stack(np.where(th > 0))
        if coords.shape[0] < 25:
            return 0.0
        rect = cv2.minAreaRect(coords[:, ::-1].astype(np.float32))
        angle = float(rect[-1])
        if angle < -45:
            angle += 90
        if angle > 45:
            angle -= 90
        if -35 <= angle <= 35:
            return angle
    except Exception:
        pass

    return 0.0


def preprocess_for_detection_with_matrix(image_bgr: np.ndarray, allow_internal_resize: bool = True) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """Same default preprocessing path used by craft_labeling_studio."""
    import cv2  # type: ignore

    steps: list[str] = []
    matrix = np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32)
    if image_bgr is None or image_bgr.size == 0:
        return image_bgr, matrix, steps

    if image_bgr.ndim == 2:
        gray = image_bgr.copy()
    elif image_bgr.ndim == 3 and image_bgr.shape[2] == 4:
        gray = cv2.cvtColor(cv2.cvtColor(image_bgr, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2GRAY)
    else:
        gray = cv2.cvtColor(image_bgr, cv2.COLOR_BGR2GRAY)
    steps.append("grayscale")

    if allow_internal_resize:
        long_side = max(gray.shape[:2])
        if long_side < 900:
            scale = min(2.4, 900.0 / max(1, long_side))
            gray, sm = resize_with_matrix(gray, scale)
            matrix = compose_affine(sm, matrix)
            steps.append(f"auto resize {scale:.2f}x")
        elif long_side > 1800:
            scale = 1800.0 / long_side
            gray, sm = resize_with_matrix(gray, scale)
            matrix = compose_affine(sm, matrix)
            steps.append(f"auto resize {scale:.2f}x")

    gray = cv2.createCLAHE(clipLimit=2.2, tileGridSize=(8, 8)).apply(gray)
    blur = cv2.GaussianBlur(gray, (0, 0), sigmaX=1.0)
    out = cv2.addWeighted(gray, 1.45, blur, -0.45, 0)
    steps.append("CLAHE + sharpen")
    return out, matrix, steps


def build_detection_preprocess_image(
    frame: np.ndarray,
    use_preprocess: bool,
    upsample_enabled: bool,
    upsample_scale: float,
    horizontalize_enabled: bool,
    horizontalize_auto: bool,
    manual_angle: float,
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """Mirror craft_labeling_studio's image-prep chain before CRAFT detect()."""
    if frame is None or frame.size == 0:
        raise ValueError("No source image loaded.")

    image = frame.copy()
    matrix = np.array([[1, 0, 0], [0, 1, 0]], dtype=np.float32)
    steps: list[str] = []

    if horizontalize_enabled:
        if horizontalize_auto:
            estimated = estimate_text_angle_degrees(image)
            rotate_angle = -estimated
            steps.append(f"horizontalize auto estimated {estimated:+.2f}° / rotated {rotate_angle:+.2f}°")
        else:
            rotate_angle = float(manual_angle)
            steps.append(f"horizontalize manual rotate {rotate_angle:+.2f}°")
        image, rm = rotate_bound_with_matrix(image, rotate_angle)
        matrix = compose_affine(rm, matrix)

    if upsample_enabled:
        scale = max(1.0, float(upsample_scale))
        if scale > 1.0:
            image, sm = resize_with_matrix(image, scale)
            matrix = compose_affine(sm, matrix)
            steps.append(f"upsample {scale:.2f}x")

    if use_preprocess:
        allow_internal_resize = not (upsample_enabled and float(upsample_scale) > 1.0)
        image, pm, pre_steps = preprocess_for_detection_with_matrix(image, allow_internal_resize=allow_internal_resize)
        matrix = compose_affine(pm, matrix)
        steps.extend(pre_steps)

    return image, matrix, steps


def horizontal_box_to_points(box: Any) -> np.ndarray:
    arr = np.array(box, dtype=np.float32).reshape(-1)
    x_min, x_max, y_min, y_max = arr[:4]
    return np.array(
        [[x_min, y_min], [x_max, y_min], [x_max, y_max], [x_min, y_max]],
        dtype=np.float32,
    )


def normalize_detect_output(out: Any) -> tuple[list[Any], list[Any]]:
    if not isinstance(out, tuple) or len(out) < 2:
        return [], []
    horizontal, free = out[0], out[1]
    if isinstance(horizontal, list) and len(horizontal) == 1 and isinstance(horizontal[0], list):
        horizontal = horizontal[0]
    if isinstance(free, list) and len(free) == 1 and isinstance(free[0], list):
        free = free[0]
    return list(horizontal or []), list(free or [])


def bounds_from_points_np(points: Any) -> tuple[float, float, float, float]:
    pts = np.asarray(points, dtype=np.float32).reshape(-1, 2)
    return float(np.min(pts[:, 0])), float(np.min(pts[:, 1])), float(np.max(pts[:, 0])), float(np.max(pts[:, 1]))


def reading_order_key_from_detect_points(points: Any) -> tuple[float, float]:
    x1, y1, _x2, _y2 = bounds_from_points_np(points)
    return y1, x1


def supported_kwargs(callable_obj: Any, kwargs: dict[str, Any]) -> dict[str, Any]:
    try:
        sig = inspect.signature(callable_obj)
        if any(p.kind == inspect.Parameter.VAR_KEYWORD for p in sig.parameters.values()):
            return kwargs
        allowed = set(sig.parameters.keys())
        return {k: v for k, v in kwargs.items() if k in allowed}
    except Exception:
        return kwargs


def points_array_to_list(points: Any) -> list[list[float]]:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    return [[float(x), float(y)] for x, y in pts.tolist()]


def run_craft_detection(reader: object, image_file: str) -> dict[str, Any]:
    """Run one CRAFT/EasyOCR detection request.

    This function is intentionally free of GUI calls so it can run inside the
    helper process. The GUI process receives only plain JSON-serializable data.
    """
    import cv2  # type: ignore

    frame = cv2.imread(image_file, cv2.IMREAD_COLOR)
    if frame is None or frame.size == 0:
        raise ValueError(f"Could not read image for CRAFT detection: {image_file}")

    detect_img, frame_to_detect_matrix, steps = build_detection_preprocess_image(
        frame,
        use_preprocess=DETECT_USE_PREPROCESS,
        upsample_enabled=DETECT_UPSAMPLE_ENABLED,
        upsample_scale=DETECT_UPSAMPLE_SCALE,
        horizontalize_enabled=DETECT_HORIZONTALIZE_ENABLED,
        horizontalize_auto=DETECT_HORIZONTALIZE_AUTO,
        manual_angle=DETECT_HORIZONTALIZE_MANUAL_ANGLE,
    )
    detect_to_frame_matrix = cv2.invertAffineTransform(frame_to_detect_matrix)
    kwargs = supported_kwargs(reader.detect, CRAFT_DETECT_KWARGS)  # type: ignore[attr-defined]
    raw_out = reader.detect(detect_img, **kwargs)  # type: ignore[attr-defined]
    horizontal, free = normalize_detect_output(raw_out)

    mapped: list[tuple[tuple[float, float], list[list[float]]]] = []
    for box in horizontal:
        try:
            pts = horizontal_box_to_points(box)
            original_pts = transform_points_affine(pts, detect_to_frame_matrix)
            mapped.append((reading_order_key_from_detect_points(pts), points_array_to_list(original_pts)))
        except Exception:
            continue

    for box in free:
        try:
            if box is None:
                continue
            pts = np.array(box, dtype=np.float32).reshape(4, 2)
            original_pts = transform_points_affine(pts, detect_to_frame_matrix)
            mapped.append((reading_order_key_from_detect_points(pts), points_array_to_list(original_pts)))
        except Exception:
            continue

    mapped.sort(key=lambda item: item[0])
    return {
        "boxes": [pts for _key, pts in mapped],
        "horizontal_count": len(horizontal),
        "free_count": len(free),
        "steps": steps,
        "detect_shape": tuple(int(v) for v in detect_img.shape[:2]),
        "source_shape": tuple(int(v) for v in frame.shape[:2]),
    }


def _craft_worker_send(message: dict[str, Any]) -> None:
    print(json.dumps(message, ensure_ascii=False), flush=True)


def craft_worker_main() -> int:
    """Subprocess entry point for EasyOCR/CRAFT.

    The GUI talks to this helper with newline-delimited JSON over stdin/stdout.
    Keeping EasyOCR, torch, and OpenCV work in this separate process avoids
    interference with native macOS file dialogs in the main Qt process.
    """
    try:
        import easyocr  # type: ignore

        reader = easyocr.Reader(["en"], detector=True, recognizer=False, gpu=False, verbose=False)
        _craft_worker_send({"type": "ready"})
    except Exception:
        _craft_worker_send({"type": "load_failed", "traceback": traceback.format_exc()})
        return 1

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            request = json.loads(line)
        except Exception:
            _craft_worker_send({"type": "protocol_error", "traceback": traceback.format_exc()})
            continue

        request_type = request.get("type")
        if request_type == "shutdown":
            return 0

        if request_type != "detect":
            _craft_worker_send({"type": "protocol_error", "message": f"Unknown request type: {request_type!r}"})
            continue

        generation = int(request.get("generation", -1))
        image_file = str(request.get("image_file", ""))
        try:
            result = run_craft_detection(reader, image_file)
            _craft_worker_send(
                {
                    "type": "detect_finished",
                    "generation": generation,
                    "image_file": image_file,
                    "result": result,
                }
            )
        except Exception:
            _craft_worker_send(
                {
                    "type": "detect_failed",
                    "generation": generation,
                    "image_file": image_file,
                    "traceback": traceback.format_exc(),
                }
            )

    return 0



def main() -> int:
    return craft_worker_main()


if __name__ == "__main__":
    raise SystemExit(main())
