#!/usr/bin/env python3
"""
parseq_lmdb_exporter_simple_v6_fixed_size_validation_row.py

A minimal PyQt6 utility that converts a directory of images + JSON annotations
into the LMDB structure expected by PARSeq:

data/
├── train/
│   └── real/
│       ├── data.mdb
│       └── lock.mdb
└── val/
    ├── data.mdb
    └── lock.mdb

Expected JSON format:
{
  "image": "page_001.tiff",
  "crops": [
    {
      "label": "text",
      "points": [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
    }
  ]
}

Install:
    pip install PyQt6 lmdb pillow opencv-python numpy

Run:
    python parseq_lmdb_exporter_simple_v6_fixed_size_validation_row.py
"""

from __future__ import annotations

import io
import json
import random
import shutil
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import lmdb
import numpy as np
from PIL import Image, ImageOps
from PyQt6.QtCore import QThread, pyqtSignal
from PyQt6.QtWidgets import (
    QApplication,
    QFileDialog,
    QCheckBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QStackedWidget,
    QVBoxLayout,
    QWidget,
)

# Only use this for trusted local dataset images.
Image.MAX_IMAGE_PIXELS = None

try:
    import cv2
except ImportError as exc:
    raise SystemExit(
        "opencv-python is required for perspective crops.\n"
        "Install with: pip install opencv-python"
    ) from exc


IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp", ".webp"}


@dataclass(frozen=True)
class SampleRef:
    json_path: Path
    image_path: Path
    label: str
    points: list[list[float]]
    json_crop_index: Any


class LmdbWriter:
    def __init__(self, output_dir: Path, map_size: int = 1 << 40, batch_size: int = 1000) -> None:
        output_dir.mkdir(parents=True, exist_ok=True)
        self.output_dir = output_dir
        self.env = lmdb.open(str(output_dir), map_size=map_size)
        self.cache: dict[bytes, bytes] = {}
        self.count = 0
        self.batch_size = batch_size
        self.closed = False

    def add(self, image_bytes: bytes, label: str) -> None:
        self.count += 1
        self.cache[f"image-{self.count:09d}".encode("ascii")] = image_bytes
        self.cache[f"label-{self.count:09d}".encode("ascii")] = label.encode("utf-8")

        if self.count % self.batch_size == 0:
            self.flush()

    def flush(self) -> None:
        if not self.cache:
            return
        with self.env.begin(write=True) as txn:
            for key, value in self.cache.items():
                txn.put(key, value)
        self.cache.clear()

    def close(self) -> None:
        if self.closed:
            return
        self.cache[b"num-samples"] = str(self.count).encode("ascii")
        self.flush()
        self.env.sync()
        self.env.close()
        self.closed = True


def load_image_rgb(path: Path) -> np.ndarray:
    with Image.open(path) as img:
        # Use the first frame/page for multi-page TIFFs.
        try:
            img.seek(0)
        except EOFError:
            pass

        img = ImageOps.exif_transpose(img)
        return np.asarray(img.convert("RGB"))


def order_points(points: np.ndarray) -> np.ndarray:
    """
    Return points ordered as top-left, top-right, bottom-right, bottom-left.
    """
    pts = np.asarray(points, dtype=np.float32)
    if pts.shape != (4, 2):
        raise ValueError(f"points must have shape (4, 2), got {pts.shape}")

    rect = np.zeros((4, 2), dtype=np.float32)

    sums = pts.sum(axis=1)
    rect[0] = pts[np.argmin(sums)]
    rect[2] = pts[np.argmax(sums)]

    diffs = np.diff(pts, axis=1).reshape(-1)
    rect[1] = pts[np.argmin(diffs)]
    rect[3] = pts[np.argmax(diffs)]

    return rect


def perspective_crop_rgb(image_rgb: np.ndarray, points: list[list[float]]) -> np.ndarray:
    rect = order_points(np.asarray(points, dtype=np.float32))
    tl, tr, br, bl = rect

    width_top = np.linalg.norm(tr - tl)
    width_bottom = np.linalg.norm(br - bl)
    height_right = np.linalg.norm(br - tr)
    height_left = np.linalg.norm(bl - tl)

    out_w = max(1, int(round(max(width_top, width_bottom))))
    out_h = max(1, int(round(max(height_right, height_left))))

    dst = np.array(
        [[0, 0], [out_w - 1, 0], [out_w - 1, out_h - 1], [0, out_h - 1]],
        dtype=np.float32,
    )

    matrix = cv2.getPerspectiveTransform(rect, dst)
    return cv2.warpPerspective(
        image_rgb,
        matrix,
        (out_w, out_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )


def encode_png_bytes(image_rgb: np.ndarray) -> bytes:
    buf = io.BytesIO()
    Image.fromarray(image_rgb).save(buf, format="PNG", compress_level=1)
    return buf.getvalue()


def iter_json_docs(data: Any) -> list[dict[str, Any]]:
    if isinstance(data, dict):
        return [data]
    if isinstance(data, list):
        return [x for x in data if isinstance(x, dict)]
    return []


def iter_input_files(input_dir: Path, recursive: bool) -> list[Path]:
    pattern = "**/*" if recursive else "*"
    return [path for path in input_dir.glob(pattern) if path.is_file()]


def build_image_lookup(input_dir: Path, recursive: bool) -> dict[str, Path]:
    lookup: dict[str, Path] = {}
    for path in iter_input_files(input_dir, recursive):
        if path.suffix.lower() in IMAGE_EXTS:
            lookup.setdefault(path.name, path)
    return lookup


def resolve_image_path(image_name: str, json_path: Path, input_dir: Path, image_lookup: dict[str, Path]) -> Path | None:
    candidates = [
        json_path.parent / image_name,
        input_dir / image_name,
    ]

    for candidate in candidates:
        if candidate.exists() and candidate.is_file():
            return candidate

    return image_lookup.get(Path(image_name).name)


def valid_points(points: Any) -> bool:
    if not isinstance(points, list) or len(points) != 4:
        return False
    for point in points:
        if not isinstance(point, list | tuple) or len(point) != 2:
            return False
        try:
            float(point[0])
            float(point[1])
        except (TypeError, ValueError):
            return False
    return True


def collect_samples(input_dir: Path, recursive: bool) -> tuple[list[SampleRef], dict[str, int], list[str]]:
    stats = {
        "json_files": 0,
        "skipped_empty_label": 0,
        "skipped_bad_json": 0,
        "skipped_bad_crop": 0,
        "skipped_missing_image": 0,
    }
    warnings: list[str] = []
    samples: list[SampleRef] = []

    json_pattern = "**/*.json" if recursive else "*.json"
    json_paths = sorted(path for path in input_dir.glob(json_pattern) if path.is_file())
    image_lookup = build_image_lookup(input_dir, recursive)

    for json_path in json_paths:
        stats["json_files"] += 1

        try:
            data = json.loads(json_path.read_text(encoding="utf-8"))
        except Exception as exc:
            stats["skipped_bad_json"] += 1
            warnings.append(f"Bad JSON: {json_path.name}: {exc}")
            continue

        for doc in iter_json_docs(data):
            image_name = doc.get("image")
            crops = doc.get("crops")

            if not isinstance(image_name, str) or not image_name.strip():
                stats["skipped_missing_image"] += 1
                warnings.append(f"Missing required 'image' field in {json_path.name}")
                continue

            if not isinstance(crops, list):
                stats["skipped_bad_json"] += 1
                warnings.append(f"Missing/invalid 'crops' list in {json_path.name}")
                continue

            image_path = resolve_image_path(image_name, json_path, input_dir, image_lookup)
            if image_path is None:
                stats["skipped_missing_image"] += len(crops)
                warnings.append(f"Image not found for {json_path.name}: {image_name}")
                continue

            for pos, crop in enumerate(crops):
                if not isinstance(crop, dict):
                    stats["skipped_bad_crop"] += 1
                    continue

                label = crop.get("label", "")
                if label is None:
                    label = ""
                label = str(label)

                if label == "":
                    stats["skipped_empty_label"] += 1
                    continue

                points = crop.get("points")
                if not valid_points(points):
                    stats["skipped_bad_crop"] += 1
                    continue

                samples.append(
                    SampleRef(
                        json_path=json_path,
                        image_path=image_path,
                        label=label,
                        points=points,
                        json_crop_index=crop.get("index", pos),
                    )
                )

    return samples, stats, warnings



def merge_stats(*stats_dicts: dict[str, int]) -> dict[str, int]:
    merged: dict[str, int] = {}
    for stats in stats_dicts:
        for key, value in stats.items():
            merged[key] = merged.get(key, 0) + int(value)
    return merged


class ExportWorker(QThread):
    progress = pyqtSignal(int, int, str)
    done = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(
        self,
        input_dir: Path,
        output_root: Path,
        val_percent: int,
        recursive: bool,
        separate_val_dir: Path | None = None,
    ) -> None:
        super().__init__()
        self.input_dir = input_dir
        self.output_root = output_root
        self.val_percent = val_percent
        self.recursive = recursive
        self.separate_val_dir = separate_val_dir

    def run(self) -> None:
        train_writer: LmdbWriter | None = None
        val_writer: LmdbWriter | None = None

        try:
            data_dir = self.output_root / "data"
            train_dir = data_dir / "train" / "real"
            val_dir = data_dir / "val"

            if self.separate_val_dir is None:
                self.progress.emit(0, 0, "Scanning JSON files...")
                samples, stats, warnings = collect_samples(self.input_dir, self.recursive)

                if not samples:
                    raise RuntimeError("No valid labeled crops were found.")

                indices = list(range(len(samples)))
                rng = random.Random(12345)
                rng.shuffle(indices)

                val_count_target = int(round(len(samples) * (self.val_percent / 100.0)))
                val_indices = set(indices[:val_count_target])

                train_samples = [sample for i, sample in enumerate(samples) if i not in val_indices]
                val_samples = [sample for i, sample in enumerate(samples) if i in val_indices]

                result_stats = stats
                result_warnings = warnings
                mode_label = f"Random {self.val_percent}% validation split from input directory"
                train_json_files = stats["json_files"]
                val_json_files = None
            else:
                self.progress.emit(0, 0, "Scanning training JSON files...")
                train_samples, train_stats, train_warnings = collect_samples(self.input_dir, self.recursive)

                self.progress.emit(0, 0, "Scanning validation JSON files...")
                val_samples, val_stats, val_warnings = collect_samples(self.separate_val_dir, self.recursive)

                if not train_samples:
                    raise RuntimeError("No valid labeled training crops were found in the input directory.")

                if not val_samples:
                    raise RuntimeError("No valid labeled validation crops were found in the validation directory.")

                result_stats = merge_stats(train_stats, val_stats)
                result_warnings = [f"Train: {w}" for w in train_warnings] + [f"Val: {w}" for w in val_warnings]
                mode_label = "Separate validation directory"
                train_json_files = train_stats["json_files"]
                val_json_files = val_stats["json_files"]

            # Replace only the LMDB target directories this tool owns.
            for target in (train_dir, val_dir):
                if target.exists():
                    shutil.rmtree(target)

            train_writer = LmdbWriter(train_dir)
            val_writer = LmdbWriter(val_dir)

            total_to_export = len(train_samples) + len(val_samples)
            processed = 0
            processed = self._write_samples(
                train_samples,
                train_writer,
                processed,
                total_to_export,
                "train",
            )
            processed = self._write_samples(
                val_samples,
                val_writer,
                processed,
                total_to_export,
                "val",
            )

            train_writer.close()
            val_writer.close()

            result = {
                **result_stats,
                "mode_label": mode_label,
                "total_samples": total_to_export,
                "train_samples": train_writer.count,
                "val_samples": val_writer.count,
                "train_json_files": train_json_files,
                "val_json_files": val_json_files,
                "input_dir": str(self.input_dir),
                "separate_val_dir": str(self.separate_val_dir) if self.separate_val_dir is not None else "",
                "output_data_dir": str(data_dir),
                "train_dir": str(train_dir),
                "val_dir": str(val_dir),
                "warnings": result_warnings[:10],
                "warning_count": len(result_warnings),
            }
            self.done.emit(result)

        except Exception:
            self.failed.emit(traceback.format_exc())
        finally:
            # If an exception happened before normal close, close the environments.
            for writer in (train_writer, val_writer):
                if writer is not None and not writer.closed:
                    try:
                        writer.close()
                    except Exception:
                        pass

    def _write_samples(
        self,
        samples: list[SampleRef],
        writer: LmdbWriter,
        processed: int,
        total: int,
        subset_name: str,
    ) -> int:
        current_image_path: Path | None = None
        current_image: np.ndarray | None = None

        for sample in samples:
            if current_image_path != sample.image_path:
                current_image_path = sample.image_path
                try:
                    current_image = load_image_rgb(sample.image_path)
                except Image.DecompressionBombError as e:
                    raise RuntimeError(
                        f"Oversized source image blocked by Pillow:\n"
                        f"{sample.image_path}\n\n"
                        f"{e}\n\n"
                        f"Best fix: split the generated augmentation sheet into smaller image/json pairs."
                    ) from e

            if current_image is None:
                raise RuntimeError(f"Could not load image: {sample.image_path}")

            crop_rgb = perspective_crop_rgb(current_image, sample.points)
            image_bytes = encode_png_bytes(crop_rgb)
            writer.add(image_bytes, sample.label)

            processed += 1
            if processed == total or processed % 25 == 0:
                self.progress.emit(
                    processed,
                    total,
                    f"Exported {processed:,} / {total:,} crops ({subset_name})...",
                )

        return processed


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.worker: ExportWorker | None = None
        self._controls_enabled = True

        self.setWindowTitle("Simple PARSeq LMDB Exporter")
        self.resize(430, 240)

        self.input_edit = QLineEdit()
        self.output_edit = QLineEdit()
        self.val_dir_edit = QLineEdit()

        self.input_browse = QPushButton("Browse...")
        self.output_browse = QPushButton("Browse...")
        self.val_dir_browse = QPushButton("Browse...")

        self.validation_label = QLabel("Validation:")
        self.val_spin = QSpinBox()
        self.val_spin.setRange(0, 50)
        self.val_spin.setValue(25)
        self.val_spin.setSuffix("%")
        self.val_split_page = QWidget()
        val_split_layout = QHBoxLayout()
        val_split_layout.setContentsMargins(0, 0, 0, 0)
        val_split_layout.addWidget(self.val_spin)
        val_split_layout.addStretch(1)
        self.val_split_page.setLayout(val_split_layout)

        self.separate_val_check = QCheckBox("Use separate validation directory")
        self.separate_val_check.setChecked(False)
        self.separate_val_check.setToolTip(
            "Off: create validation samples by splitting the input directory. "
            "On: use the input directory for train and a separate directory for validation."
        )

        self.val_dir_widget = self._with_button(self.val_dir_edit, self.val_dir_browse)
        self.validation_stack = QStackedWidget()
        self.validation_stack.addWidget(self.val_split_page)
        self.validation_stack.addWidget(self.val_dir_widget)

        self.recursive_check = QCheckBox("Search subfolders")
        self.recursive_check.setChecked(False)
        self.recursive_check.setToolTip("Off: only scan files directly inside each selected directory. On: scan nested folders too.")

        self.progress = QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)

        self.status = QLabel("")
        self.export_btn = QPushButton("Export LMDB")

        form = QFormLayout()
        form.addRow("Input directory:", self._with_button(self.input_edit, self.input_browse))
        form.addRow("Output root:", self._with_button(self.output_edit, self.output_browse))
        form.addRow("", self.separate_val_check)
        form.addRow(self.validation_label, self.validation_stack)
        form.addRow("", self.recursive_check)

        layout = QVBoxLayout()
        layout.addLayout(form)
        layout.addWidget(self.progress)
        layout.addWidget(self.status)
        layout.addWidget(self.export_btn)

        central = QWidget()
        central.setLayout(layout)
        self.setCentralWidget(central)

        self.input_browse.clicked.connect(self.choose_input_dir)
        self.output_browse.clicked.connect(self.choose_output_dir)
        self.val_dir_browse.clicked.connect(self.choose_val_dir)
        self.separate_val_check.toggled.connect(self.update_validation_controls)
        self.export_btn.clicked.connect(self.start_export)

        self.update_validation_controls()

    def _with_button(self, edit: QLineEdit, button: QPushButton) -> QWidget:
        box = QWidget()
        layout = QHBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(edit, 1)
        layout.addWidget(button)
        box.setLayout(layout)
        return box

    def _existing_dir_from_text(self, text: str) -> Path | None:
        if not text.strip():
            return None
        path = Path(text).expanduser()
        if path.exists() and path.is_dir():
            return path
        if path.parent.exists() and path.parent.is_dir():
            return path.parent
        return None

    def choose_input_dir(self) -> None:
        start_dir = self._existing_dir_from_text(self.input_edit.text()) or Path.home()
        path = QFileDialog.getExistingDirectory(self, "Choose input directory", str(start_dir))
        if path:
            self.input_edit.setText(path)

    def choose_output_dir(self) -> None:
        start_dir = self._existing_dir_from_text(self.output_edit.text()) or Path.home()
        path = QFileDialog.getExistingDirectory(self, "Choose output root", str(start_dir))
        if path:
            self.output_edit.setText(path)

    def choose_val_dir(self) -> None:
        start_dir = (
            self._existing_dir_from_text(self.input_edit.text())
            or self._existing_dir_from_text(self.val_dir_edit.text())
            or Path.home()
        )
        path = QFileDialog.getExistingDirectory(self, "Choose validation directory", str(start_dir))
        if path:
            self.val_dir_edit.setText(path)

    def update_validation_controls(self) -> None:
        use_separate_val = self.separate_val_check.isChecked()

        # Keep the same form row visible in both modes so toggling the checkbox
        # does not make the window resize or shift. Only the row contents swap.
        self.validation_stack.setCurrentWidget(
            self.val_dir_widget if use_separate_val else self.val_split_page
        )

        self.val_spin.setEnabled(self._controls_enabled and not use_separate_val)
        self.val_dir_edit.setEnabled(self._controls_enabled and use_separate_val)
        self.val_dir_browse.setEnabled(self._controls_enabled and use_separate_val)

    def start_export(self) -> None:
        input_dir = Path(self.input_edit.text()).expanduser()
        output_root = Path(self.output_edit.text()).expanduser()
        separate_val_dir: Path | None = None

        if not input_dir.exists() or not input_dir.is_dir():
            QMessageBox.warning(self, "Missing input", "Choose a valid input directory.")
            return

        if not output_root.exists() or not output_root.is_dir():
            QMessageBox.warning(self, "Missing output", "Choose a valid output root directory.")
            return

        if self.separate_val_check.isChecked():
            separate_val_dir = Path(self.val_dir_edit.text()).expanduser()
            if not separate_val_dir.exists() or not separate_val_dir.is_dir():
                QMessageBox.warning(self, "Missing validation", "Choose a valid validation directory.")
                return

            if input_dir.resolve() == separate_val_dir.resolve():
                QMessageBox.warning(
                    self,
                    "Validation matches input",
                    "Choose a validation directory that is different from the input directory.",
                )
                return

        data_dir = output_root / "data"
        if (data_dir / "train" / "real" / "data.mdb").exists() or (data_dir / "val" / "data.mdb").exists():
            answer = QMessageBox.question(
                self,
                "Overwrite LMDB?",
                "Existing PARSeq LMDB files were found under output_root/data.\n\n"
                "Replace data/train/real and data/val?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No,
            )
            if answer != QMessageBox.StandardButton.Yes:
                return

        self.set_controls_enabled(False)
        self.progress.setValue(0)
        self.status.setText("Starting export...")

        self.worker = ExportWorker(
            input_dir,
            output_root,
            self.val_spin.value(),
            self.recursive_check.isChecked(),
            separate_val_dir,
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.done.connect(self.on_done)
        self.worker.failed.connect(self.on_failed)
        self.worker.start()

    def set_controls_enabled(self, enabled: bool) -> None:
        self._controls_enabled = enabled

        self.input_edit.setEnabled(enabled)
        self.output_edit.setEnabled(enabled)
        self.input_browse.setEnabled(enabled)
        self.output_browse.setEnabled(enabled)
        self.separate_val_check.setEnabled(enabled)
        self.recursive_check.setEnabled(enabled)
        self.export_btn.setEnabled(enabled)

        self.update_validation_controls()

    def on_progress(self, done: int, total: int, message: str) -> None:
        if total > 0:
            if self.progress.minimum() == 0 and self.progress.maximum() == 0:
                self.progress.setRange(0, 100)
            self.progress.setValue(int(100 * done / total))
        else:
            self.progress.setRange(0, 0)

        self.status.setText(message)

    def on_done(self, result: dict) -> None:
        self.progress.setRange(0, 100)
        self.progress.setValue(100)
        self.set_controls_enabled(True)

        warning_text = ""
        if result["warning_count"]:
            warning_text = "\n\nWarnings shown below are limited to the first 10:\n" + "\n".join(result["warnings"])

        if result["val_json_files"] is None:
            json_summary = f"JSON files: {result['json_files']:,}\n"
        else:
            json_summary = (
                f"Train JSON files: {result['train_json_files']:,}\n"
                f"Val JSON files: {result['val_json_files']:,}\n"
                f"Total JSON files: {result['json_files']:,}\n"
            )

        msg = (
            "Done.\n\n"
            f"Mode: {result['mode_label']}\n"
            f"{json_summary}"
            f"Total samples: {result['total_samples']:,}\n"
            f"Train samples: {result['train_samples']:,}\n"
            f"Val samples: {result['val_samples']:,}\n\n"
            f"Created:\n"
            f"{result['train_dir']}\n"
            f"{result['val_dir']}\n\n"
            f"Skipped empty labels: {result['skipped_empty_label']:,}\n"
            f"Skipped bad crops: {result['skipped_bad_crop']:,}\n"
            f"Skipped missing images: {result['skipped_missing_image']:,}"
            f"{warning_text}"
        )

        self.status.setText(
            f"Done: {result['train_samples']:,} train, {result['val_samples']:,} val."
        )
        QMessageBox.information(self, "Export complete", msg)

    def on_failed(self, error_text: str) -> None:
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.set_controls_enabled(True)
        self.status.setText("Export failed.")
        QMessageBox.critical(self, "Export failed", error_text)

def main() -> int:
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
