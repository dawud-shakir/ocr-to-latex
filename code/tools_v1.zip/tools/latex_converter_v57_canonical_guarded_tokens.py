#!/usr/bin/env python3
"""
latex_converter_v32_discovered_charset_tokens_tooltips.py

Small PyQt6 utility for converting JSON `label` fields among several
math-label conventions: LaTeX, plain ASCII math, UnicodeMath-style linear
notation, academic Unicode, and readable Unicode symbols.

Input JSON shape can be like:
{
  "crops": [
    {"index": 1, "label": "δ₁ → q₂", "points": [...]}
  ]
}

The app recursively finds every dictionary key named "label" whose value is a
string, previews the conversion, and writes converted JSON copies to an output
folder. Originals are not overwritten unless you intentionally choose the same
output folder and provide a filename suffix.

Recommended install:
    pip install PyQt6

Run:
    python latex_converter_v32_discovered_charset_tokens_tooltips.py
"""

from __future__ import annotations

import ast
import hashlib
import json
import random
import re
from collections import Counter
import shutil
import sys
import time
import unicodedata
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Callable, Iterable

from PyQt6.QtCore import Qt, QThread, QTimer, pyqtSignal
from PyQt6.QtGui import QColor, QFont, QKeySequence, QShortcut, QTextCharFormat, QTextCursor
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QListWidget,
    QListWidgetItem,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QProgressBar,
    QSpinBox,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

APP_TITLE = "JSON Label String Token Converter"
DEFAULT_OUTPUT_FOLDER_NAME = "LaTeX version"
DEFAULT_INPUT_JSON_FOLDER = Path("/Users/macintosh/UNM/Demos/ocr-to-latex/data")
MAX_FILTER_VALUE = 1_000_000
BALANCE_RANDOM_SEED = 0
DEFAULT_MIN_CLASS_COUNT = 5
MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN = "Auto: lower median"
MAX_PER_LABEL_MODE_AUTO_P25 = "Auto: 25th percentile"
MAX_PER_LABEL_MODE_AUTO_MEDIAN = "Auto: median"
MAX_PER_LABEL_MODE_AUTO_MIN_ELIGIBLE = "Auto: min eligible class count"
MAX_PER_LABEL_MODE_MANUAL = "Manual"
MAX_PER_LABEL_MODE_AUTO = MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN  # backward-compatible alias
MAX_PER_LABEL_MODES = (
    MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN,
    MAX_PER_LABEL_MODE_AUTO_P25,
    MAX_PER_LABEL_MODE_AUTO_MEDIAN,
    MAX_PER_LABEL_MODE_AUTO_MIN_ELIGIBLE,
    MAX_PER_LABEL_MODE_MANUAL,
)
MAX_PER_LABEL_MODE_TOOLTIPS = {
    MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN: (
        "Best default. Conservative, simple, and usually gives a balanced result without being too aggressive."
    ),
    MAX_PER_LABEL_MODE_AUTO_P25: (
        "More aggressive than lower median. Useful if you want a smaller, tighter dataset and want to cap common labels harder."
    ),
    MAX_PER_LABEL_MODE_AUTO_MEDIAN: (
        "Slightly less aggressive. Keeps more examples from common classes.\nGood if you have enough storage/training time and do not want to throw away as much."
    ),
    MAX_PER_LABEL_MODE_AUTO_MIN_ELIGIBLE: (
        "Most perfectly balanced: every eligible class is capped at the smallest eligible class count. But it can be too harsh.\nExample: if eligible counts are 4, 20, 100, it caps everything at 4, which may throw away too much."
    ),
    MAX_PER_LABEL_MODE_MANUAL: (
        "Use a fixed maximum number of entries to keep per output-label class."
    ),
}
CHARSET_TEMPLATE_TOOLTIP = (
    "What kind of charset file am I trying to produce, and what ordering/token list should I start from?"
)
CHARSET_TYPE_TOOLTIP = (
    "Choose whether the generated config is character-only or uses string + character tokens. Auto detects from the template."
)
CHARSET_DISCOVER_TOKENS_TOOLTIP = (
    "Add LaTeX-like tokens found in the current output labels even if they are missing from the template latex_tokens list."
)
CHARSET_GENERATE_TOOLTIP = (
    "Generate a charset config preview from the labels that would be exported with the current options."
)
CHARSET_BROWSE_TOOLTIP = (
    "Choose a PARSeq charset YAML template. Browse starts in parseq/configs/charset when it can be found."
)
CHARSET_TEMPLATE_SOURCE_TOOLTIP = (
    "Choose Auto for the recommended template, Last used to reuse your previous custom file, "
    "a built-in preset, or Custom file when you need an exact repo config."
)
CHARSET_TEMPLATE_MODE_AUTO = "Auto"
CHARSET_TEMPLATE_MODE_LAST_USED = "Last used"
CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID = "Built-in: LaTeX hybrid"
CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE = "Built-in: LaTeX hybrid no space"
CHARSET_TEMPLATE_MODE_BUILTIN_94_FULL = "Built-in: 94 full"
CHARSET_TEMPLATE_MODE_BUILTIN_62_MIXED_CASE = "Built-in: 62 mixed-case"
CHARSET_TEMPLATE_MODE_BUILTIN_36_LOWERCASE = "Built-in: 36 lowercase"
CHARSET_TEMPLATE_MODE_CUSTOM = "Custom file..."
CHARSET_TEMPLATE_MODE_CHOICES = (
    CHARSET_TEMPLATE_MODE_AUTO,
    CHARSET_TEMPLATE_MODE_LAST_USED,
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID,
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE,
    CHARSET_TEMPLATE_MODE_BUILTIN_94_FULL,
    CHARSET_TEMPLATE_MODE_BUILTIN_62_MIXED_CASE,
    CHARSET_TEMPLATE_MODE_BUILTIN_36_LOWERCASE,
    CHARSET_TEMPLATE_MODE_CUSTOM,
)
BUILTIN_CHARSET_TEMPLATE_TEXTS: dict[str, str] = {
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID: '# @package _global_\n# Character fallback (62 alphanumeric + 32 punctuation) + selected multi-character LaTeX command tokens.\n#\n# `max_label_length` is now measured in string + character tokens when tokenizer_type is\n# latex_hybrid. For example, \\frac{x+1}{y} becomes:\n#   [\\frac] [{] [x] [+] [1] [}] [{] [y] [}]\nmodel:\n  tokenizer_type: latex_hybrid\n  charset_train: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\\"#$%&\'()*+,-./:;<=>?@[\\\\]^_`{|}~ " # includes space\n  latex_tokens:\n    - "_{"\n    - "^{"\n    - "\\\\frac"\n    - "\\\\sqrt"\n    - "\\\\sum"\n    - "\\\\int"\n    - "\\\\lim"\n    - "\\\\max"\n    - "\\\\min"\n    - "\\\\sin"\n    - "\\\\cos"\n    - "\\\\tan"\n    - "\\\\log"\n    - "\\\\ln"\n    - "\\\\alpha"\n    - "\\\\beta"\n    - "\\\\gamma"\n    - "\\\\delta"\n    - "\\\\epsilon"\n    - "\\\\theta"\n    - "\\\\lambda"\n    - "\\\\mu"\n    - "\\\\pi"\n    - "\\\\rho"\n    - "\\\\sigma"\n    - "\\\\phi"\n    - "\\\\omega"\n    - "\\\\infty"\n    - "\\\\leq"\n    - "\\\\geq"\n    - "\\\\neq"\n    - "\\\\cdot"\n    - "\\\\times"\n    - "\\\\left"\n    - "\\\\right"\n',
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE: '# @package _global_\n# Character fallback (62 alphanumeric + 32 punctuation) + selected multi-character LaTeX command tokens.\n#\n# `max_label_length` is now measured in string + character tokens when tokenizer_type is\n# latex_hybrid. For example, \\frac{x+1}{y} becomes:\n#   [\\frac] [{] [x] [+] [1] [}] [{] [y] [}]\nmodel:\n  tokenizer_type: latex_hybrid\n  charset_train: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\\"#$%&\'()*+,-./:;<=>?@[\\\\]^_`{|}~" # no space\n  latex_tokens:\n    - "_{"\n    - "^{"\n    - "\\\\frac"\n    - "\\\\sqrt"\n    - "\\\\sum"\n    - "\\\\int"\n    - "\\\\lim"\n    - "\\\\max"\n    - "\\\\min"\n    - "\\\\sin"\n    - "\\\\cos"\n    - "\\\\tan"\n    - "\\\\log"\n    - "\\\\ln"\n    - "\\\\alpha"\n    - "\\\\beta"\n    - "\\\\gamma"\n    - "\\\\delta"\n    - "\\\\epsilon"\n    - "\\\\theta"\n    - "\\\\lambda"\n    - "\\\\mu"\n    - "\\\\pi"\n    - "\\\\rho"\n    - "\\\\sigma"\n    - "\\\\phi"\n    - "\\\\omega"\n    - "\\\\infty"\n    - "\\\\leq"\n    - "\\\\geq"\n    - "\\\\neq"\n    - "\\\\cdot"\n    - "\\\\times"\n    - "\\\\left"\n    - "\\\\right"\n',
    CHARSET_TEMPLATE_MODE_BUILTIN_94_FULL: '# @package _global_\nmodel:\n  charset_train: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!\\"#$%&\'()*+,-./:;<=>?@[\\\\]^_`{|}~"\n',
    CHARSET_TEMPLATE_MODE_BUILTIN_62_MIXED_CASE: '# @package _global_\nmodel:\n  charset_train: "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"\n',
    CHARSET_TEMPLATE_MODE_BUILTIN_36_LOWERCASE: '# @package _global_\nmodel:\n  charset_train: "0123456789abcdefghijklmnopqrstuvwxyz"\n',
}
BUILTIN_CHARSET_TEMPLATE_FILENAMES: dict[str, tuple[str, ...]] = {
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID: ("latex_hybrid.yaml",),
    CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE: ("latex_hybrid_no_space.yaml",),
    CHARSET_TEMPLATE_MODE_BUILTIN_94_FULL: ("94_full.yaml", "94_full(1).yaml"),
    CHARSET_TEMPLATE_MODE_BUILTIN_62_MIXED_CASE: ("62_mixed-case.yaml",),
    CHARSET_TEMPLATE_MODE_BUILTIN_36_LOWERCASE: ("36_lowercase.yaml",),
}


@dataclass(frozen=True)
class CachedCharsetTemplate:
    """Cached text for a built-in charset-template choice.

    A built-in choice can be backed by a nearby repo template file when one is
    found, or by the script's embedded fallback text when no file is available.
    """

    mode: str
    text: str
    source: str
    path: Path | None = None
    file_signature: tuple[int, int] | None = None


BUILTIN_CHARSET_TEMPLATE_CACHE: dict[str, CachedCharsetTemplate] = {}


def charset_template_file_signature(path: Path) -> tuple[int, int] | None:
    """Return a small signature that changes when a template file changes."""
    try:
        stat = path.stat()
    except OSError:
        return None
    return stat.st_mtime_ns, stat.st_size


def read_charset_template_file_text(path: Path) -> tuple[str, tuple[int, int]] | None:
    """Read a charset template file and return text plus its file signature."""
    signature = charset_template_file_signature(path)
    if signature is None:
        return None
    try:
        return path.read_text(encoding="utf-8"), signature
    except Exception:  # noqa: BLE001
        return None


def fallback_cached_charset_template(mode: str) -> CachedCharsetTemplate | None:
    text = BUILTIN_CHARSET_TEMPLATE_TEXTS.get(mode)
    if text is None:
        return None
    return CachedCharsetTemplate(
        mode=mode,
        text=text,
        source=f"Embedded fallback: {mode}",
        path=None,
        file_signature=None,
    )


def load_builtin_charset_templates() -> None:
    """Read and cache repo-backed built-in charset templates.

    This runs when the app starts and again before charset previews. Built-in
    choices prefer nearby repo files such as parseq/configs/charset/latex_hybrid.yaml;
    embedded text is only a fallback when no matching file is found/readable.
    """
    for mode, filenames in BUILTIN_CHARSET_TEMPLATE_FILENAMES.items():
        cached: CachedCharsetTemplate | None = None
        path = find_charset_template_file_by_names(filenames)
        if path is not None:
            loaded = read_charset_template_file_text(path)
            if loaded is not None:
                template_text, signature = loaded
                cached = CachedCharsetTemplate(
                    mode=mode,
                    text=template_text,
                    source=str(path),
                    path=path,
                    file_signature=signature,
                )
        if cached is None:
            cached = fallback_cached_charset_template(mode)
        if cached is not None:
            BUILTIN_CHARSET_TEMPLATE_CACHE[mode] = cached


def refresh_builtin_charset_templates() -> bool:
    """Refresh cached built-in templates whose backing files changed."""
    if not BUILTIN_CHARSET_TEMPLATE_CACHE:
        load_builtin_charset_templates()
        return bool(BUILTIN_CHARSET_TEMPLATE_CACHE)

    changed = False
    for mode in BUILTIN_CHARSET_TEMPLATE_FILENAMES:
        cached = BUILTIN_CHARSET_TEMPLATE_CACHE.get(mode)
        if cached is None:
            load_builtin_charset_templates()
            return True

        # Embedded fallbacks have no file to refresh. Avoid repeated repo scans.
        if cached.path is None:
            continue

        signature = charset_template_file_signature(cached.path)
        if signature == cached.file_signature:
            continue

        loaded = read_charset_template_file_text(cached.path)
        if loaded is None:
            fallback = fallback_cached_charset_template(mode)
            if fallback is not None:
                BUILTIN_CHARSET_TEMPLATE_CACHE[mode] = fallback
                changed = True
            continue

        template_text, new_signature = loaded
        BUILTIN_CHARSET_TEMPLATE_CACHE[mode] = CachedCharsetTemplate(
            mode=mode,
            text=template_text,
            source=str(cached.path),
            path=cached.path,
            file_signature=new_signature,
        )
        changed = True

    return changed


def cached_builtin_charset_template(mode: str) -> CachedCharsetTemplate | None:
    """Return cached built-in text, loading/refreshing the cache if needed."""
    if not BUILTIN_CHARSET_TEMPLATE_CACHE:
        load_builtin_charset_templates()
    refresh_builtin_charset_templates()
    cached = BUILTIN_CHARSET_TEMPLATE_CACHE.get(mode)
    if cached is not None:
        return cached
    fallback = fallback_cached_charset_template(mode)
    if fallback is not None:
        BUILTIN_CHARSET_TEMPLATE_CACHE[mode] = fallback
    return fallback
APP_SETTINGS_PATH = Path.home() / ".json_label_hybrid_converter_settings.json"

TOKEN_AUDIT_MODE_AUTO = "Auto"
TOKEN_AUDIT_MODE_HYBRID = "String + character tokens"
TOKEN_AUDIT_MODE_CHARS = "Characters only"
TOKEN_AUDIT_MODES = (
    TOKEN_AUDIT_MODE_AUTO,
    TOKEN_AUDIT_MODE_HYBRID,
    TOKEN_AUDIT_MODE_CHARS,
)

OLD_TOKEN_OCCURRENCE_BALANCE_MODE_HARD_RANGE = "Hard min/max"
TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT = "Current adaptive (original)"
TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED = "Optimized adaptive"
TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS = "Fast two-pass"
TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL = "Prune from full set"
# Backward-compatible names used by earlier code/settings.
TOKEN_OCCURRENCE_BALANCE_MODE_HARD_RANGE = TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT
TOKEN_OCCURRENCE_BALANCE_MODE_SOFT = TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT
TOKEN_OCCURRENCE_BALANCE_MODES = (
    TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT,
    TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED,
    TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS,
    TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL,
)
TOKEN_OCCURRENCE_BALANCE_TOOLTIPS = {
    TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT: (
        "Original adaptive greedy scorer. Re-scores the front row of each label queue after every selection. "
        "Best for preserving the existing behavior, but usually slowest."
    ),
    TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED: (
        "Same adaptive greedy idea, but precomputes row IDs/token Counters and uses queue indices instead of pop(0). "
        "This should stay close to the original behavior while reducing repeated work."
    ),
    TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS: (
        "Faster static-score sampler. It sorts rows once, keeps at most one row per label first, then fills duplicates. "
        "Hard token max is still enforced, but choices are less adaptive."
    ),
    TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL: (
        "Starts from the full eligible set and greedily removes whole rows until token totals and per-label caps fit. "
        "Removal scoring favors rows that reduce over-cap tokens while protecting rare or near-minimum tokens."
    ),
}

# Literal LaTeX-special characters from the original label can optionally be
# escaped without escaping LaTeX syntax generated by this converter.
# The app no longer reports unsupported-character warnings in the preview; the
# table focuses on conversion changes only.

# Direct Unicode symbol -> LaTeX text replacements.
# These replacements use ASCII-friendly LaTeX strings.
SYMBOL_TO_LATEX: dict[str, str] = {
    # Arrows
    "→": r"\to",
    "←": r"\leftarrow",
    "↑": r"\uparrow",
    "↓": r"\downarrow",
    "⇓": r"\Downarrow",
    "⇒": r"\Rightarrow",
    "↔": r"\leftrightarrow",

    # Sets
    "∅": r"\emptyset",
    "∈": r"\in",
    "∉": r"\notin",
    "⊆": r"\subseteq",
    "⊂": r"\subset",
    "∪": r"\cup",
    "∩": r"\cap",
    "𝔼": r"\mathbb{E}",
    "ℝ": r"\mathbb{R}",
    "ℤ": r"\mathbb{Z}",
    "ℕ": r"\mathbb{N}",
    "ℂ": r"\mathbb{C}",
    "ℚ": r"\mathbb{Q}",

    # Logic
    "∀": r"\forall",
    "∃": r"\exists",
    "∧": r"\land",
    "∨": r"\lor",
    "¬": r"\neg",
    "⊢": r"\vdash",
    "⊨": r"\models",
    "⊥": r"\bot",

    # Greek uppercase
    "Α": "A",          # no separate standard LaTeX command normally needed
    "Β": "B",
    "Γ": r"\Gamma",
    "Δ": r"\Delta",
    "Ε": "E",
    "Ζ": "Z",
    "Η": "H",
    "Θ": r"\Theta",
    "Ι": "I",
    "Κ": "K",
    "Λ": r"\Lambda",
    "Μ": "M",
    "Ν": "N",
    "Ξ": r"\Xi",
    "Ο": "O",
    "Π": r"\Pi",
    "Ρ": "P",
    "Σ": r"\Sigma",
    "Τ": "T",
    "Υ": r"\Upsilon",
    "Φ": r"\Phi",
    "Χ": "X",
    "Ψ": r"\Psi",
    "Ω": r"\Omega",

    # Greek lowercase
    "α": r"\alpha",
    "β": r"\beta",
    "γ": r"\gamma",
    "δ": r"\delta",
    "ε": r"\epsilon",
    "ζ": r"\zeta",
    "η": r"\eta",
    "θ": r"\theta",
    "ι": r"\iota",
    "κ": r"\kappa",
    "λ": r"\lambda",
    "μ": r"\mu",
    "ν": r"\nu",
    "ξ": r"\xi",
    "ο": "o",          # Greek omicron is visually/semantically close to o
    "π": r"\pi",
    "ρ": r"\rho",
    "σ": r"\sigma",
    "ς": r"\varsigma",
    "τ": r"\tau",
    "υ": r"\upsilon",
    "φ": r"\phi",
    "χ": r"\chi",
    "ψ": r"\psi",
    "ω": r"\omega",
    "ϑ": r"\vartheta",

    # Relations
    "≤": r"\leq",
    "≥": r"\geq",
    "≠": r"\neq",
    "≡": r"\equiv",
    "⟨": r"\langle",
    "⟩": r"\rangle",

    # Math / algebra
    "±": r"\pm",
    "×": r"\times",
    "⋅": r"\cdot",
    "÷": r"\div",
    "√": r"\sqrt{}",
    "⎯": "-",
    "°": r"^{\circ}",
    "‖": r"\Vert",
    "⊗": r"\otimes",
    "⊕": r"\oplus",
    "⊙": r"\odot",
    "⟂": r"\perp",
    "∥": r"\parallel",
    "∇": r"\nabla",
    "∂": r"\partial",
    "∞": r"\infty",
    "†": r"\dagger",

    # Dots / bullets / ellipses
    "·": r"\cdot",
    "∙": r"\bullet",
    "•": r"\bullet",
    "◦": r"\circ",
    "∘": r"\circ",
    "˙": r"\dot{}",
    "…": r"\ldots",
    "⋯": r"\cdots",
    "⋮": r"\vdots",
    "⋰": r"\iddots",
    "⋱": r"\ddots",
}

SUBSCRIPT_CHARS: dict[str, str] = {
    "₍": "(", "₎": ")", "₊": "+", "₋": "-", "₌": "=",
    "ₐ": "a", "ₑ": "e", "ₕ": "h", "ᵢ": "i", "ⱼ": "j",
    "ₖ": "k", "ₗ": "l", "ₘ": "m", "ₙ": "n", "ₒ": "o",
    "ₚ": "p", "ᵣ": "r", "ₛ": "s", "ₜ": "t", "ᵤ": "u",
    "ᵥ": "v", "ₓ": "x", "ᵧ": "y", "ₔ": "schwa",
    "ᵦ": r"\beta", "ᵨ": r"\rho", "ᵩ": r"\phi", "ᵪ": r"\chi",
    "₀": "0", "₁": "1", "₂": "2", "₃": "3", "₄": "4",
    "₅": "5", "₆": "6", "₇": "7", "₈": "8", "₉": "9",
}

SUPERSCRIPT_CHARS: dict[str, str] = {
    "⁽": "(", "⁾": ")", "⁺": "+", "⁻": "-", "⁼": "=",
    "ᴬ": "A", "ᴮ": "B", "ᴰ": "D", "ᴱ": "E", "ᴳ": "G",
    "ᴴ": "H", "ᴵ": "I", "ᴶ": "J", "ᴷ": "K", "ᴸ": "L",
    "ᴹ": "M", "ᴺ": "N", "ᴼ": "O", "ᴾ": "P", "ᴿ": "R",
    "ᵀ": "T", "ᵁ": "U", "ⱽ": "V", "ᵂ": "W",
    "ᵃ": "a", "ᵇ": "b", "ᶜ": "c", "ᵈ": "d", "ᵉ": "e",
    "ᶠ": "f", "ᵍ": "g", "ʰ": "h", "ⁱ": "i", "ʲ": "j",
    "ᵏ": "k", "ˡ": "l", "ᵐ": "m", "ⁿ": "n", "ᵒ": "o",
    "ᵖ": "p", "ʳ": "r", "ˢ": "s", "ᵗ": "t", "ᵘ": "u",
    "ᵛ": "v", "ʷ": "w", "ˣ": "x", "ʸ": "y", "ᶻ": "z",
    "ᵅ": r"\alpha", "ᵝ": r"\beta", "ᵞ": r"\gamma", "ᵟ": r"\delta",
    "ᵋ": r"\epsilon", "ᶿ": r"\theta", "ᶥ": r"\iota", "ᵠ": r"\phi", "ᵡ": r"\chi",
    "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
    "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
}

# Punctuation/separator marks that can appear inside script runs.
# Unicode has subscript digits/letters, but no standalone subscript comma,
# period, colon, or semicolon. OCR labels may therefore contain normal ASCII
# punctuation, full-width punctuation, or combining marks between subscript /
# superscript characters. In a script run, keep these as plain ASCII
# punctuation inside the same LaTeX group:
#     M₀‚₀  -> M_{0,0}
#     Aᵢ:ⱼ  -> A_{i:j}
#     x¹．² -> x^{1.2}
SCRIPT_SEPARATOR_CHARS: dict[str, str] = {
    # comma-like
    ",": ",",
    "‚": ",",      # U+201A single low-9 quotation mark
    "،": ",",      # U+060C Arabic comma
    "，": ",",     # U+FF0C fullwidth comma
    "﹐": ",",     # U+FE50 small comma
    "､": ",",      # U+FF64 halfwidth ideographic comma
    "︐": ",",     # U+FE10 presentation comma
    "⸲": ",",      # U+2E32 turned comma
    "ꓹ": ",",      # U+A4F9 Lisu letter tone na po, comma-like
    "¸": ",",      # U+00B8 cedilla, often OCR-confused with comma below
    "̦": ",",      # U+0326 combining comma below

    # period/dot-like
    ".": ".",
    "．": ".",     # U+FF0E fullwidth full stop
    "｡": ".",      # U+FF61 halfwidth ideographic full stop
    "。": ".",      # U+3002 ideographic full stop
    "․": ".",      # U+2024 one dot leader
    "·": ".",      # U+00B7 middle dot, when used as a script separator
    "∙": ".",      # U+2219 bullet operator, when used as a script separator
    "̇": ".",      # U+0307 combining dot above
    "̣": ".",      # U+0323 combining dot below

    # colon-like
    ":": ":",
    "：": ":",     # U+FF1A fullwidth colon
    "﹕": ":",     # U+FE55 small colon
    "︓": ":",     # U+FE13 presentation colon
    "ː": ":",      # U+02D0 modifier letter triangular colon
    "꞉": ":",      # U+A789 modifier letter colon
    "∶": ":",      # U+2236 ratio

    # semicolon-like
    ";": ";",
    "；": ";",     # U+FF1B fullwidth semicolon
    "﹔": ";",     # U+FE54 small semicolon
    "︔": ";",     # U+FE14 presentation semicolon
    "؛": ";",      # U+061B Arabic semicolon
}

SPACE_MODE_PRESERVE = "Preserve exactly"
SPACE_MODE_COLLAPSE = "Collapse runs to one space"
SPACE_MODE_REMOVE = "Remove all spaces"
SPACE_MODE_TILDE = "Replace spaces with ~"
SPACE_MODES = (
    SPACE_MODE_PRESERVE,
    SPACE_MODE_COLLAPSE,
    SPACE_MODE_REMOVE,
    SPACE_MODE_TILDE,
)

EXISTING_LATEX_MODE_PRESERVE = "Preserve LaTeX syntax"
EXISTING_LATEX_MODE_ESCAPE = "Escape as literal text"
EXISTING_LATEX_MODES = (
    EXISTING_LATEX_MODE_PRESERVE,
    EXISTING_LATEX_MODE_ESCAPE,
)

OUTPUT_CONVENTION_LATEX = "LaTeX"
OUTPUT_CONVENTION_PLAIN_ASCII = "Plain ASCII math"
OUTPUT_CONVENTION_UNICODE_MATH = "UnicodeMath linear"
OUTPUT_CONVENTION_UNICODE_ACADEMIC = "Unicode ISO/academic"
OUTPUT_CONVENTION_UNICODE_CHARSET = "Unicode character set"
OUTPUT_CONVENTIONS = (
    OUTPUT_CONVENTION_LATEX,
    OUTPUT_CONVENTION_PLAIN_ASCII,
    OUTPUT_CONVENTION_UNICODE_MATH,
    OUTPUT_CONVENTION_UNICODE_ACADEMIC,
    OUTPUT_CONVENTION_UNICODE_CHARSET,
)

# Backward-compatible names used by the older frequency-filter plumbing.
CONVERSION_DIRECTION_SYMBOLS_TO_LATEX = OUTPUT_CONVENTION_LATEX
CONVERSION_DIRECTION_LATEX_TO_SYMBOLS = OUTPUT_CONVENTION_UNICODE_CHARSET
CONVERSION_DIRECTIONS = OUTPUT_CONVENTIONS

# Private-use sentinel used only inside the conversion pipeline. It marks a
# tilde generated by the Spaces: ~ mode, so it is emitted as a LaTeX space token
# instead of being treated as a literal original-label tilde that needs escaping.
SPACE_GENERATED_TILDE = "\uE000"

# Literal original-label characters that can be escaped for LaTeX when the
# Escape literal LaTeX specials option is enabled. These are escaped only in
# the fallback path for characters copied from the source label; generated
# syntax such as \theta, _{0}, and \mathbb{R} is never re-escaped.
LITERAL_LATEX_SPECIALS: dict[str, str] = {
    "\\": r"\textbackslash{}",
    "{": r"\{",
    "}": r"\}",
    "$": r"\$",
    "&": r"\&",
    "%": r"\%",
    "#": r"\#",
    "_": r"\_",
    "^": r"\textasciicircum{}",
    "~": r"\textasciitilde{}",
    # A straight double quote is not one of TeX's core parameter/special chars,
    # but making it explicit avoids package/shorthand surprises.
    '"': r"\textquotedbl{}",
}

def apply_space_mode(label: str, space_mode: str) -> tuple[str, str]:
    """Apply the selected whitespace export policy before symbol conversion.

    Returns (new_label, status_note).  Applying this before LaTeX conversion is
    important for remove-all-spaces mode: if a Greek symbol is followed by a
    word after spaces are removed, convert_label_to_latex() can still add the
    needed {} guard, e.g. θ when -> \theta{}when.
    """
    if space_mode == SPACE_MODE_COLLAPSE:
        collapsed = re.sub(r"\s+", " ", label)
        return collapsed, "spaces collapsed" if collapsed != label else ""

    if space_mode == SPACE_MODE_REMOVE:
        removed = re.sub(r"\s+", "", label)
        return removed, "spaces removed" if removed != label else ""

    if space_mode == SPACE_MODE_TILDE:
        replaced = re.sub(r"\s+", SPACE_GENERATED_TILDE, label)
        return replaced, "spaces replaced with ~" if replaced != label else ""

    return label, ""

def convert_label_with_options(
    label: str,
    space_mode: str,
    existing_latex_mode: str,
    escape_literal_specials: bool,
    conversion_direction: str,
) -> tuple[str, str, str, str, str]:
    """Apply whitespace policy, then normalize labels to the selected convention."""
    prepared, space_action = apply_space_mode(label, space_mode)

    if conversion_direction == OUTPUT_CONVENTION_PLAIN_ASCII:
        converted, changed = convert_label_to_plain_ascii(prepared)
        return converted, space_action, "", "", "plain ASCII math" if changed else ""

    if conversion_direction == OUTPUT_CONVENTION_UNICODE_MATH:
        converted, changed = convert_label_to_unicode_math(prepared)
        return converted, space_action, "", "", "UnicodeMath linear" if changed else ""

    if conversion_direction == OUTPUT_CONVENTION_UNICODE_ACADEMIC:
        converted, changed = convert_label_to_unicode_academic(prepared)
        return converted, space_action, "", "", "Unicode academic" if changed else ""

    if conversion_direction == OUTPUT_CONVENTION_UNICODE_CHARSET:
        converted, changed = convert_label_to_unicode_charset(prepared)
        return converted, space_action, "", "", "Unicode characters" if changed else ""

    preserve_existing = existing_latex_mode == EXISTING_LATEX_MODE_PRESERVE
    converted, escaped, preserved, normalized_unicode, unicode_fallback = convert_label_to_latex(
        prepared,
        escape_literal_specials=escape_literal_specials,
        preserve_existing_latex=preserve_existing,
    )
    escape_action = "latex specials escaped" if escaped else ""
    preserve_action = "existing latex preserved" if preserved else ""
    if unicode_fallback:
        unicode_action = "unicode fallback used"
    elif normalized_unicode:
        unicode_action = "unicode normalized"
    else:
        unicode_action = ""
    return converted, space_action, escape_action, preserve_action, unicode_action

@dataclass(frozen=True)
class LabelPreview:
    file_path: Path
    label_path: str
    before: str
    after: str
    changed: bool
    space_action: str
    escape_action: str
    preserve_action: str
    unicode_action: str
    label_frequency: int
    before_raw_length: int
    after_raw_length: int
    after_token_length: int
    token_length_delta: int
    unique_after_tokens: int
    label_stats: str


BASE_COLUMN_SPECS: tuple[tuple[str, str], ...] = (
    ("file", "File"),
    ("label_path", "Label Path"),
    ("before", "Before"),
    ("after", "After"),
    ("status", "Status"),
)

OPTIONAL_COLUMN_SPECS: tuple[tuple[str, str], ...] = (
    ("label_frequency", "Output Freq"),
    ("before_raw_length", "Before Raw Len"),
    ("after_raw_length", "After Raw Len"),
    ("after_token_length", "After Tokens"),
    ("token_length_delta", "Token Δ"),
    ("unique_after_tokens", "Unique Tokens"),
    ("label_stats", "Label Stats"),
)

NUMERIC_COLUMN_KEYS = {
    "label_frequency",
    "before_raw_length",
    "after_raw_length",
    "after_token_length",
    "token_length_delta",
    "unique_after_tokens",
}

ALL_COLUMN_SPECS: tuple[tuple[str, str], ...] = BASE_COLUMN_SPECS + OPTIONAL_COLUMN_SPECS

COLUMN_VIEW_SIMPLE = "Simple"
COLUMN_VIEW_TRAINING = "Training"
COLUMN_VIEW_DEBUG_FULL = "Debug / full"
COLUMN_VIEW_CUSTOM = "Custom"
COLUMN_VIEW_CHOICES = (
    COLUMN_VIEW_TRAINING,
    COLUMN_VIEW_SIMPLE,
    COLUMN_VIEW_DEBUG_FULL,
    COLUMN_VIEW_CUSTOM,
)
DEFAULT_COLUMN_VIEW = COLUMN_VIEW_TRAINING
COLUMN_VIEW_PRESETS: dict[str, set[str]] = {
    COLUMN_VIEW_SIMPLE: {"file", "label_path", "before", "after", "status"},
    COLUMN_VIEW_TRAINING: {
        "before",
        "after",
        "status",
        "label_frequency",
        "after_token_length",
        "unique_after_tokens",
    },
    COLUMN_VIEW_DEBUG_FULL: {key for key, _title in ALL_COLUMN_SPECS},
}


def natural_sort_key(text: str) -> tuple[tuple[int, int | str], ...]:
    """Return a stable natural-sort key so crop[9] sorts before crop[10].

    Only ASCII digit runs are treated as sortable integers. Unicode math/script
    digits like ² stay in the text part instead of crashing int(...).
    """
    parts = re.split(r"([0-9]+)", text)
    key: list[tuple[int, int | str]] = []
    for part in parts:
        if not part:
            continue
        if part.isascii() and part.isdecimal():
            key.append((0, int(part)))
        else:
            key.append((1, part.casefold()))
    return tuple(key)

def format_elapsed_seconds(seconds: float) -> str:
    """Return a compact elapsed-time string for preview/export status text."""
    if seconds < 1.0:
        return f"{seconds * 1000:.0f} ms"
    if seconds < 60.0:
        return f"{seconds:.2f} s"
    minutes = int(seconds // 60)
    remainder = seconds - (minutes * 60)
    return f"{minutes} min {remainder:.1f} s"


def label_stats_sort_key(stats: str) -> tuple[int, int, int, int, int, int] | str:
    """Sort the compact stats column by its numeric fields instead of text."""
    match = re.search(
        r"raw=(\d+),\s*tokens=(\d+),\s*unique_tokens=(\d+),\s*ascii=(\d+),\s*unicode=(\d+),\s*cmds=(\d+)",
        stats,
    )
    if not match:
        return stats.casefold()
    return tuple(int(value) for value in match.groups())


class SortableTableWidgetItem(QTableWidgetItem):
    """QTableWidgetItem that keeps display text separate from sort value.

    QTableWidgetItem sorts by displayed text by default, so numeric columns such
    as Label Freq sort lexicographically (1, 10, 2). This item stores a typed
    sort value and compares that value when the user clicks a column header.
    """

    def __init__(self, text: str, sort_value: object | None = None) -> None:
        super().__init__(text)
        self.sort_value = text.casefold() if sort_value is None else sort_value

    def __lt__(self, other: QTableWidgetItem) -> bool:
        left = self.sort_value
        right = getattr(other, "sort_value", other.text().casefold())
        try:
            return left < right  # type: ignore[operator]
        except TypeError:
            return str(left) < str(right)

@dataclass(frozen=True)
class FrequencyFilterOptions:
    # Frequency is class balancing by final output label.
    enabled: bool
    min_count: int = DEFAULT_MIN_CLASS_COUNT
    max_count_auto: bool = True
    max_count_mode: str = MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN
    max_count: int = DEFAULT_MIN_CLASS_COUNT
    length_enabled: bool = False
    min_length: int = 0
    max_length: int = MAX_FILTER_VALUE
    unique_enabled: bool = False
    min_unique: int = 0
    max_unique: int = MAX_FILTER_VALUE
    token_filter_enabled: bool = False
    token_min_label_count: int = 3
    token_unit_mode: str = TOKEN_AUDIT_MODE_AUTO
    token_use_hybrid_tokens: bool = True
    prefer_rare_tokens: bool = True
    token_occurrence_balance_enabled: bool = False
    token_occurrence_target_auto: bool = True
    token_occurrence_target_mode: str = MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN
    token_occurrence_target_max: int = DEFAULT_MIN_CLASS_COUNT
    token_occurrence_min_target: int = 0
    token_occurrence_balance_mode: str = TOKEN_OCCURRENCE_BALANCE_MODE_SOFT
    charset_filter_enabled: bool = False
    charset_filter_path: str = ""

    def any_enabled(self) -> bool:
        return (
            self.enabled
            or self.length_enabled
            or self.unique_enabled
            or self.token_filter_enabled
            or self.token_occurrence_balance_enabled
            or self.charset_filter_enabled
        )


@dataclass(frozen=True)
class FilterMetricLimits:
    max_frequency: int = 1
    max_length: int = 0
    max_unique: int = 0


LabelEntryId = tuple[Path, str]


def normalized_token_occurrence_balance_mode(mode: str) -> str:
    """Map old/saved token-occurrence mode names to the current method names."""
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED:
        return TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS:
        return TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL:
        return TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL
    # Older builds stored/displayed this as "Hard min/max". That is the
    # original current adaptive method.
    return TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT


def make_label_stats(label: str, token_items: list[str] | None = None) -> str:
    """Return compact raw-text and tokenizer-focused stats for an output label."""
    if token_items is None:
        token_items = list(label)
    ascii_count = sum(1 for ch in label if ch.isascii())
    non_ascii_count = len(label) - ascii_count
    latex_command_count = len(re.findall(r"\\[A-Za-z]+", label))
    unique_token_count = len(set(token_items))
    return (
        f"raw={len(label)}, tokens={len(token_items)}, unique_tokens={unique_token_count}, "
        f"ascii={ascii_count}, unicode={non_ascii_count}, cmds={latex_command_count}"
    )


def latex_macro_needs_guard(text: str) -> bool:
    """Return True for macros such as \alpha that can absorb following letters."""
    if not text.startswith("\\"):
        return False
    if not text[-1:].isalpha():
        return False
    # Control symbols like \| do not need this. All entries ending in a letter do.
    return True

def append_token(out: list[str], token: str, next_raw_char: str | None = None) -> None:
    """Append a converted token, adding {} after letter macros before letters."""
    if latex_macro_needs_guard(token) and next_raw_char and next_raw_char.isascii() and next_raw_char.isalpha():
        out.append(token + "{}")
    else:
        out.append(token)

def join_script_pieces(pieces: list[str]) -> str:
    """Join sub/superscript pieces without letting macros absorb letters."""
    out: list[str] = []
    for idx, piece in enumerate(pieces):
        next_piece = pieces[idx + 1] if idx + 1 < len(pieces) else ""
        if latex_macro_needs_guard(piece) and next_piece[:1].isascii() and next_piece[:1].isalpha():
            out.append(piece + "{}")
        else:
            out.append(piece)
    return "".join(out)

# Text-like Unicode that should become plain ASCII instead of LaTeX commands.
# This keeps labels compatible with the string-token tokenizer's character fallback.
UNICODE_TEXT_TO_ASCII: dict[str, str] = {
    "\u00a0": " ",      # non-breaking space
    "\u2007": " ",
    "\u202f": " ",
    "\u2009": " ",
    "\u200a": " ",
    "\u200b": "",       # zero-width space
    "\ufeff": "",       # byte-order mark / zero-width no-break space
    "“": '"', "”": '"', "„": '"', "‟": '"',
    "‘": "'", "’": "'", "‚": ",", "‛": "'",
    "′": "'", "″": "''", "‴": "'" * 3,
    "‐": "-", "‑": "-", "‒": "-", "–": "-", "—": "-", "―": "-", "−": "-",
    "．": ".", "。": ".", "｡": ".",
    "，": ",", "、": ",", "﹐": ",", "､": ",",
    "：": ":", "﹕": ":",
    "；": ";", "﹔": ";",
    "（": "(", "）": ")", "［": "[", "］": "]", "｛": "{", "｝": "}",
    "＜": "<", "＞": ">", "＝": "=", "＋": "+", "＊": "*", "／": "/", "＼": "\\",
}

# Extra math symbols that commonly appear in OCR labels. Commands not listed as
# multi-character tokens in latex_hybrid.yaml are still representable through
# the tokenizer's character fallback because the output is ASCII.
SYMBOL_TO_LATEX.update({
    "∑": r"\sum",
    "∏": r"\prod",
    "∫": r"\int",
    "∮": r"\oint",
    "≈": r"\approx",
    "≃": r"\simeq",
    "≅": r"\cong",
    "∼": r"\sim",
    "≪": r"\ll",
    "≫": r"\gg",
    "∓": r"\mp",
    "∗": r"\ast",
    "⊄": r"\nsubset",
    "⊇": r"\supseteq",
    "⊃": r"\supset",
    "∖": r"\setminus",
    "↦": r"\mapsto",
    "⇔": r"\Leftrightarrow",
    "⇐": r"\Leftarrow",
    "↩": r"\hookleftarrow",
    "↪": r"\hookrightarrow",
    "∴": r"\therefore",
    "∵": r"\because",
    "∝": r"\propto",
    "∎": r"\blacksquare",
    "□": r"\square",
    "△": r"\triangle",
    "∠": r"\angle",
})

def safe_ascii_fallback_for_unicode(ch: str) -> tuple[str, bool, bool]:
    """Return an ASCII-only fallback for a Unicode character.

    Returns (replacement, normalized, fallback). If Unicode normalization gives
    a useful ASCII representation, use it. Otherwise emit \\unicode{XXXX}; that
    keeps the label representable by the string-token tokenizer even when the symbol
    is not in the hand-written map yet.
    """
    direct = UNICODE_TEXT_TO_ASCII.get(ch)
    if direct is not None:
        return direct, True, False

    normalized = unicodedata.normalize("NFKC", ch)
    if normalized != ch and normalized and all(c.isascii() for c in normalized):
        return normalized, True, False

    return rf"\unicode{{{ord(ch):04X}}}", False, True

def convert_plain_char(
    ch: str,
    *,
    escape_literal_specials: bool,
) -> tuple[str, bool, bool, bool]:
    """Convert one non-script, non-command source character.

    Returns (text, escaped_literal, normalized_unicode, unicode_fallback).
    """
    replacement = SYMBOL_TO_LATEX.get(ch)
    if replacement is not None:
        return replacement, False, False, False

    if ch in SCRIPT_SEPARATOR_CHARS:
        return SCRIPT_SEPARATOR_CHARS[ch], False, False, False

    if ch == SPACE_GENERATED_TILDE:
        return "~", False, False, False

    if escape_literal_specials and ch in LITERAL_LATEX_SPECIALS:
        return LITERAL_LATEX_SPECIALS[ch], True, False, False

    if not ch.isascii():
        repl, normalized, fallback = safe_ascii_fallback_for_unicode(ch)
        return repl, False, normalized, fallback

    return ch, False, False, False

def read_script_run(label: str, start: int, script_chars: dict[str, str]) -> tuple[list[str], int]:
    """Read one grouped subscript/superscript run.

    Consecutive Unicode script characters become one LaTeX group. ASCII or
    Unicode punctuation is included only when it is *inside* the run, meaning
    it already follows at least one script character and the next non-separator
    character is another script character.

    This keeps normal punctuation outside scripts unchanged, while fixing cases
    like M₀‚₀ -> M_{0,0} instead of M_{0},_{0}.
    """
    pieces: list[str] = []
    i = start
    n = len(label)

    while i < n:
        ch = label[i]

        if ch in script_chars:
            pieces.append(script_chars[ch])
            i += 1
            continue

        if ch in SCRIPT_SEPARATOR_CHARS and pieces:
            sep_i = i
            separator_pieces: list[str] = []
            while sep_i < n and label[sep_i] in SCRIPT_SEPARATOR_CHARS:
                separator_pieces.append(SCRIPT_SEPARATOR_CHARS[label[sep_i]])
                sep_i += 1

            if sep_i < n and label[sep_i] in script_chars:
                pieces.extend(separator_pieces)
                i = sep_i
                continue

        break

    return pieces, i

def read_balanced_group(text: str, start: int, open_char: str, close_char: str) -> tuple[str, int] | None:
    """Read a balanced LaTeX-style group such as {...} or [...]."""
    if start >= len(text) or text[start] != open_char:
        return None

    depth = 1
    i = start + 1
    while i < len(text):
        ch = text[i]
        if ch == "\\":
            # Keep escaped chars / control sequences inside the preserved group
            # from confusing the brace matcher.
            i += 2
            continue
        if ch == open_char:
            depth += 1
        elif ch == close_char:
            depth -= 1
            if depth == 0:
                return text[start : i + 1], i + 1
        i += 1
    return None

def read_normalized_latex_group(
    text: str,
    start: int,
    open_char: str,
    close_char: str,
    *,
    escape_literal_specials: bool,
) -> tuple[str, int, bool, bool, bool, bool] | None:
    """Read a group and recursively convert mixed Unicode inside it."""
    raw = read_balanced_group(text, start, open_char, close_char)
    if raw is None:
        return None
    group_text, end = raw
    inner = group_text[1:-1]
    converted_inner, escaped, preserved, normalized, fallback = convert_label_to_latex(
        inner,
        escape_literal_specials=escape_literal_specials,
        preserve_existing_latex=True,
    )
    return open_char + converted_inner + close_char, end, escaped, preserved, normalized, fallback

def read_simple_latex_argument(
    text: str,
    start: int,
    *,
    escape_literal_specials: bool,
) -> tuple[str, int, bool, bool, bool, bool] | None:
    """Read one existing-LaTeX argument/group and convert mixed Unicode inside."""
    if start >= len(text):
        return None
    if text[start] == "{":
        return read_normalized_latex_group(text, start, "{", "}", escape_literal_specials=escape_literal_specials)
    if text[start] == "[":
        return read_normalized_latex_group(text, start, "[", "]", escape_literal_specials=escape_literal_specials)
    return None

def convert_simple_script_argument_char(
    ch: str,
    *,
    escape_literal_specials: bool,
) -> tuple[str, bool, bool, bool]:
    """Convert a single unbraced script argument to the inside of {...}."""
    if ch in SUBSCRIPT_CHARS:
        return SUBSCRIPT_CHARS[ch], False, False, False
    if ch in SUPERSCRIPT_CHARS:
        return SUPERSCRIPT_CHARS[ch], False, False, False
    return convert_plain_char(ch, escape_literal_specials=escape_literal_specials)

def read_existing_latex_script(
    text: str,
    start: int,
    *,
    escape_literal_specials: bool,
) -> tuple[str, int, bool, bool, bool, bool] | None:
    r"""Read and normalize an existing LaTeX _ or ^ script expression.

    Existing braced scripts are preserved as groups, but any Unicode inside the
    braces is still converted. Unbraced scripts are normalized to braced form:
        ^n       -> ^{n}
        _1       -> _{1}
        ^\alpha -> ^{\alpha}
        ^δ       -> ^{\delta}
    """
    if start >= len(text) or text[start] not in "_^" or start + 1 >= len(text):
        return None

    op = text[start]
    i = start + 1

    if text[i] == "{":
        group = read_simple_latex_argument(text, i, escape_literal_specials=escape_literal_specials)
        if group is None:
            return None
        group_text, end, escaped, preserved, normalized, fallback = group
        return op + group_text, end, escaped, True, normalized, fallback

    if text[i] == "[":
        group = read_simple_latex_argument(text, i, escape_literal_specials=escape_literal_specials)
        if group is None:
            return None
        group_text, end, escaped, preserved, normalized, fallback = group
        return op + "{" + group_text + "}", end, escaped, True, normalized, fallback

    if text[i] == "\\":
        command = read_existing_latex_syntax(text, i, escape_literal_specials=escape_literal_specials)
        if command is not None:
            command_text, end, escaped, preserved, normalized, fallback = command
            return op + "{" + command_text + "}", end, escaped, True, normalized, fallback

    arg, escaped, normalized, fallback = convert_simple_script_argument_char(
        text[i],
        escape_literal_specials=escape_literal_specials,
    )
    return op + "{" + arg + "}", i + 1, escaped, True, normalized, fallback

def read_latex_environment(text: str, start: int, *, escape_literal_specials: bool) -> tuple[str, int, bool, bool, bool, bool] | None:
    r"""Preserve \begin{...} ... \end{...}, converting mixed Unicode in the body."""
    begin_prefix = r"\begin"
    if not text.startswith(begin_prefix, start):
        return None

    group = read_simple_latex_argument(text, start + len(begin_prefix), escape_literal_specials=escape_literal_specials)
    if group is None:
        return None
    env_group, after_group, escaped, _preserved, normalized, fallback = group
    env_name = env_group[1:-1]
    if not env_name:
        return None

    end_token = rf"\end{{{env_name}}}"
    end_pos = text.find(end_token, after_group)
    if end_pos == -1:
        return begin_prefix + env_group, after_group, escaped, True, normalized, fallback

    body = text[after_group:end_pos]
    body_text, body_escaped, _body_preserved, body_normalized, body_fallback = convert_label_to_latex(
        body,
        escape_literal_specials=escape_literal_specials,
        preserve_existing_latex=True,
    )
    return (
        begin_prefix + env_group + body_text + end_token,
        end_pos + len(end_token),
        escaped or body_escaped,
        True,
        normalized or body_normalized,
        fallback or body_fallback,
    )

def read_existing_latex_syntax(
    text: str,
    start: int,
    *,
    escape_literal_specials: bool,
) -> tuple[str, int, bool, bool, bool, bool] | None:
    r"""Read existing LaTeX syntax and convert mixed Unicode inside it.

    The string-token tokenizer can consume a mix of command-string tokens and normal
    characters. This parser therefore preserves existing command syntax, but it
    no longer freezes entire arguments. For example:
        \frac{δ_1}{Σ^n} -> \frac{\delta_{1}}{\Sigma^{n}}
    """
    if start >= len(text):
        return None

    ch = text[start]
    if ch in "_^":
        return read_existing_latex_script(text, start, escape_literal_specials=escape_literal_specials)

    if ch != "\\":
        return None

    env = read_latex_environment(text, start, escape_literal_specials=escape_literal_specials)
    if env is not None:
        return env

    i = start + 1
    if i >= len(text):
        return None

    if text[i].isascii() and text[i].isalpha():
        i += 1
        while i < len(text) and text[i].isascii() and text[i].isalpha():
            i += 1
    else:
        # Control symbol / escaped special, e.g. \%, \_, \{, \\, etc.
        i += 1

    pieces = [text[start:i]]
    escaped_literal = False
    normalized_unicode = False
    unicode_fallback = False

    # Preserve immediately attached arguments and scripts, while recursively
    # converting any Unicode inside the arguments/scripts.
    while i < len(text):
        if text[i] in "{[":
            group = read_simple_latex_argument(text, i, escape_literal_specials=escape_literal_specials)
            if group is None:
                break
            group_text, i, escaped, _preserved, normalized, fallback = group
            pieces.append(group_text)
            escaped_literal = escaped_literal or escaped
            normalized_unicode = normalized_unicode or normalized
            unicode_fallback = unicode_fallback or fallback
            continue
        if text[i] in "_^":
            script = read_existing_latex_script(text, i, escape_literal_specials=escape_literal_specials)
            if script is None:
                break
            script_text, i, escaped, _preserved, normalized, fallback = script
            pieces.append(script_text)
            escaped_literal = escaped_literal or escaped
            normalized_unicode = normalized_unicode or normalized
            unicode_fallback = unicode_fallback or fallback
            continue
        break

    return "".join(pieces), i, escaped_literal, True, normalized_unicode, unicode_fallback

def convert_label_to_latex(
    label: str,
    *,
    escape_literal_specials: bool = True,
    preserve_existing_latex: bool = True,
) -> tuple[str, bool, bool, bool, bool]:
    """Convert supported Unicode symbols in a label to hybrid-tokenizer-friendly LaTeX.

    Returns (text, escaped_literal, preserved_existing, normalized_unicode,
    unicode_fallback). The output is intended to be representable by the
    latex_string-token tokenizer's character fallback even when a rare Unicode symbol
    was not explicitly mapped.
    """
    out: list[str] = []
    escaped_literal = False
    preserved_existing = False
    normalized_unicode = False
    unicode_fallback = False
    i = 0
    n = len(label)

    while i < n:
        ch = label[i]

        if preserve_existing_latex:
            existing = read_existing_latex_syntax(
                label,
                i,
                escape_literal_specials=escape_literal_specials,
            )
            if existing is not None:
                existing_text, i, escaped, preserved, normalized, fallback = existing
                out.append(existing_text)
                escaped_literal = escaped_literal or escaped
                preserved_existing = preserved_existing or preserved
                normalized_unicode = normalized_unicode or normalized
                unicode_fallback = unicode_fallback or fallback
                continue

        if ch in SUBSCRIPT_CHARS:
            pieces, i = read_script_run(label, i, SUBSCRIPT_CHARS)
            out.append("_{" + join_script_pieces(pieces) + "}")
            continue

        if ch in SUPERSCRIPT_CHARS:
            pieces, i = read_script_run(label, i, SUPERSCRIPT_CHARS)
            out.append("^{" + join_script_pieces(pieces) + "}")
            continue

        replacement = SYMBOL_TO_LATEX.get(ch)
        if replacement is not None:
            next_raw = label[i + 1] if i + 1 < n else None
            append_token(out, replacement, next_raw)
        else:
            converted, escaped, normalized, fallback = convert_plain_char(
                ch,
                escape_literal_specials=escape_literal_specials,
            )
            out.append(converted)
            escaped_literal = escaped_literal or escaped
            normalized_unicode = normalized_unicode or normalized
            unicode_fallback = unicode_fallback or fallback
        i += 1

    return "".join(out), escaped_literal, preserved_existing, normalized_unicode, unicode_fallback

# Reverse LaTeX command -> Unicode/symbol conversion. This is intentionally not
# restricted to the string-token tokenizer charset; the point of this direction is to
# restore readable symbol labels when desired.
def _macro_boundary_ok(text: str, start: int, macro: str) -> bool:
    """Avoid matching short alphabetic commands inside longer commands."""
    if not (macro.startswith("\\") and macro[1:].isalpha()):
        return True
    end = start + len(macro)
    return end >= len(text) or not (text[end].isascii() and text[end].isalpha())


def _build_latex_to_symbol_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for symbol, latex in SYMBOL_TO_LATEX.items():
        # Prefer the first symbol listed for duplicate commands such as \cdot.
        # Do not reverse plain ASCII fallbacks like Greek capital Nu -> "N";
        # otherwise ordinary Latin letters inside scripts become Greek symbols.
        if latex.startswith("\\"):
            mapping.setdefault(latex, symbol)

    mapping.update({
        r"\%": "%",
        r"\_": "_",
        r"\{": "{",
        r"\}": "}",
        r"\$": "$",
        r"\&": "&",
        r"\#": "#",
        r"\textquotedbl{}": '"',
        r"\textbackslash{}": "\\",
        r"\textasciicircum{}": "^",
        r"\textasciitilde{}": "~",
    })
    return mapping


LATEX_TO_SYMBOL = _build_latex_to_symbol_map()
LATEX_SYMBOL_KEYS = sorted(LATEX_TO_SYMBOL, key=len, reverse=True)

SUBSCRIPT_LATEX_TO_UNICODE: dict[str, str] = {}
for _unicode_ch, _latex_text in SUBSCRIPT_CHARS.items():
    SUBSCRIPT_LATEX_TO_UNICODE.setdefault(_latex_text, _unicode_ch)
SUBSCRIPT_LATEX_TO_UNICODE.update({",": ",", ".": ".", ":": ":", ";": ";", " ": " "})

SUPERSCRIPT_LATEX_TO_UNICODE: dict[str, str] = {}
for _unicode_ch, _latex_text in SUPERSCRIPT_CHARS.items():
    SUPERSCRIPT_LATEX_TO_UNICODE.setdefault(_latex_text, _unicode_ch)
SUPERSCRIPT_LATEX_TO_UNICODE.update({",": ",", ".": ".", ":": ":", ";": ";", " ": " "})


def read_latex_command_name(text: str, start: int) -> tuple[str, int] | None:
    """Read a LaTeX command/control sequence starting at a backslash."""
    if start >= len(text) or text[start] != "\\":
        return None
    i = start + 1
    if i >= len(text):
        return None
    if text[i].isascii() and text[i].isalpha():
        i += 1
        while i < len(text) and text[i].isascii() and text[i].isalpha():
            i += 1
    else:
        i += 1
    return text[start:i], i


FORMAT_GUARD_TOKEN = "{}"
FORMAT_GUARD_STATUS = "canonical latex guards normalized"
CANONICAL_GUARDED_TOKEN_MODE_DEFAULT = True

# Commands in these categories either take real arguments/delimiters or already
# use an empty group as their semantic token. They should not be converted into
# formatting-guard tokens such as \frac{} or \sqrt{}{}.
CANONICAL_GUARD_EXCLUDED_COMMANDS = {
    r"\frac",
    r"\sqrt",
    r"\dot",
    r"\left",
    r"\right",
    r"\begin",
    r"\end",
    r"\mathbb",
    r"\mathbf",
    r"\mathrm",
    r"\mathcal",
    r"\mathfrak",
    r"\mathsf",
    r"\mathtt",
    r"\unicode",
    r"\textquotedbl",
    r"\textbackslash",
    r"\textasciicircum",
    r"\textasciitilde",
}


def append_status_note(existing: str, note: str) -> str:
    """Append a semicolon-separated status note without duplicating it."""
    if not note:
        return existing
    parts = [part.strip() for part in existing.split(";") if part.strip()]
    if note not in parts:
        parts.append(note)
    return "; ".join(parts)


def canonical_guardable_latex_commands() -> set[str]:
    r"""Return atomic LaTeX commands that should use ``{}`` as canonical guard.

    The list is derived from the symbol-conversion map, so semantic atoms like
    ``\theta``, ``\neq``, ``\sum``, and ``\rightarrow`` are guarded by
    default. Structural/argument commands such as ``\frac``, ``\sqrt``,
    ``\left``, and ``\mathbb`` are excluded.
    """
    commands: set[str] = set()
    for latex_text in SYMBOL_TO_LATEX.values():
        if not re.fullmatch(r"\\[A-Za-z]+", latex_text):
            continue
        if latex_text in CANONICAL_GUARD_EXCLUDED_COMMANDS:
            continue
        commands.add(latex_text)
    return commands


def is_canonical_guardable_latex_command(command_text: str) -> bool:
    return command_text in canonical_guardable_latex_commands()


def canonicalize_latex_token_for_guarded_mode(token: str) -> str:
    r"""Return the canonical guarded spelling for guardable atomic tokens."""
    if CANONICAL_GUARDED_TOKEN_MODE_DEFAULT and is_canonical_guardable_latex_command(token):
        return token + FORMAT_GUARD_TOKEN
    return token


def canonicalize_latex_token_list_for_guarded_mode(tokens: Iterable[str]) -> list[str]:
    """Canonicalize template token spellings while preserving order and uniqueness."""
    ordered: list[str] = []
    seen: set[str] = set()
    for token in tokens:
        canonical = canonicalize_latex_token_for_guarded_mode(token)
        if canonical not in seen:
            ordered.append(canonical)
            seen.add(canonical)
    return ordered


def guarded_latex_command_bases_from_labels(labels: Iterable[str]) -> set[str]:
    r"""Return LaTeX command bases that appear with an empty formatting guard.

    If any output label contains a guarded form such as ``\theta{}``, the base
    command ``\theta`` is returned so all unguarded instances can be normalized
    to the same guarded class.
    """
    guarded: set[str] = set()
    for label in labels:
        i = 0
        while i < len(label):
            if label[i] != "\\":
                i += 1
                continue
            command = read_latex_command_name(label, i)
            if command is None:
                i += 1
                continue
            command_text, end = command
            if (
                command_text.startswith("\\")
                and command_text[1:].isascii()
                and command_text[1:].isalpha()
                and label.startswith(FORMAT_GUARD_TOKEN, end)
            ):
                guarded.add(command_text)
                i = end + len(FORMAT_GUARD_TOKEN)
            else:
                i = max(end, i + 1)
    return guarded


def canonical_guardable_latex_command_bases_from_labels(labels: Iterable[str]) -> set[str]:
    r"""Return guardable atomic command bases present in the current labels."""
    guarded: set[str] = set()
    for label in labels:
        i = 0
        while i < len(label):
            if label[i] != "\\":
                i += 1
                continue
            command = read_latex_command_name(label, i)
            if command is None:
                i += 1
                continue
            command_text, end = command
            if is_canonical_guardable_latex_command(command_text):
                guarded.add(command_text)
            i = max(end, i + 1)
    return guarded


def normalize_latex_command_guards(label: str, guarded_commands: set[str]) -> tuple[str, bool]:
    r"""Normalize unguarded commands to guarded form when their class uses ``{}``.

    Example: if ``\to{}`` appears anywhere in the dataset, all standalone
    ``\to`` occurrences are rewritten to ``\to{}``. Commands already followed
    by a non-empty argument group are left alone to avoid corrupting structures
    like ``\sqrt{x}`` or ``\mathbb{R}``.
    """
    if not guarded_commands:
        return label, False

    ordered_commands = sorted(guarded_commands, key=len, reverse=True)
    out: list[str] = []
    changed = False
    i = 0
    while i < len(label):
        matched_command = ""
        if label[i] == "\\":
            for command in ordered_commands:
                if not label.startswith(command, i):
                    continue
                end = i + len(command)
                # Do not split a longer command name, e.g. do not treat
                # 	hetax as 	heta + x.
                if end < len(label) and label[end].isascii() and label[end].isalpha():
                    continue
                matched_command = command
                break

        if matched_command:
            out.append(matched_command)
            i += len(matched_command)
            if label.startswith(FORMAT_GUARD_TOKEN, i):
                out.append(FORMAT_GUARD_TOKEN)
                i += len(FORMAT_GUARD_TOKEN)
            elif i < len(label) and label[i] == "{":
                # A non-empty group is likely an argument/constant, not a
                # formatting guard. Preserve it unchanged.
                pass
            else:
                out.append(FORMAT_GUARD_TOKEN)
                changed = True
            continue

        out.append(label[i])
        i += 1

    normalized = "".join(out)
    return normalized, changed or normalized != label


def normalize_latex_string_token_guard_labels(
    labels: list[str],
    *,
    canonical_guarded_token_mode: bool = CANONICAL_GUARDED_TOKEN_MODE_DEFAULT,
) -> tuple[list[str], set[str], int]:
    """Normalize LaTeX command guard usage across a complete label set.

    Canonical guarded token mode is on by default. That means known atomic
    command tokens such as ``\theta``, ``\neq``, and ``\sum`` are normalized
    to ``\theta{}``, ``\neq{}``, and ``\sum{}`` even if no guarded instance
    was already present in the labels. Structural commands with real arguments
    such as ``\frac{...}{...}``, ``\sqrt{...}``, and ``\mathbb{R}`` are left
    alone.
    """
    guarded_commands = guarded_latex_command_bases_from_labels(labels)
    if canonical_guarded_token_mode:
        guarded_commands |= canonical_guardable_latex_command_bases_from_labels(labels)
    if not guarded_commands:
        return labels, set(), 0

    normalized_labels: list[str] = []
    changed_count = 0
    for label in labels:
        normalized, changed = normalize_latex_command_guards(label, guarded_commands)
        normalized_labels.append(normalized)
        changed_count += int(changed)
    return normalized_labels, guarded_commands, changed_count


def convert_latex_script_content_to_unicode(content: str, script_kind: str) -> str | None:
    """Convert script content such as '0,0' or '\\alpha' to Unicode script chars.

    Returns None when any part cannot be represented as Unicode script text.
    Punctuation such as commas is kept as normal punctuation because Unicode has
    no dependable standalone subscript comma/period/colon equivalents.
    """
    table = SUBSCRIPT_LATEX_TO_UNICODE if script_kind == "_" else SUPERSCRIPT_LATEX_TO_UNICODE
    out: list[str] = []
    i = 0
    while i < len(content):
        if content[i] == "\\":
            matched = False
            for key in sorted(table, key=len, reverse=True):
                if key.startswith("\\") and content.startswith(key, i) and _macro_boundary_ok(content, i, key):
                    out.append(table[key])
                    i += len(key)
                    matched = True
                    break
            if matched:
                continue
            return None

        ch = content[i]
        repl = table.get(ch)
        if repl is None:
            return None
        out.append(repl)
        i += 1
    return "".join(out)


def read_latex_group_raw(text: str, start: int) -> tuple[str, int] | None:
    """Read a raw {...} or [...] group and return (inner, end)."""
    if start >= len(text) or text[start] not in "{[":
        return None
    open_char = text[start]
    close_char = "}" if open_char == "{" else "]"
    group = read_balanced_group(text, start, open_char, close_char)
    if group is None:
        return None
    group_text, end = group
    return group_text[1:-1], end


def read_latex_script_to_symbols(text: str, start: int) -> tuple[str, int, bool] | None:
    """Read _ or ^ syntax and convert it to Unicode script when possible."""
    if start >= len(text) or text[start] not in "_^" or start + 1 >= len(text):
        return None

    op = text[start]
    i = start + 1
    if text[i] in "{[":
        raw_group = read_latex_group_raw(text, i)
        if raw_group is None:
            return None
        inner, end = raw_group
        converted_inner, changed_inner = convert_label_to_symbols(inner)
        unicode_script = convert_latex_script_content_to_unicode(converted_inner, op)
        if unicode_script is not None:
            return unicode_script, end, True
        return op + "{" + converted_inner + "}", end, changed_inner

    if text[i] == "\\":
        # A command in a single script position, e.g. ^\alpha.
        command = read_latex_command_name(text, i)
        if command is None:
            return None
        command_text, end = command
        unicode_script = convert_latex_script_content_to_unicode(command_text, op)
        if unicode_script is not None:
            return unicode_script, end, True
        converted_command, changed = convert_label_to_symbols(command_text)
        return op + "{" + converted_command + "}", end, changed

    unicode_script = convert_latex_script_content_to_unicode(text[i], op)
    if unicode_script is not None:
        return unicode_script, i + 1, True
    return op + text[i], i + 1, False


def read_latex_command_to_symbols(text: str, start: int) -> tuple[str, int, bool] | None:
    """Read a LaTeX command/control sequence and convert known commands."""
    if start >= len(text) or text[start] != "\\":
        return None

    # Fallback output produced by the forward converter: \unicode{XXXX}.
    if text.startswith(r"\unicode", start):
        group = read_latex_group_raw(text, start + len(r"\unicode"))
        if group is not None:
            code_text, end = group
            try:
                return chr(int(code_text, 16)), end, True
            except ValueError:
                pass

    # A few commands need argument-aware handling.
    if text.startswith(r"\sqrt", start) and _macro_boundary_ok(text, start, r"\sqrt"):
        after = start + len(r"\sqrt")
        group = read_latex_group_raw(text, after)
        if group is None:
            # \sqrt{} is also in LATEX_TO_SYMBOL and should become √.
            return "√", after, True
        inner, end = group
        converted_inner, changed_inner = convert_label_to_symbols(inner)
        return "√{" + converted_inner + "}", end, True or changed_inner

    # Exact known command/string tokens, including \mathbb{R} and escaped specials.
    for key in LATEX_SYMBOL_KEYS:
        if text.startswith(key, start) and _macro_boundary_ok(text, start, key):
            return LATEX_TO_SYMBOL[key], start + len(key), True

    command = read_latex_command_name(text, start)
    if command is None:
        return None
    command_text, i = command
    pieces = [command_text]
    changed = False

    # Preserve unknown commands such as \frac, but recursively convert symbols
    # inside immediately attached arguments/scripts.
    while i < len(text):
        if text[i] in "{[":
            open_char = text[i]
            close_char = "}" if open_char == "{" else "]"
            raw_group = read_latex_group_raw(text, i)
            if raw_group is None:
                break
            inner, i = raw_group
            converted_inner, inner_changed = convert_label_to_symbols(inner)
            pieces.append(open_char + converted_inner + close_char)
            changed = changed or inner_changed
            continue
        if text[i] in "_^":
            script = read_latex_script_to_symbols(text, i)
            if script is None:
                break
            script_text, i, script_changed = script
            pieces.append(script_text)
            changed = changed or script_changed
            continue
        break

    return "".join(pieces), i, changed


def convert_label_to_symbols(label: str) -> tuple[str, bool]:
    """Convert known LaTeX syntax in a label to Unicode/math symbols.

    This direction intentionally keeps Unicode symbols, and it does not restrict
    output to the training charset. Unknown LaTeX commands are preserved while
    any convertible content inside their arguments is still normalized.
    """
    out: list[str] = []
    changed = False
    i = 0
    while i < len(label):
        ch = label[i]
        if ch in "_^":
            script = read_latex_script_to_symbols(label, i)
            if script is not None:
                script_text, i, script_changed = script
                out.append(script_text)
                changed = changed or script_changed
                continue
        if ch == "\\":
            command = read_latex_command_to_symbols(label, i)
            if command is not None:
                command_text, i, command_changed = command
                out.append(command_text)
                changed = changed or command_changed
                continue
        out.append(ch)
        i += 1
    converted = "".join(out)
    return converted, changed or converted != label


PLAIN_ASCII_SYMBOLS: dict[str, str] = {
    "→": "->", "←": "<-", "↔": "<->", "⇒": "=>", "⇔": "<=>", "⇐": "<=", "↦": "|->",
    "≤": "<=", "≥": ">=", "≠": "!=", "≈": "~=", "≡": "==",
    "×": "*", "⋅": "*", "·": "*", "∙": "*", "∗": "*", "÷": "/",
    "±": "+/-", "∓": "-/+",
    "∞": "inf", "∑": "sum", "∏": "prod", "∫": "int", "∮": "oint", "√": "sqrt",
    "∈": " in ", "∉": " notin ", "⊆": " subseteq ", "⊂": " subset ", "⊇": " supseteq ", "⊃": " supset ",
    "∪": " union ", "∩": " intersect ", "∅": "emptyset", "∀": "forall", "∃": "exists",
    "∧": " and ", "∨": " or ", "¬": "not ", "⊢": "vdash", "⊨": "models", "⊥": "bot",
    "ℝ": "R", "ℤ": "Z", "ℕ": "N", "ℂ": "C", "ℚ": "Q", "𝔼": "E",
    "∇": "nabla", "∂": "partial", "∥": "parallel", "⟂": "perp", "⊗": "otimes", "⊕": "oplus", "⊙": "odot",
    "°": "deg", "†": "dagger", "…": "...", "⋯": "...", "⋮": ":", "⋰": "...", "⋱": "...", "⟨": "<", "⟩": ">", "〈": "<", "〉": ">", "⎯": "-",
}

GREEK_TO_ASCII: dict[str, str] = {
    "Α": "Alpha", "Β": "Beta", "Γ": "Gamma", "Δ": "Delta", "Ε": "Epsilon", "Ζ": "Zeta", "Η": "Eta",
    "Θ": "Theta", "Ι": "Iota", "Κ": "Kappa", "Λ": "Lambda", "Μ": "Mu", "Ν": "Nu", "Ξ": "Xi",
    "Ο": "Omicron", "Π": "Pi", "Ρ": "Rho", "Σ": "Sigma", "Τ": "Tau", "Υ": "Upsilon", "Φ": "Phi",
    "Χ": "Chi", "Ψ": "Psi", "Ω": "Omega",
    "α": "alpha", "β": "beta", "γ": "gamma", "δ": "delta", "ε": "epsilon", "ζ": "zeta", "η": "eta",
    "θ": "theta", "ι": "iota", "κ": "kappa", "λ": "lambda", "μ": "mu", "ν": "nu", "ξ": "xi",
    "ο": "o", "π": "pi", "ρ": "rho", "σ": "sigma", "ς": "varsigma", "τ": "tau", "υ": "upsilon",
    "φ": "phi", "χ": "chi", "ψ": "psi", "ω": "omega", "ϑ": "vartheta",
}

LATEX_NAME_TO_ASCII: dict[str, str] = {
    latex: ascii_name for symbol, ascii_name in GREEK_TO_ASCII.items()
    for latex in (SYMBOL_TO_LATEX.get(symbol),) if latex and latex.startswith("\\")
}
LATEX_NAME_TO_ASCII.update({
    r"\infty": "inf", r"\sum": "sum", r"\prod": "prod", r"\int": "int", r"\sqrt": "sqrt",
    r"\pm": "+/-", r"\mp": "-/+", r"\leq": "<=", r"\geq": ">=", r"\neq": "!=",
})

ASCII_TO_UNICODE_SEQUENCES: tuple[tuple[str, str], ...] = (
    ("<->", "↔"), ("<=>", "⇔"), ("->", "→"), ("<-", "←"), ("=>", "⇒"),
    ("<=", "≤"), (">=", "≥"), ("!=", "≠"), ("+-", "±"),
)

ACADEMIC_UNICODE_NORMALS: dict[str, str] = {
    "·": "⋅",
    "∙": "⋅",
    "•": "∙",
    "−": "-",
    "∼": "~",
}


def default_output_folder_name_for(output_convention: str) -> str:
    """Return the default generated subfolder for the selected target convention."""
    return {
        OUTPUT_CONVENTION_LATEX: "LaTeX version",
        OUTPUT_CONVENTION_PLAIN_ASCII: "Plain ASCII math version",
        OUTPUT_CONVENTION_UNICODE_MATH: "UnicodeMath version",
        OUTPUT_CONVENTION_UNICODE_ACADEMIC: "Unicode academic version",
        OUTPUT_CONVENTION_UNICODE_CHARSET: "Unicode symbols version",
    }.get(output_convention, DEFAULT_OUTPUT_FOLDER_NAME)


def replace_ascii_math_sequences_with_unicode(text: str) -> str:
    """Convert common plain ASCII math sequences to Unicode symbols."""
    out = text
    for ascii_text, unicode_text in ASCII_TO_UNICODE_SEQUENCES:
        out = out.replace(ascii_text, unicode_text)
    # Whole-word pragmatic names. Keep this intentionally small to avoid
    # changing ordinary prose such as "pin" -> "πn".
    word_map = {
        "alpha": "α", "beta": "β", "gamma": "γ", "delta": "δ", "epsilon": "ε",
        "theta": "θ", "lambda": "λ", "mu": "μ", "pi": "π", "sigma": "σ", "omega": "ω",
        "inf": "∞",
    }
    for word, symbol in word_map.items():
        out = re.sub(rf"\b{re.escape(word)}\b", symbol, out)
    return out


def normalize_unicode_academic(text: str) -> tuple[str, bool]:
    """Apply conservative Unicode normalization for academic/math notation."""
    out = replace_ascii_math_sequences_with_unicode(text)
    changed = out != text
    chars: list[str] = []
    for ch in out:
        repl = ACADEMIC_UNICODE_NORMALS.get(ch, ch)
        chars.append(repl)
        changed = changed or repl != ch
    return "".join(chars), changed


def latex_structures_to_linear(text: str, *, plain_ascii: bool) -> tuple[str, bool]:
    """Convert structural LaTeX like \frac{a}{b} into linear notation.

    This is intentionally pragmatic. Unknown commands are preserved and later
    handled by the normal LaTeX->symbol converter.
    """
    out: list[str] = []
    changed = False
    i = 0
    while i < len(text):
        if text.startswith(r"\frac", i) and _macro_boundary_ok(text, i, r"\frac"):
            first = read_latex_group_raw(text, i + len(r"\frac"))
            if first is not None:
                numerator, after_num = first
                second = read_latex_group_raw(text, after_num)
                if second is not None:
                    denominator, after_den = second
                    num_text, num_changed = latex_structures_to_linear(numerator, plain_ascii=plain_ascii)
                    den_text, den_changed = latex_structures_to_linear(denominator, plain_ascii=plain_ascii)
                    out.append(f"({num_text})/({den_text})")
                    changed = True or num_changed or den_changed
                    i = after_den
                    continue
        if text.startswith(r"\sqrt", i) and _macro_boundary_ok(text, i, r"\sqrt"):
            group = read_latex_group_raw(text, i + len(r"\sqrt"))
            if group is not None:
                inner, end = group
                inner_text, inner_changed = latex_structures_to_linear(inner, plain_ascii=plain_ascii)
                fn = "sqrt" if plain_ascii else "√"
                out.append(f"{fn}({inner_text})")
                changed = True or inner_changed
                i = end
                continue
        out.append(text[i])
        i += 1
    return "".join(out), changed


def script_piece_to_ascii(piece: str) -> str:
    """Convert a script-run piece into plain ASCII when possible."""
    return LATEX_NAME_TO_ASCII.get(piece, piece)


def script_text_to_linear(pieces: list[str], op: str) -> str:
    inner = "".join(script_piece_to_ascii(piece) for piece in pieces)
    if len(inner) == 1 and inner.isalnum():
        return op + inner
    return op + "{" + inner + "}"


def unicode_scripts_to_linear(text: str) -> tuple[str, bool]:
    """Convert Unicode sub/superscript runs into _{...}/^{...} linear syntax."""
    out: list[str] = []
    changed = False
    i = 0
    while i < len(text):
        ch = text[i]
        if ch in SUBSCRIPT_CHARS:
            pieces, i = read_script_run(text, i, SUBSCRIPT_CHARS)
            out.append(script_text_to_linear(pieces, "_"))
            changed = True
            continue
        if ch in SUPERSCRIPT_CHARS:
            pieces, i = read_script_run(text, i, SUPERSCRIPT_CHARS)
            out.append(script_text_to_linear(pieces, "^"))
            changed = True
            continue
        out.append(ch)
        i += 1
    return "".join(out), changed


def unicode_to_plain_ascii(text: str) -> tuple[str, bool]:
    """Convert Unicode/math-symbol text into pragmatic plain ASCII notation."""
    linear, changed = unicode_scripts_to_linear(text)
    out: list[str] = []
    for ch in linear:
        if ch in GREEK_TO_ASCII:
            out.append(GREEK_TO_ASCII[ch])
            changed = True
        elif ch in PLAIN_ASCII_SYMBOLS:
            out.append(PLAIN_ASCII_SYMBOLS[ch])
            changed = True
        elif not ch.isascii():
            repl, normalized, fallback = safe_ascii_fallback_for_unicode(ch)
            if fallback:
                repl = f"U+{ord(ch):04X}"
            out.append(repl)
            changed = True or normalized or fallback
        else:
            out.append(ch)
    converted = "".join(out)
    converted = re.sub(r"\s+", " ", converted).strip() if converted.strip() else converted
    return converted, changed or converted != text


def convert_label_to_plain_ascii(label: str) -> tuple[str, bool]:
    """Convert mixed LaTeX/Unicode labels to pragmatic plain ASCII math notation."""
    linear_latex, changed_struct = latex_structures_to_linear(label, plain_ascii=True)
    symbol_text, changed_symbols = convert_label_to_symbols(linear_latex)
    plain_text, changed_plain = unicode_to_plain_ascii(symbol_text)
    return plain_text, changed_struct or changed_symbols or changed_plain or plain_text != label


def convert_label_to_unicode_math(label: str) -> tuple[str, bool]:
    """Convert mixed labels to a UnicodeMath-like linear notation.

    Unicode symbols are kept, while scripts are expressed using _ and ^ so the
    label remains editable as a linear string.
    """
    linear_latex, changed_struct = latex_structures_to_linear(label, plain_ascii=False)
    symbol_text, changed_symbols = convert_label_to_symbols(linear_latex)
    academic_text, changed_academic = normalize_unicode_academic(symbol_text)
    linear_scripts, changed_scripts = unicode_scripts_to_linear(academic_text)
    return linear_scripts, changed_struct or changed_symbols or changed_academic or changed_scripts or linear_scripts != label


def convert_label_to_unicode_academic(label: str) -> tuple[str, bool]:
    """Convert mixed labels to Unicode using conservative academic norms."""
    symbol_text, changed_symbols = convert_label_to_symbols(label)
    academic_text, changed_academic = normalize_unicode_academic(symbol_text)
    return academic_text, changed_symbols or changed_academic or academic_text != label


def convert_label_to_unicode_charset(label: str) -> tuple[str, bool]:
    """Convert mixed labels to readable Unicode characters without charset limits."""
    symbol_text, changed_symbols = convert_label_to_symbols(label)
    unicode_text, changed_unicode = normalize_unicode_academic(symbol_text)
    return unicode_text, changed_symbols or changed_unicode or unicode_text != label


def collect_filter_metric_limits(
    input_dir: Path,
    recursive: bool,
    space_mode: str,
    existing_latex_mode: str,
    escape_literal_specials: bool,
    conversion_direction: str,
    use_hybrid_tokens: bool = False,
) -> tuple[FilterMetricLimits, Counter[str], list[str]]:
    """Collect actual max values for the active dataset and conversion options.

    Frequency is measured on final output labels. Length and unique counts are
    measured in tokenizer tokens for the final output labels, using the selected
    tokenization mode.
    """
    output_labels: list[str] = []
    errors: list[str] = []
    for path in iter_json_files(input_dir, recursive):
        try:
            data = load_json(path)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{path.name}: {exc}")
            continue

        for _label_path, before in find_labels(data):
            after, _space_action, _escape_action, _preserve_action, _unicode_action = convert_label_with_options(
                before,
                space_mode,
                existing_latex_mode,
                escape_literal_specials,
                conversion_direction,
            )
            output_labels.append(after)

    if conversion_direction == OUTPUT_CONVENTION_LATEX:
        output_labels, _guarded_commands, _normalized_count = normalize_latex_string_token_guard_labels(output_labels)

    output_label_counts: Counter[str] = Counter(output_labels)
    scan_tokens = hybrid_audit_scan_tokens(output_labels) if use_hybrid_tokens else None
    max_length = 0
    max_unique = 0
    for after in output_labels:
        token_items = tokenize_label_for_coverage(after, scan_tokens)
        max_length = max(max_length, len(token_items))
        max_unique = max(max_unique, len(set(token_items)))

    return (
        FilterMetricLimits(
            max_frequency=max(output_label_counts.values(), default=1),
            max_length=max(0, max_length),
            max_unique=max(0, max_unique),
        ),
        output_label_counts,
        errors,
    )


def label_entry_id(file_path: Path, label_path: str) -> LabelEntryId:
    return file_path, label_path


def passes_length_unique_filters(row: LabelPreview, options: FrequencyFilterOptions) -> bool:
    """Return True when a row passes the optional token-complexity filters."""
    if options.length_enabled:
        if row.after_token_length < options.min_length or row.after_token_length > options.max_length:
            return False
    if options.unique_enabled:
        if row.unique_after_tokens < options.min_unique or row.unique_after_tokens > options.max_unique:
            return False
    return True


def lower_median(values: list[int]) -> int:
    """Return the lower median of a non-empty list of positive counts."""
    if not values:
        return 0
    ordered = sorted(values)
    return ordered[(len(ordered) - 1) // 2]


def median_floor(values: list[int]) -> int:
    """Return the standard median, floored to an integer for even-sized lists."""
    if not values:
        return 0
    ordered = sorted(values)
    mid = len(ordered) // 2
    if len(ordered) % 2:
        return ordered[mid]
    return (ordered[mid - 1] + ordered[mid]) // 2


def percentile_floor(values: list[int], percentile: float) -> int:
    """Return a linearly interpolated percentile, floored to an integer."""
    if not values:
        return 0
    ordered = sorted(values)
    if len(ordered) == 1:
        return ordered[0]
    pos = max(0.0, min(1.0, percentile)) * (len(ordered) - 1)
    low = int(pos)
    high = min(low + 1, len(ordered) - 1)
    frac = pos - low
    value = ordered[low] + (ordered[high] - ordered[low]) * frac
    return int(value)


def auto_max_per_label_value(class_counts: list[int], mode: str) -> int:
    """Resolve an automatic per-label cap from eligible output-label class counts."""
    if not class_counts:
        return 0
    if mode == MAX_PER_LABEL_MODE_AUTO_P25:
        return percentile_floor(class_counts, 0.25)
    if mode == MAX_PER_LABEL_MODE_AUTO_MEDIAN:
        return median_floor(class_counts)
    if mode == MAX_PER_LABEL_MODE_AUTO_MIN_ELIGIBLE:
        return min(class_counts)
    # Default and backward-compatible behavior.
    return lower_median(class_counts)


def max_per_label_mode_short_name(mode: str) -> str:
    """Return a compact status-bar label for the selected max-per-label mode."""
    if mode.startswith("Auto: "):
        return "auto " + mode.removeprefix("Auto: ")
    return mode.casefold()


def tooltip_for_max_per_label_mode(mode: str) -> str:
    """Return the explanatory tooltip for a max-per-label mode."""
    return MAX_PER_LABEL_MODE_TOOLTIPS.get(mode, MAX_PER_LABEL_MODE_TOOLTIPS[MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN])


def resolved_max_per_label(class_counts: list[int], options: FrequencyFilterOptions) -> int:
    """Return the manual cap, or the selected automatic cap for eligible classes."""
    if not options.max_count_auto:
        return max(1, options.max_count)
    return max(1, auto_max_per_label_value(class_counts, options.max_count_mode))


def resolved_max_per_label_for_rows(
    candidate_rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> int | None:
    """Return the effective max-per-label for the current rows/options."""
    if not options.enabled:
        return None
    eligible_rows = [row for row in candidate_rows if passes_length_unique_filters(row, options)]
    rows_by_output_label: dict[str, list[LabelPreview]] = {}
    for row in eligible_rows:
        rows_by_output_label.setdefault(row.after, []).append(row)
    class_counts = [len(rows) for rows in rows_by_output_label.values() if len(rows) >= options.min_count]
    if not class_counts:
        return None
    return resolved_max_per_label(class_counts, options)


def stable_seed(base_seed: int, salt: str) -> int:
    """Make reproducible shuffle seeds independent of Python's hash randomization."""
    digest = hashlib.sha256(f"{base_seed}:{salt}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big", signed=False)


def balanced_sample_rows_by_file(
    rows: list[LabelPreview],
    *,
    cap: int,
    seed: int,
    salt: str,
    row_sort_key: Callable[[LabelPreview], object] | None = None,
) -> set[LabelEntryId]:
    """Sample rows deterministically while mixing source JSON files.

    Rows are grouped by source file, shuffled deterministically within each file,
    then selected round-robin across files until ``cap`` rows are chosen. This
    keeps a very common output label from being represented by only the first
    source file in sorted order.
    """
    if cap <= 0 or not rows:
        return set()
    if cap >= len(rows):
        return {label_entry_id(row.file_path, row.label_path) for row in rows}

    by_file: dict[Path, list[LabelPreview]] = {}
    for row in rows:
        by_file.setdefault(row.file_path, []).append(row)

    rng_files = random.Random(stable_seed(seed, salt + ":files"))
    files = sorted(by_file, key=lambda path: path.as_posix())
    rng_files.shuffle(files)

    queues: dict[Path, list[LabelPreview]] = {}
    for file_path in files:
        queue = list(by_file[file_path])
        rng = random.Random(stable_seed(seed, salt + ":" + file_path.as_posix()))
        rng.shuffle(queue)
        if row_sort_key is not None:
            queue.sort(key=row_sort_key)
        queues[file_path] = queue

    selected: set[LabelEntryId] = set()
    while files and len(selected) < cap:
        next_files: list[Path] = []
        for file_path in files:
            queue = queues[file_path]
            if not queue:
                continue
            row = queue.pop(0)
            selected.add(label_entry_id(row.file_path, row.label_path))
            if len(selected) >= cap:
                break
            if queue:
                next_files.append(file_path)
        files = next_files
    return selected


def token_unit_mode_summary(mode: str, use_hybrid_tokens: bool) -> str:
    """Return a compact label for token/character coverage mode."""
    if mode == TOKEN_AUDIT_MODE_AUTO:
        return "string+chars" if use_hybrid_tokens else "chars"
    if mode == TOKEN_AUDIT_MODE_HYBRID:
        return "string+chars"
    return "chars"


def row_token_items_and_label_counts(
    rows: list[LabelPreview],
    *,
    use_hybrid_tokens: bool,
) -> tuple[dict[LabelEntryId, set[str]], Counter[str]]:
    """Return per-row token sets plus label-count coverage for those tokens."""
    labels = [row.after for row in rows]
    scan_tokens = hybrid_audit_scan_tokens(labels) if use_hybrid_tokens else None
    row_items: dict[LabelEntryId, set[str]] = {}
    label_counts: Counter[str] = Counter()
    for row in rows:
        entry_id = label_entry_id(row.file_path, row.label_path)
        items = set(tokenize_label_for_coverage(row.after, scan_tokens))
        row_items[entry_id] = items
        label_counts.update(items)
    return row_items, label_counts


def rare_token_sort_key(
    row: LabelPreview,
    row_items: dict[LabelEntryId, set[str]],
    token_label_counts: Counter[str],
) -> tuple[int, int, str, str]:
    """Sort rows so labels containing rarer tokens are preferred first."""
    entry_id = label_entry_id(row.file_path, row.label_path)
    items = row_items.get(entry_id, set())
    if not items:
        rarest_count = MAX_FILTER_VALUE
        total_count = MAX_FILTER_VALUE
    else:
        counts = [token_label_counts[item] for item in items]
        rarest_count = min(counts)
        total_count = sum(counts)
    return (rarest_count, total_count, row.file_path.as_posix(), row.label_path)


def apply_token_coverage_filter(
    rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> tuple[list[LabelPreview], dict[LabelEntryId, set[str]], Counter[str]]:
    """Apply optional rare-token exclusion and return token coverage metadata."""
    row_items, token_label_counts = row_token_items_and_label_counts(
        rows,
        use_hybrid_tokens=options.token_use_hybrid_tokens,
    )
    if not options.token_filter_enabled:
        return rows, row_items, token_label_counts

    min_count = max(1, options.token_min_label_count)
    kept_rows = [
        row
        for row in rows
        if all(
            token_label_counts[item] >= min_count
            for item in row_items.get(label_entry_id(row.file_path, row.label_path), set())
        )
    ]
    return kept_rows, row_items, token_label_counts


def row_token_occurrence_lists(
    rows: list[LabelPreview],
    *,
    use_hybrid_tokens: bool,
) -> dict[LabelEntryId, list[str]]:
    """Return per-row token occurrence lists for total-occurrence balancing."""
    labels = [row.after for row in rows]
    scan_tokens = hybrid_audit_scan_tokens(labels) if use_hybrid_tokens else None
    row_tokens: dict[LabelEntryId, list[str]] = {}
    for row in rows:
        row_tokens[label_entry_id(row.file_path, row.label_path)] = tokenize_label_for_coverage(row.after, scan_tokens)
    return row_tokens


def resolved_token_occurrence_target_max_from_counts(
    token_counts: Counter[str],
    options: FrequencyFilterOptions,
) -> int:
    """Resolve the target maximum occurrence count for token balancing."""
    if options.token_occurrence_target_auto:
        return auto_max_per_label_value(
            [count for count in token_counts.values() if count > 0],
            options.token_occurrence_target_mode,
        )
    return options.token_occurrence_target_max


def total_token_counts_for_rows(
    rows: list[LabelPreview],
    row_tokens: dict[LabelEntryId, list[str]],
) -> Counter[str]:
    """Count total token occurrences across rows, including duplicates inside labels."""
    counts: Counter[str] = Counter()
    for row in rows:
        counts.update(row_tokens.get(label_entry_id(row.file_path, row.label_path), []))
    return counts


def resolved_token_occurrence_target_range_from_counts(
    token_counts: Counter[str],
    options: FrequencyFilterOptions,
) -> tuple[int, int]:
    """Resolve the hard total-occurrence range for each tokenizer token.

    The minimum is a hard availability filter: tokens whose total occurrences in
    the eligible candidate rows are below this value cause their rows to be
    removed before balancing. The maximum is a hard selected-count cap: rows are
    not selected when adding them would push any token over the cap.
    """
    target_min = max(0, options.token_occurrence_min_target)
    target_max = max(0, resolved_token_occurrence_target_max_from_counts(token_counts, options))
    return target_min, max(target_min, target_max)


def filter_groups_by_token_occurrence_min(
    eligible_groups: dict[str, list[LabelPreview]],
    row_tokens: dict[LabelEntryId, list[str]],
    target_min: int,
    *,
    min_rows_per_label: int = 1,
) -> tuple[dict[str, list[LabelPreview]], Counter[str], set[str], int]:
    """Hard-exclude rows containing tokens below the total-occurrence minimum."""
    all_rows = [row for rows in eligible_groups.values() for row in rows]
    available_counts = total_token_counts_for_rows(all_rows, row_tokens)
    if target_min <= 0:
        return eligible_groups, available_counts, set(), 0

    under_min_tokens = {token for token, count in available_counts.items() if count < target_min}
    if not under_min_tokens:
        return eligible_groups, available_counts, set(), 0

    filtered_groups: dict[str, list[LabelPreview]] = {}
    excluded_count = 0
    for label, rows in eligible_groups.items():
        kept_rows: list[LabelPreview] = []
        for row in rows:
            tokens = set(row_tokens.get(label_entry_id(row.file_path, row.label_path), []))
            if tokens & under_min_tokens:
                excluded_count += 1
            else:
                kept_rows.append(row)
        if len(kept_rows) >= min_rows_per_label:
            filtered_groups[label] = kept_rows

    filtered_rows = [row for rows in filtered_groups.values() for row in rows]
    filtered_counts = total_token_counts_for_rows(filtered_rows, row_tokens)
    return filtered_groups, filtered_counts, under_min_tokens, excluded_count


def token_occurrence_row_fits_cap(
    tokens: list[str],
    selected_token_counts: Counter[str],
    target_max: int,
) -> bool:
    """Return True if adding a row keeps every token at or below the max cap."""
    if target_max <= 0:
        return False
    for token, amount in Counter(tokens).items():
        if selected_token_counts[token] + amount > target_max:
            return False
    return True


def token_occurrence_marginal_score(
    row: LabelPreview,
    row_tokens: dict[LabelEntryId, list[str]],
    baseline_token_counts: Counter[str],
    selected_token_counts: Counter[str],
    target_min: int,
    target_max: int,
) -> float:
    """Score a candidate row while enforcing a hard per-token max cap.

    Rows that would push any token above the selected-count maximum are not
    selectable. Among rows that fit, prefer labels that move selected token
    counts toward the minimum range first, then fill remaining capacity with
    rarer tokens.
    """
    tokens = row_tokens.get(label_entry_id(row.file_path, row.label_path), [])
    if not tokens or not token_occurrence_row_fits_cap(tokens, selected_token_counts, target_max):
        return float("-inf")

    min_denom = max(1, target_min)
    max_denom = max(1, target_max)
    occurrences = Counter(tokens)
    score = 0.0
    for token, amount in occurrences.items():
        current = selected_token_counts[token]
        available = max(1, baseline_token_counts[token])

        if target_min > 0 and current < target_min:
            fills_to_min = min(amount, target_min - current)
            score += 12.0 * (fills_to_min / min_denom)

        remaining_capacity = max(0, target_max - current)
        fills_under_max = min(amount, remaining_capacity)
        score += 1.5 * (fills_under_max / max_denom)

        # Rarity bonus uses total available occurrences, not label-counts.
        # This keeps uncommon string/character tokens from being crowded out.
        score += 2.0 * (amount / available)

        if current == 0:
            score += 0.75

    # Slightly prefer shorter rows when scores tie, because long rows consume
    # more of several token caps at once.
    score -= 0.001 * len(tokens)
    return score


def deterministic_row_queue(rows: list[LabelPreview], *, salt: str) -> list[LabelPreview]:
    """Return a reproducibly shuffled queue for rows from one output-label class."""
    queue = sorted(rows, key=lambda row: (row.file_path.as_posix(), row.label_path))
    rng = random.Random(stable_seed(BALANCE_RANDOM_SEED, salt))
    rng.shuffle(queue)
    return queue


def select_rows_with_token_occurrence_balance_current(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> set[LabelEntryId]:
    """Select rows with hard total-occurrence min/max balancing.

    Tokens below the minimum total-occurrence threshold are removed by excluding
    any row that contains them. Then rows are selected greedily while enforcing
    a hard maximum count for every character or string token. Exact-label caps
    are still respected when frequency balancing is enabled.
    """
    if max_per_label <= 0 or not eligible_groups:
        return set()

    all_rows = [row for rows in eligible_groups.values() for row in rows]
    row_tokens = row_token_occurrence_lists(
        all_rows,
        use_hybrid_tokens=options.token_use_hybrid_tokens,
    )

    # Hard min filter: if a token does not appear often enough in the candidate
    # rows, exclude every row containing that token. This uses total occurrences
    # rather than per-label presence, and it applies to both character tokens and
    # string tokens.
    initial_counts = total_token_counts_for_rows(all_rows, row_tokens)
    target_min = max(0, options.token_occurrence_min_target)
    min_rows_per_label = options.min_count if options.enabled else 1
    eligible_groups, filtered_counts, _under_min_tokens, _excluded_count = filter_groups_by_token_occurrence_min(
        eligible_groups,
        row_tokens,
        target_min,
        min_rows_per_label=min_rows_per_label,
    )
    if not eligible_groups:
        return set()

    # Resolve the hard max after rare-token rows are removed. For auto modes,
    # this lets the cap reflect the actual pool being balanced.
    target_min, target_max = resolved_token_occurrence_target_range_from_counts(
        filtered_counts if filtered_counts else initial_counts,
        options,
    )
    target_max = max(target_min, target_max)
    if target_max <= 0:
        return set()

    queues: dict[str, list[LabelPreview]] = {
        label: deterministic_row_queue(rows, salt="token-occurrence:" + label)
        for label, rows in eligible_groups.items()
        if rows
    }
    per_label_caps = {label: min(max_per_label, len(rows)) for label, rows in eligible_groups.items() if rows}
    selected_per_label: Counter[str] = Counter()
    selected_token_counts: Counter[str] = Counter()
    selected_ids: set[LabelEntryId] = set()

    def best_candidate(labels: Iterable[str]) -> tuple[float, str] | None:
        best: tuple[float, str] | None = None
        for label in labels:
            queue = queues.get(label, [])
            if not queue:
                continue
            if selected_per_label[label] >= per_label_caps.get(label, 0):
                continue
            score = token_occurrence_marginal_score(
                queue[0],
                row_tokens,
                filtered_counts,
                selected_token_counts,
                target_min,
                target_max,
            )
            if score == float("-inf"):
                continue
            candidate = (score, label)
            if best is None or candidate > best:
                best = candidate
        return best

    def select_next(label: str) -> None:
        row = queues[label].pop(0)
        selected_per_label[label] += 1
        selected_ids.add(label_entry_id(row.file_path, row.label_path))
        selected_token_counts.update(row_tokens.get(label_entry_id(row.file_path, row.label_path), []))

    # First pass: try to keep one row for as many exact output labels as possible
    # without exceeding any token max cap. Labels that cannot fit are clipped out.
    remaining_labels = {label for label, queue in queues.items() if queue and per_label_caps.get(label, 0) > 0}
    while remaining_labels:
        best = best_candidate(remaining_labels)
        if best is None:
            break
        _score, best_label = best
        select_next(best_label)
        remaining_labels.remove(best_label)

    # Additional passes: fill duplicate rows up to exact-label caps, but never
    # allow a token's selected total occurrence count to exceed max.
    while True:
        best = best_candidate(queues.keys())
        if best is None:
            break
        _best_score, best_label = best
        select_next(best_label)

    return selected_ids



@dataclass(frozen=True)
class TokenOccurrenceBalanceSetup:
    """Precomputed state shared by token-occurrence balancing methods."""

    eligible_groups: dict[str, list[LabelPreview]]
    row_tokens: dict[LabelEntryId, list[str]]
    row_token_counts: dict[LabelEntryId, Counter[str]]
    filtered_counts: Counter[str]
    target_min: int
    target_max: int
    per_label_caps: dict[str, int]


def prepare_token_occurrence_balance_setup(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> TokenOccurrenceBalanceSetup | None:
    """Build shared token-occurrence state after hard-min filtering."""
    if max_per_label <= 0 or not eligible_groups:
        return None

    all_rows = [row for rows in eligible_groups.values() for row in rows]
    row_tokens = row_token_occurrence_lists(
        all_rows,
        use_hybrid_tokens=options.token_use_hybrid_tokens,
    )

    initial_counts = total_token_counts_for_rows(all_rows, row_tokens)
    target_min = max(0, options.token_occurrence_min_target)
    min_rows_per_label = options.min_count if options.enabled else 1
    eligible_groups, filtered_counts, _under_min_tokens, _excluded_count = filter_groups_by_token_occurrence_min(
        eligible_groups,
        row_tokens,
        target_min,
        min_rows_per_label=min_rows_per_label,
    )
    if not eligible_groups:
        return None

    target_min, target_max = resolved_token_occurrence_target_range_from_counts(
        filtered_counts if filtered_counts else initial_counts,
        options,
    )
    target_max = max(target_min, target_max)
    if target_max <= 0:
        return None

    row_token_counts: dict[LabelEntryId, Counter[str]] = {}
    for row in (row for rows in eligible_groups.values() for row in rows):
        row_id = label_entry_id(row.file_path, row.label_path)
        row_token_counts[row_id] = Counter(row_tokens.get(row_id, []))

    per_label_caps = {label: min(max_per_label, len(rows)) for label, rows in eligible_groups.items() if rows}
    return TokenOccurrenceBalanceSetup(
        eligible_groups=eligible_groups,
        row_tokens=row_tokens,
        row_token_counts=row_token_counts,
        filtered_counts=filtered_counts,
        target_min=target_min,
        target_max=target_max,
        per_label_caps=per_label_caps,
    )


def token_occurrence_counter_fits_cap(
    occurrences: Counter[str],
    selected_token_counts: Counter[str],
    target_max: int,
) -> bool:
    """Counter-based version of token_occurrence_row_fits_cap()."""
    if target_max <= 0 or not occurrences:
        return False
    for token, amount in occurrences.items():
        if selected_token_counts[token] + amount > target_max:
            return False
    return True


def token_occurrence_marginal_score_from_counter(
    occurrences: Counter[str],
    baseline_token_counts: Counter[str],
    selected_token_counts: Counter[str],
    target_min: int,
    target_max: int,
) -> float:
    """Score a candidate using a precomputed row token Counter."""
    if not token_occurrence_counter_fits_cap(occurrences, selected_token_counts, target_max):
        return float("-inf")

    min_denom = max(1, target_min)
    max_denom = max(1, target_max)
    score = 0.0
    token_total = 0
    for token, amount in occurrences.items():
        token_total += amount
        current = selected_token_counts[token]
        available = max(1, baseline_token_counts[token])

        if target_min > 0 and current < target_min:
            fills_to_min = min(amount, target_min - current)
            score += 12.0 * (fills_to_min / min_denom)

        remaining_capacity = max(0, target_max - current)
        fills_under_max = min(amount, remaining_capacity)
        score += 1.5 * (fills_under_max / max_denom)
        score += 2.0 * (amount / available)

        if current == 0:
            score += 0.75

    score -= 0.001 * token_total
    return score


def select_rows_with_token_occurrence_balance_optimized(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> set[LabelEntryId]:
    """Adaptive hard min/max token balancing with precomputed row metadata."""
    setup = prepare_token_occurrence_balance_setup(
        eligible_groups,
        max_per_label=max_per_label,
        options=options,
    )
    if setup is None:
        return set()

    queues: dict[str, list[LabelPreview]] = {
        label: deterministic_row_queue(rows, salt="token-occurrence:" + label)
        for label, rows in setup.eligible_groups.items()
        if rows
    }
    queue_indices = {label: 0 for label in queues}
    selected_per_label: Counter[str] = Counter()
    selected_token_counts: Counter[str] = Counter()
    selected_ids: set[LabelEntryId] = set()

    def front_row(label: str) -> LabelPreview | None:
        queue = queues.get(label, [])
        idx = queue_indices.get(label, 0)
        if idx >= len(queue):
            return None
        return queue[idx]

    def best_candidate(labels: Iterable[str]) -> tuple[float, str] | None:
        best: tuple[float, str] | None = None
        for label in labels:
            row = front_row(label)
            if row is None:
                continue
            if selected_per_label[label] >= setup.per_label_caps.get(label, 0):
                continue
            row_id = label_entry_id(row.file_path, row.label_path)
            score = token_occurrence_marginal_score_from_counter(
                setup.row_token_counts.get(row_id, Counter()),
                setup.filtered_counts,
                selected_token_counts,
                setup.target_min,
                setup.target_max,
            )
            if score == float("-inf"):
                continue
            candidate = (score, label)
            if best is None or candidate > best:
                best = candidate
        return best

    def select_next(label: str) -> None:
        row = queues[label][queue_indices[label]]
        queue_indices[label] += 1
        selected_per_label[label] += 1
        row_id = label_entry_id(row.file_path, row.label_path)
        selected_ids.add(row_id)
        selected_token_counts.update(setup.row_token_counts.get(row_id, Counter()))

    remaining_labels = {
        label
        for label, queue in queues.items()
        if queue and setup.per_label_caps.get(label, 0) > 0
    }
    while remaining_labels:
        best = best_candidate(remaining_labels)
        if best is None:
            break
        _score, best_label = best
        select_next(best_label)
        remaining_labels.remove(best_label)

    while True:
        best = best_candidate(queues.keys())
        if best is None:
            break
        _best_score, best_label = best
        select_next(best_label)

    return selected_ids


def token_occurrence_static_row_score(
    row: LabelPreview,
    setup: TokenOccurrenceBalanceSetup,
) -> float:
    """Static score used by the fast two-pass sampler."""
    row_id = label_entry_id(row.file_path, row.label_path)
    occurrences = setup.row_token_counts.get(row_id, Counter())
    if not occurrences:
        return float("-inf")

    min_denom = max(1, setup.target_min)
    max_denom = max(1, setup.target_max)
    token_total = 0
    score = 0.0
    for token, amount in occurrences.items():
        token_total += amount
        available = max(1, setup.filtered_counts[token])
        if setup.target_min > 0:
            score += 12.0 * (min(amount, setup.target_min) / min_denom)
        score += 1.5 * (min(amount, setup.target_max) / max_denom)
        score += 2.0 * (amount / available)
        score += 0.75
    score -= 0.001 * token_total
    return score


def token_occurrence_two_pass_tiebreak(row: LabelPreview) -> int:
    """Deterministic pseudo-random tiebreak for the static two-pass method."""
    row_id = label_entry_id(row.file_path, row.label_path)
    return stable_seed(BALANCE_RANDOM_SEED, f"token-occurrence-two-pass:{row.after}:{row_id[0].as_posix()}:{row_id[1]}")


def select_rows_with_token_occurrence_balance_two_pass(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> set[LabelEntryId]:
    """Fast hard min/max token balancing using one static sort and two passes."""
    setup = prepare_token_occurrence_balance_setup(
        eligible_groups,
        max_per_label=max_per_label,
        options=options,
    )
    if setup is None:
        return set()

    all_rows = [row for rows in setup.eligible_groups.values() for row in rows]
    rows_by_score = sorted(
        all_rows,
        key=lambda row: (
            -token_occurrence_static_row_score(row, setup),
            token_occurrence_two_pass_tiebreak(row),
            row.file_path.as_posix(),
            row.label_path,
        ),
    )

    selected_per_label: Counter[str] = Counter()
    selected_token_counts: Counter[str] = Counter()
    selected_ids: set[LabelEntryId] = set()

    def try_select(row: LabelPreview) -> bool:
        row_id = label_entry_id(row.file_path, row.label_path)
        if row_id in selected_ids:
            return False
        if selected_per_label[row.after] >= setup.per_label_caps.get(row.after, 0):
            return False
        occurrences = setup.row_token_counts.get(row_id, Counter())
        if not token_occurrence_counter_fits_cap(occurrences, selected_token_counts, setup.target_max):
            return False
        selected_ids.add(row_id)
        selected_per_label[row.after] += 1
        selected_token_counts.update(occurrences)
        return True

    # Pass 1: keep at most one row for as many exact output labels as possible.
    for row in rows_by_score:
        if selected_per_label[row.after] == 0:
            try_select(row)

    # Pass 2: fill duplicate rows up to exact-label caps while enforcing max.
    for row in rows_by_score:
        try_select(row)

    return selected_ids


def token_occurrence_prune_tiebreak(row: LabelPreview) -> int:
    """Deterministic pseudo-random tiebreak for prune-from-full deletion."""
    row_id = label_entry_id(row.file_path, row.label_path)
    return stable_seed(BALANCE_RANDOM_SEED, f"token-occurrence-prune:{row.after}:{row_id[0].as_posix()}:{row_id[1]}")


def token_occurrence_prune_drop_score(
    row: LabelPreview,
    occurrences: Counter[str],
    selected_token_counts: Counter[str],
    selected_per_label: Counter[str],
    setup: TokenOccurrenceBalanceSetup,
    options: FrequencyFilterOptions,
) -> float:
    """Score how useful it is to remove a whole row from the selected set.

    Higher is better for deletion. The score rewards removing occurrences from
    currently over-cap tokens and from exact-label classes above their cap. It
    penalizes damage to rare tokens, tokens near the target minimum, and labels
    that are already close to their desired floor. This keeps the matrix-style
    pruning fast while avoiding purely random deletion of valuable rare-token
    rows.
    """
    if not occurrences:
        return float("-inf")

    score = 0.0
    token_total = sum(occurrences.values())
    max_denom = max(1, setup.target_max)
    min_denom = max(1, setup.target_min)

    label_count = selected_per_label[row.after]
    label_cap = setup.per_label_caps.get(row.after, 0)
    if label_count > label_cap:
        # Row deletion is always useful when the exact output-label class is
        # above its cap. Larger overage gets a larger bonus.
        score += 35.0 * ((label_count - label_cap) / max(1, label_cap))

    for token, amount in occurrences.items():
        current = selected_token_counts[token]
        available = max(1, setup.filtered_counts[token])
        overage = max(0, current - setup.target_max)
        if overage > 0:
            # Reward the part of this row that actually fixes the current
            # over-cap amount. Whole rows are removed, so this can also reduce
            # other tokens; those effects are handled by the penalties below.
            score += 80.0 * (min(amount, overage) / max_denom)

        if setup.target_min > 0:
            after_remove = current - amount
            if after_remove < setup.target_min:
                # Strongly protect tokens that would fall below the desired
                # lower range after this row is removed. This is a soft penalty
                # because sometimes every possible deletion damages such a token.
                score -= 45.0 * ((setup.target_min - after_remove) / min_denom)
            elif current <= setup.target_min:
                score -= 12.0 * (amount / min_denom)

        # Protect rarer tokens even when they are not near the minimum.
        score -= 8.0 * (amount / available)

    if options.enabled:
        desired_label_floor = min(options.min_count, max(1, label_cap))
    else:
        desired_label_floor = 1
    if label_count - 1 < desired_label_floor:
        score -= 18.0 * (desired_label_floor - (label_count - 1))

    # Prefer removing shorter rows when the main effects are tied: a short row
    # fixes the offending column with less collateral damage to unrelated caps.
    score -= 0.001 * token_total
    return score


def select_rows_with_token_occurrence_balance_prune_full(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> set[LabelEntryId]:
    """Hard min/max token balancing by pruning down from the full eligible set.

    This is the matrix-prune style method: after hard-min token filtering, every
    eligible row starts selected. While any token column is above the hard max,
    or any exact-label class is above its cap, remove a whole row whose removal
    best reduces over-cap tokens/labels while protecting rare and near-minimum
    tokens.
    """
    setup = prepare_token_occurrence_balance_setup(
        eligible_groups,
        max_per_label=max_per_label,
        options=options,
    )
    if setup is None:
        return set()

    selected_rows: dict[LabelEntryId, LabelPreview] = {}
    selected_per_label: Counter[str] = Counter()
    selected_token_counts: Counter[str] = Counter()
    for rows in setup.eligible_groups.values():
        for row in rows:
            row_id = label_entry_id(row.file_path, row.label_path)
            selected_rows[row_id] = row
            selected_per_label[row.after] += 1
            selected_token_counts.update(setup.row_token_counts.get(row_id, Counter()))

    if not selected_rows:
        return set()

    def overfull_tokens() -> set[str]:
        return {token for token, count in selected_token_counts.items() if count > setup.target_max}

    def overfull_labels() -> set[str]:
        return {
            label
            for label, count in selected_per_label.items()
            if count > setup.per_label_caps.get(label, 0)
        }

    while True:
        tokens_over = overfull_tokens()
        labels_over = overfull_labels()
        if not tokens_over and not labels_over:
            break

        best: tuple[float, int, str, LabelEntryId] | None = None
        for row_id, row in selected_rows.items():
            occurrences = setup.row_token_counts.get(row_id, Counter())
            if row.after not in labels_over and not (set(occurrences) & tokens_over):
                continue
            score = token_occurrence_prune_drop_score(
                row,
                occurrences,
                selected_token_counts,
                selected_per_label,
                setup,
                options,
            )
            if score == float("-inf"):
                continue
            candidate = (
                score,
                token_occurrence_prune_tiebreak(row),
                row.file_path.as_posix() + "::" + row.label_path,
                row_id,
            )
            if best is None or candidate > best:
                best = candidate

        if best is None:
            # Defensive escape hatch: this should be rare because every over-cap
            # token/label should have at least one selected row that contributes
            # to it. Return the best valid partial selection rather than loop.
            break

        _score, _tiebreak, _row_key, row_id_to_remove = best
        row_to_remove = selected_rows.pop(row_id_to_remove)
        selected_per_label[row_to_remove.after] -= 1
        if selected_per_label[row_to_remove.after] <= 0:
            del selected_per_label[row_to_remove.after]
        selected_token_counts.subtract(setup.row_token_counts.get(row_id_to_remove, Counter()))
        for token in list(selected_token_counts):
            if selected_token_counts[token] <= 0:
                del selected_token_counts[token]

    return set(selected_rows)


def select_rows_with_token_occurrence_balance(
    eligible_groups: dict[str, list[LabelPreview]],
    *,
    max_per_label: int,
    options: FrequencyFilterOptions,
) -> set[LabelEntryId]:
    """Dispatch to the selected token-occurrence balancing method."""
    mode = normalized_token_occurrence_balance_mode(options.token_occurrence_balance_mode)
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_OPTIMIZED:
        return select_rows_with_token_occurrence_balance_optimized(
            eligible_groups,
            max_per_label=max_per_label,
            options=options,
        )
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_TWO_PASS:
        return select_rows_with_token_occurrence_balance_two_pass(
            eligible_groups,
            max_per_label=max_per_label,
            options=options,
        )
    if mode == TOKEN_OCCURRENCE_BALANCE_METHOD_PRUNE_FULL:
        return select_rows_with_token_occurrence_balance_prune_full(
            eligible_groups,
            max_per_label=max_per_label,
            options=options,
        )
    return select_rows_with_token_occurrence_balance_current(
        eligible_groups,
        max_per_label=max_per_label,
        options=options,
    )



def ordered_total_token_counts_for_rows(
    rows: list[LabelPreview],
    *,
    use_hybrid_tokens: bool,
) -> list[tuple[str, int]]:
    """Return selected token/character occurrence counts in first-seen order."""
    if not rows:
        return []

    row_tokens = row_token_occurrence_lists(rows, use_hybrid_tokens=use_hybrid_tokens)
    counts: Counter[str] = Counter()
    order: list[str] = []
    for row in rows:
        row_id = label_entry_id(row.file_path, row.label_path)
        for token in row_tokens.get(row_id, []):
            if counts[token] == 0:
                order.append(token)
            counts[token] += 1
    return [(token, counts[token]) for token in order]


def ordered_token_counts_from_row_tokens(
    rows: list[LabelPreview],
    row_tokens: dict[LabelEntryId, list[str]],
) -> list[tuple[str, int]]:
    """Return occurrence counts from pre-tokenized rows in first-seen order."""
    counts: Counter[str] = Counter()
    order: list[str] = []
    for row in rows:
        row_id = label_entry_id(row.file_path, row.label_path)
        for token in row_tokens.get(row_id, []):
            if counts[token] == 0:
                order.append(token)
            counts[token] += 1
    return [(token, counts[token]) for token in order]


def token_kind_label(token: str, *, use_hybrid_tokens: bool) -> str:
    """Return a compact kind label for a token audit line."""
    if not use_hybrid_tokens:
        return "char"
    return "string" if len(token) > 1 else "char"


def build_token_occurrence_log_text(
    selected_rows: list[LabelPreview],
    candidate_rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> str:
    """Build the log-pane report for selected and hard-range-eliminated tokens."""
    unit_text = "string + character tokens" if options.token_use_hybrid_tokens else "characters only"
    lines: list[str] = []
    lines.append(f"Selected token occurrence counts ({unit_text}; {len(selected_rows)} selected row(s)):")
    selected_counts = ordered_total_token_counts_for_rows(
        selected_rows,
        use_hybrid_tokens=options.token_use_hybrid_tokens,
    )
    if selected_counts:
        for index, (token, count) in enumerate(selected_counts, start=1):
            kind = token_kind_label(token, use_hybrid_tokens=options.token_use_hybrid_tokens)
            lines.append(f"  {index:>3}. [{kind}] {display_token_item(token)} = {count}")
    else:
        lines.append("  (none)")

    lines.append("")
    lines.append("Tokens eliminated by hard-range token occurrence balancing:")
    if not options.token_occurrence_balance_enabled:
        lines.append("  (token occurrence balance is off)")
        return "\n".join(lines)

    eligible_rows = [row for row in candidate_rows if passes_length_unique_filters(row, options)]
    if options.charset_filter_enabled:
        eligible_rows, _charset_unsupported_counts, _charset_unsupported_examples = apply_charset_file_filter(eligible_rows, options)
    token_metadata_needed = (
        options.token_filter_enabled
        or (options.enabled and options.prefer_rare_tokens)
        or options.token_occurrence_balance_enabled
    )
    if token_metadata_needed:
        eligible_rows, _row_items, _token_label_counts = apply_token_coverage_filter(eligible_rows, options)

    rows_by_output_label: dict[str, list[LabelPreview]] = {}
    for row in eligible_rows:
        rows_by_output_label.setdefault(row.after, []).append(row)

    if options.enabled:
        eligible_groups = {
            label: rows
            for label, rows in rows_by_output_label.items()
            if len(rows) >= options.min_count
        }
    else:
        eligible_groups = {label: rows for label, rows in rows_by_output_label.items() if rows}

    if not eligible_groups:
        lines.append("  (no eligible rows reached the hard-range step)")
        return "\n".join(lines)

    all_rows = [row for rows in eligible_groups.values() for row in rows]
    row_tokens = row_token_occurrence_lists(
        all_rows,
        use_hybrid_tokens=options.token_use_hybrid_tokens,
    )
    target_min = max(0, options.token_occurrence_min_target)
    min_rows_per_label = options.min_count if options.enabled else 1
    filtered_groups, filtered_counts, under_min_tokens, excluded_count = filter_groups_by_token_occurrence_min(
        eligible_groups,
        row_tokens,
        target_min,
        min_rows_per_label=min_rows_per_label,
    )
    initial_ordered_counts = ordered_token_counts_from_row_tokens(all_rows, row_tokens)
    initial_counts = Counter(dict(initial_ordered_counts))
    _resolved_min, resolved_max = resolved_token_occurrence_target_range_from_counts(
        filtered_counts if filtered_counts else initial_counts,
        options,
    )
    method = normalized_token_occurrence_balance_mode(options.token_occurrence_balance_mode)
    lines.append(f"  Hard range: min={target_min}, max={resolved_max}, method={method}")

    if not under_min_tokens:
        lines.append("  (none below the hard minimum)")
        return "\n".join(lines)

    lines.append(f"  Removed {len(under_min_tokens)} token(s), excluding {excluded_count} row(s):")
    shown = 0
    for token, count in initial_ordered_counts:
        if token not in under_min_tokens:
            continue
        shown += 1
        kind = token_kind_label(token, use_hybrid_tokens=options.token_use_hybrid_tokens)
        lines.append(f"  {shown:>3}. [{kind}] {display_token_item(token)} = {count}")

    dropped_labels = len(eligible_groups) - len(filtered_groups)
    if dropped_labels > 0:
        lines.append(f"  Note: {dropped_labels} exact-label class(es) were dropped after hard-min filtering because too few rows remained.")
    return "\n".join(lines)


def select_rows_with_class_balance(
    candidate_rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> list[LabelPreview]:
    """Apply eligibility filters, token coverage filtering, and output-label balancing."""
    if not options.any_enabled() and not (options.enabled and options.prefer_rare_tokens):
        return candidate_rows

    eligible_rows = [row for row in candidate_rows if passes_length_unique_filters(row, options)]
    if options.charset_filter_enabled:
        eligible_rows, _charset_unsupported_counts, _charset_unsupported_examples = apply_charset_file_filter(eligible_rows, options)
    token_metadata_needed = (
        options.token_filter_enabled
        or (options.enabled and options.prefer_rare_tokens)
        or options.token_occurrence_balance_enabled
    )
    if token_metadata_needed:
        eligible_rows, row_items, token_label_counts = apply_token_coverage_filter(eligible_rows, options)
    else:
        row_items = {}
        token_label_counts = Counter()

    rows_by_output_label: dict[str, list[LabelPreview]] = {}
    for row in eligible_rows:
        rows_by_output_label.setdefault(row.after, []).append(row)

    if options.enabled:
        eligible_groups = {
            label: rows
            for label, rows in rows_by_output_label.items()
            if len(rows) >= options.min_count
        }
        if not eligible_groups:
            return []
        class_counts = [len(rows) for rows in eligible_groups.values()]
        max_per_label = resolved_max_per_label(class_counts, options)
    elif options.token_occurrence_balance_enabled:
        eligible_groups = {label: rows for label, rows in rows_by_output_label.items() if rows}
        if not eligible_groups:
            return []
        max_per_label = max((len(rows) for rows in eligible_groups.values()), default=1)
    else:
        return eligible_rows

    if options.token_occurrence_balance_enabled:
        selected_ids = select_rows_with_token_occurrence_balance(
            eligible_groups,
            max_per_label=max_per_label,
            options=options,
        )
    else:
        selected_ids: set[LabelEntryId] = set()
        row_sort_key: Callable[[LabelPreview], object] | None = None
        if options.prefer_rare_tokens and token_metadata_needed:
            row_sort_key = lambda row: rare_token_sort_key(row, row_items, token_label_counts)

        for label, rows in eligible_groups.items():
            if len(rows) <= max_per_label:
                selected_ids.update(label_entry_id(row.file_path, row.label_path) for row in rows)
                continue
            selected_ids.update(
                balanced_sample_rows_by_file(
                    rows,
                    cap=max_per_label,
                    seed=BALANCE_RANDOM_SEED,
                    salt="label:" + label,
                    row_sort_key=row_sort_key,
                )
            )

    return [row for row in eligible_rows if label_entry_id(row.file_path, row.label_path) in selected_ids]


def build_candidate_preview_rows(
    input_dir: Path,
    recursive: bool,
    space_mode: str,
    existing_latex_mode: str,
    escape_literal_specials: bool,
    conversion_direction: str,
    use_hybrid_tokens: bool = False,
) -> tuple[list[LabelPreview], int, int, list[str], Counter[str]]:
    """Build all candidate rows before length/unique filtering and balancing."""
    pending_rows: list[tuple[Path, str, str, str, bool, str, str, str, str]] = []
    output_labels: list[str] = []
    errors: list[str] = []
    files = iter_json_files(input_dir, recursive)
    changed_count = 0

    for path in files:
        try:
            data = load_json(path)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"{path.name}: {exc}")
            continue

        for label_path, before in find_labels(data):
            after, space_action, escape_action, preserve_action, unicode_action = convert_label_with_options(
                before,
                space_mode,
                existing_latex_mode,
                escape_literal_specials,
                conversion_direction,
            )
            changed = after != before
            pending_rows.append((
                path,
                label_path,
                before,
                after,
                changed,
                space_action,
                escape_action,
                preserve_action,
                unicode_action,
            ))
            output_labels.append(after)

    if conversion_direction == OUTPUT_CONVENTION_LATEX:
        normalized_labels, guarded_commands, _normalized_count = normalize_latex_string_token_guard_labels(output_labels)
        if guarded_commands:
            normalized_pending_rows: list[tuple[Path, str, str, str, bool, str, str, str, str]] = []
            for pending, normalized_after in zip(pending_rows, normalized_labels, strict=False):
                (
                    path,
                    label_path,
                    before,
                    after,
                    _changed,
                    space_action,
                    escape_action,
                    preserve_action,
                    unicode_action,
                ) = pending
                if normalized_after != after:
                    unicode_action = append_status_note(unicode_action, FORMAT_GUARD_STATUS)
                normalized_pending_rows.append((
                    path,
                    label_path,
                    before,
                    normalized_after,
                    normalized_after != before,
                    space_action,
                    escape_action,
                    preserve_action,
                    unicode_action,
                ))
            pending_rows = normalized_pending_rows
            output_labels = normalized_labels

    changed_count = sum(1 for _path, _label_path, before, after, _changed, *_rest in pending_rows if after != before)
    output_label_counts: Counter[str] = Counter(output_labels)
    scan_tokens = hybrid_audit_scan_tokens(output_labels) if use_hybrid_tokens else None
    rows: list[LabelPreview] = []
    for (
        path,
        label_path,
        before,
        after,
        changed,
        space_action,
        escape_action,
        preserve_action,
        unicode_action,
    ) in pending_rows:
        token_items = tokenize_label_for_coverage(after, scan_tokens)
        after_token_length = len(token_items)
        unique_after_tokens = len(set(token_items))
        rows.append(
            LabelPreview(
                file_path=path,
                label_path=label_path,
                before=before,
                after=after,
                changed=changed,
                space_action=space_action,
                escape_action=escape_action,
                preserve_action=preserve_action,
                unicode_action=unicode_action,
                label_frequency=output_label_counts[after],
                before_raw_length=len(before),
                after_raw_length=len(after),
                after_token_length=after_token_length,
                token_length_delta=after_token_length - len(before),
                unique_after_tokens=unique_after_tokens,
                label_stats=make_label_stats(after, token_items),
            )
        )

    return rows, len(files), changed_count, errors, output_label_counts


def build_filtered_preview_rows(
    input_dir: Path,
    recursive: bool,
    space_mode: str,
    existing_latex_mode: str,
    escape_literal_specials: bool,
    conversion_direction: str,
    frequency_options: FrequencyFilterOptions,
) -> tuple[list[LabelPreview], int, int, list[str], Counter[str]]:
    """Build preview rows after active eligibility filters and class balancing."""
    rows, file_count, _candidate_changed, errors, frequency_counts = build_candidate_preview_rows(
        input_dir,
        recursive,
        space_mode,
        existing_latex_mode,
        escape_literal_specials,
        conversion_direction,
        use_hybrid_tokens=frequency_options.token_use_hybrid_tokens,
    )
    filtered_rows = select_rows_with_class_balance(rows, frequency_options)
    changed_count = sum(1 for row in filtered_rows if row.changed)
    return filtered_rows, file_count, changed_count, errors, frequency_counts


def format_frequency_filter_summary(
    options: FrequencyFilterOptions,
    candidate_rows: list[LabelPreview] | None = None,
) -> str:
    parts: list[str] = []
    if options.enabled:
        if options.max_count_auto:
            resolved = resolved_max_per_label_for_rows(candidate_rows, options) if candidate_rows is not None else None
            mode_text = max_per_label_mode_short_name(options.max_count_mode)
            max_text = f"{mode_text}={resolved}" if resolved is not None else mode_text
        else:
            max_text = str(options.max_count)
        parts.append(f"balance labels min {options.min_count}, max/label {max_text}")
    if options.length_enabled:
        parts.append(f"tokens {options.min_length}–{options.max_length}")
    if options.unique_enabled:
        parts.append(f"unique tokens {options.min_unique}–{options.max_unique}")
    if options.token_filter_enabled:
        unit = token_unit_mode_summary(options.token_unit_mode, options.token_use_hybrid_tokens)
        parts.append(f"token labels ≥ {options.token_min_label_count} ({unit})")
    if options.enabled and options.prefer_rare_tokens:
        parts.append("prefer rare tokens")
    if options.token_occurrence_balance_enabled:
        if options.token_occurrence_target_auto:
            target_text = max_per_label_mode_short_name(options.token_occurrence_target_mode)
        else:
            target_text = str(options.token_occurrence_target_max)
        method_text = normalized_token_occurrence_balance_mode(options.token_occurrence_balance_mode)
        parts.append(
            f"hard-balance token occurrences {options.token_occurrence_min_target}–{target_text}, "
            f"{method_text.casefold()}"
        )
    if options.charset_filter_enabled:
        path_name = Path(options.charset_filter_path).name if options.charset_filter_path else "(no file)"
        parts.append(f"charset strict {path_name}")
    return ", ".join(parts)

def iter_json_files(folder: Path, recursive: bool) -> list[Path]:
    pattern = "**/*.json" if recursive else "*.json"
    return sorted(p for p in folder.glob(pattern) if p.is_file())

def format_json_path_value(value: Any) -> str:
    """Render a short JSON value for use inside a preview path."""
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    return str(value)

def label_path_for(container_path: str, key: str, container: dict[str, Any]) -> str:
    """Build the preview path for a label field.

    The list position and the crop's stored index are different pieces of
    information.  For crop dictionaries that include an ``index`` field, show
    both so the UI reads like:

        $.crops[55] index=63 .label

    Here, ``55`` is the zero-based list position and ``63`` is the original
    crop index preserved in the JSON.
    """
    if "index" in container:
        return f"{container_path} index={format_json_path_value(container['index'])} .{key}"
    return f"{container_path}.{key}"

def find_labels(obj: Any, path: str = "$") -> Iterable[tuple[str, str]]:
    """Yield (preview_path, label_value) for every string-valued key named label."""
    if isinstance(obj, dict):
        for key, value in obj.items():
            child_path = f"{path}.{key}"
            if key == "label" and isinstance(value, str):
                yield label_path_for(path, key, obj), value
            else:
                yield from find_labels(value, child_path)
    elif isinstance(obj, list):
        for idx, value in enumerate(obj):
            yield from find_labels(value, f"{path}[{idx}]")

SKIP_ENTRY = object()


def convert_labels_in_obj(
    obj: Any,
    src_path: Path,
    selected_label_ids: set[LabelEntryId],
    space_mode: str,
    existing_latex_mode: str,
    escape_literal_specials: bool,
    conversion_direction: str,
    converted_labels_by_id: dict[LabelEntryId, str] | None = None,
    path: str = "$",
) -> tuple[Any, int, int]:
    """Recursively convert and prune selected string label entries.

    Returns (object_or_SKIP_ENTRY, changed_count, kept_label_count). A dictionary
    that itself contains a string-valued ``label`` key is treated as one label
    entry. If that label was not selected by the preview/filter/balancing plan,
    the whole entry is omitted from its parent list/dict. JSON files with no
    kept label entries are skipped by ConvertThread.
    """
    if isinstance(obj, dict):
        label_value = obj.get("label")
        if isinstance(label_value, str):
            current_label_path = label_path_for(path, "label", obj)
            if label_entry_id(src_path, current_label_path) not in selected_label_ids:
                return SKIP_ENTRY, 0, 0

            entry_id = label_entry_id(src_path, current_label_path)
            if converted_labels_by_id is not None and entry_id in converted_labels_by_id:
                candidate_value = converted_labels_by_id[entry_id]
            else:
                candidate_value, _space_action, _escape_action, _preserve_action, _unicode_action = convert_label_with_options(
                    label_value,
                    space_mode,
                    existing_latex_mode,
                    escape_literal_specials,
                    conversion_direction,
                )
            changed_count = int(candidate_value != label_value)
            kept_label_count = 1
            new_obj: dict[str, Any] = {}
            for key, value in obj.items():
                if key == "label":
                    new_obj[key] = candidate_value
                    continue
                child_path = f"{path}.{key}"
                new_value, sub_changed, sub_kept = convert_labels_in_obj(
                    value,
                    src_path,
                    selected_label_ids,
                    space_mode,
                    existing_latex_mode,
                    escape_literal_specials,
                    conversion_direction,
                    converted_labels_by_id,
                    child_path,
                )
                if new_value is SKIP_ENTRY:
                    continue
                new_obj[key] = new_value
                changed_count += sub_changed
                kept_label_count += sub_kept
            return new_obj, changed_count, kept_label_count

        changed_count = 0
        kept_label_count = 0
        new_obj: dict[str, Any] = {}
        for key, value in obj.items():
            child_path = f"{path}.{key}"
            new_value, sub_changed, sub_kept = convert_labels_in_obj(
                value,
                src_path,
                selected_label_ids,
                space_mode,
                existing_latex_mode,
                escape_literal_specials,
                conversion_direction,
                converted_labels_by_id,
                child_path,
            )
            if new_value is SKIP_ENTRY:
                continue
            new_obj[key] = new_value
            changed_count += sub_changed
            kept_label_count += sub_kept
        return new_obj, changed_count, kept_label_count

    if isinstance(obj, list):
        changed_count = 0
        kept_label_count = 0
        new_list: list[Any] = []
        for idx, value in enumerate(obj):
            new_value, sub_changed, sub_kept = convert_labels_in_obj(
                value,
                src_path,
                selected_label_ids,
                space_mode,
                existing_latex_mode,
                escape_literal_specials,
                conversion_direction,
                converted_labels_by_id,
                f"{path}[{idx}]",
            )
            if new_value is SKIP_ENTRY:
                continue
            new_list.append(new_value)
            changed_count += sub_changed
            kept_label_count += sub_kept
        return new_list, changed_count, kept_label_count

    return obj, 0, 0

def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)

def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")


def find_image_field(obj: Any) -> str | None:
    """Return the first string-valued JSON field named image, if present."""
    if isinstance(obj, dict):
        value = obj.get("image")
        if isinstance(value, str) and value.strip():
            return value
        for child in obj.values():
            found = find_image_field(child)
            if found is not None:
                return found
    elif isinstance(obj, list):
        for child in obj:
            found = find_image_field(child)
            if found is not None:
                return found
    return None


def copy_referenced_image(data: Any, src_json: Path, dst_json: Path) -> bool:
    """Copy the image named by the JSON image field beside the output JSON."""
    image_value = find_image_field(data)
    if image_value is None:
        raise ValueError('No string-valued "image" field found.')

    image_path = Path(image_value).expanduser()
    if not image_path.is_absolute():
        image_path = src_json.parent / image_path

    image_src = image_path.resolve()
    if not image_src.is_file():
        raise FileNotFoundError(f"Referenced image not found: {image_value}")

    image_dst = dst_json.parent / image_src.name
    if image_dst.exists() and image_dst.resolve() == image_src:
        return False

    image_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(image_src, image_dst)
    return True


def yaml_double_quote(value: str) -> str:
    """Return a YAML-safe double-quoted scalar."""
    return json.dumps(value, ensure_ascii=False)


def parse_yaml_string_literal(value_text: str) -> str:
    """Parse a simple YAML scalar used in these PARSeq charset files."""
    value_text = value_text.strip()
    if not value_text:
        return ""
    if value_text[0] in {'"', "'"}:
        try:
            return ast.literal_eval(value_text)
        except Exception:  # noqa: BLE001
            pass
    return value_text.strip('"\'')


def parse_charset_train_from_config(text: str) -> str:
    # Match a quoted YAML scalar without treating # inside the charset as a comment.
    match = re.search(r"charset_train\s*:\s*(\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'|[^\n#]+)", text)
    if not match:
        return ""
    return parse_yaml_string_literal(match.group(1).strip())


def parse_latex_tokens_from_config(text: str) -> list[str]:
    lines = text.splitlines()
    tokens: list[str] = []
    in_tokens = False
    tokens_indent = 0
    for line in lines:
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if re.match(r"latex_tokens\s*:", stripped):
            in_tokens = True
            tokens_indent = len(line) - len(line.lstrip())
            continue
        if not in_tokens:
            continue
        indent = len(line) - len(line.lstrip())
        if indent <= tokens_indent and not stripped.startswith("-"):
            break
        if stripped.startswith("-"):
            value = stripped[1:].strip()
            if "#" in value:
                value = value.split("#", 1)[0].rstrip()
            tokens.append(parse_yaml_string_literal(value))
    return tokens



@dataclass(frozen=True)
class CharsetFilterSpec:
    """Allowed fallback characters and explicit string tokens from a PARSeq charset config."""

    path: Path
    charset_train: str
    latex_tokens: tuple[str, ...]


def load_charset_filter_spec(path_text: str) -> CharsetFilterSpec:
    """Load the charset file used by the strict charset compatibility filter."""
    path = Path(path_text).expanduser()
    text = path.read_text(encoding="utf-8")
    return CharsetFilterSpec(
        path=path,
        charset_train=parse_charset_train_from_config(text),
        latex_tokens=tuple(parse_latex_tokens_from_config(text)),
    )


def strict_charset_unsupported_pieces(label: str, spec: CharsetFilterSpec) -> list[str]:
    r"""Return unsupported pieces under strict string-token coverage.

    This is intentionally stricter than plain representability. In canonical
    guarded token mode, guardable command atoms are expected as guarded tokens
    such as ``\theta{}`` and ``\neq{}``; grouped constants such as
    ``\mathbb{R}``, and structural string tokens such as ``_{`` and ``^{``
    must also appear explicitly in ``latex_tokens``. Remaining single
    characters must appear in ``charset_train``.
    """
    allowed_chars = set(spec.charset_train)
    allowed_tokens = set(spec.latex_tokens)
    non_command_tokens = sorted(
        [token for token in allowed_tokens if token and not token.startswith("\\") and token not in {"_{", "^{"}],
        key=len,
        reverse=True,
    )
    unsupported: list[str] = []
    i = 0
    while i < len(label):
        structural = ""
        if label.startswith("_{", i):
            structural = "_{"
        elif label.startswith("^{", i):
            structural = "^{"
        if structural:
            if structural in allowed_tokens:
                i += len(structural)
            else:
                unsupported.append(structural)
                i += len(structural)
            continue

        if label[i] == "\\":
            discovered = read_discoverable_latex_token(label, i)
            if discovered is not None:
                token, end = discovered
                if token in allowed_tokens:
                    i = max(end, i + 1)
                else:
                    unsupported.append(token)
                    i = max(end, i + 1)
                continue

        matched_token = ""
        for token in non_command_tokens:
            if label.startswith(token, i):
                matched_token = token
                break
        if matched_token:
            i += len(matched_token)
            continue

        ch = label[i]
        if ch not in allowed_chars:
            unsupported.append(ch)
        i += 1

    return unsupported


def apply_charset_file_filter(
    rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> tuple[list[LabelPreview], Counter[str], dict[str, str]]:
    """Apply strict charset-file compatibility filtering to final output labels."""
    if not options.charset_filter_enabled:
        return rows, Counter(), {}

    spec = load_charset_filter_spec(options.charset_filter_path)
    unsupported_counts: Counter[str] = Counter()
    unsupported_examples: dict[str, str] = {}
    kept_rows: list[LabelPreview] = []
    for row in rows:
        unsupported = strict_charset_unsupported_pieces(row.after, spec)
        if not unsupported:
            kept_rows.append(row)
            continue
        for piece in set(unsupported):
            unsupported_counts[piece] += 1
            unsupported_examples.setdefault(piece, row.after)
    return kept_rows, unsupported_counts, unsupported_examples


def build_charset_filter_log_text(
    selected_rows: list[LabelPreview],
    candidate_rows: list[LabelPreview],
    options: FrequencyFilterOptions,
) -> str:
    """Build a log report for the strict charset-file compatibility filter."""
    lines: list[str] = ["Charset compatibility filter"]
    if not options.charset_filter_enabled:
        lines.append("  (charset filter is off)")
        return "\n".join(lines)

    lines.append(f"  File: {options.charset_filter_path}")
    lines.append("  Mode: String + character tokens; strict canonical guarded string-token coverage")
    try:
        eligible_rows = [row for row in candidate_rows if passes_length_unique_filters(row, options)]
        filtered_rows, unsupported_counts, unsupported_examples = apply_charset_file_filter(eligible_rows, options)
    except Exception as exc:  # noqa: BLE001
        lines.append(f"  Error: {exc}")
        return "\n".join(lines)

    removed_count = len(eligible_rows) - len(filtered_rows)
    lines.append(f"  Checked rows after length/unique filters: {len(eligible_rows)}")
    lines.append(f"  Kept by charset filter before later balancing: {len(filtered_rows)}")
    lines.append(f"  Removed by charset filter: {removed_count}")
    lines.append(f"  Final selected rows after all filters/balancing: {len(selected_rows)}")
    lines.append("")
    lines.append("  Unsupported pieces:")
    if not unsupported_counts:
        lines.append("    (none)")
    else:
        for index, (piece, count) in enumerate(unsupported_counts.most_common(), start=1):
            kind = "string" if len(piece) > 1 else "char"
            example = truncate_middle(unsupported_examples.get(piece, ""), 100)
            lines.append(f"    {index:>3}. [{kind}] {display_token_item(piece)} = {count} label(s); example: {example}")
    return "\n".join(lines)

def detect_charset_config_kind(text: str) -> str:
    if "tokenizer_type" in text and "latex_hybrid" in text:
        return "hybrid"
    if "latex_tokens" in text:
        return "hybrid"
    return "regular"


def ordered_used_chars(used_chars: set[str], template_charset: str) -> str:
    ordered: list[str] = []
    seen: set[str] = set()
    for ch in template_charset:
        if ch in used_chars and ch not in seen:
            ordered.append(ch)
            seen.add(ch)
    for ch in sorted(used_chars - seen, key=lambda c: (ord(c), c)):
        ordered.append(ch)
        seen.add(ch)
    return "".join(ordered)


LATEX_GROUP_TOKEN_COMMANDS = {
    r"\mathbb",
    r"\mathbf",
    r"\mathrm",
    r"\mathcal",
    r"\mathfrak",
    r"\mathsf",
    r"\mathtt",
    r"\unicode",
}

EMPTY_GROUP_TOKEN_COMMANDS = {
    r"\sqrt",
    r"\dot",
    r"\textquotedbl",
    r"\textbackslash",
    r"\textasciicircum",
    r"\textasciitilde",
}


def read_discoverable_latex_token(text: str, start: int) -> tuple[str, int] | None:
    r"""Read one LaTeX-like token that is safe to add to a string-token charset.

    This deliberately avoids making ordinary words into tokens. It discovers
    command-like LaTeX strings such as \to, \theta, \frac, \sqrt{}, and
    group-style constants such as \mathbb{R}. Unknown commands are still useful
    as tokens because the string-token tokenizer can learn them as whole strings.
    """
    command = read_latex_command_name(text, start)
    if command is None:
        return None
    command_text, end = command

    # Only discover alphabetic LaTeX commands or known escaped literal helpers.
    if not (command_text.startswith("\\") and command_text[1:].isascii() and command_text[1:].isalpha()):
        if command_text in LITERAL_LATEX_SPECIALS.values():
            return command_text, end
        return None

    token = command_text
    i = end

    # Empty groups are meaningful for the tokenizer in two cases:
    #   - generated empty-argument commands such as \sqrt{} and \dot{}
    #   - normalized formatting guards such as \theta{} or \to{}
    # In both cases, keep the guarded form as the discovered string token.
    if i + 1 < len(text) and text[i : i + 2] == FORMAT_GUARD_TOKEN:
        token += FORMAT_GUARD_TOKEN
        i += len(FORMAT_GUARD_TOKEN)
        if command_text in EMPTY_GROUP_TOKEN_COMMANDS:
            while i + 1 < len(text) and text[i : i + 2] == FORMAT_GUARD_TOKEN:
                token += FORMAT_GUARD_TOKEN
                i += len(FORMAT_GUARD_TOKEN)

    # Compact style/constant commands such as \mathbb{R} are often intended as
    # one string token. Do not absorb arbitrary arguments for structural commands
    # such as \frac{...}{...}; those remain \frac plus fallback chars/tokens.
    if command_text in LATEX_GROUP_TOKEN_COMMANDS and i < len(text) and text[i] == "{":
        raw_group = read_latex_group_raw(text, i)
        if raw_group is not None:
            inner, group_end = raw_group
            if inner and len(inner) <= 16 and "{" not in inner and "}" not in inner:
                token += "{" + inner + "}"
                i = group_end

    return token, i


def discover_latex_tokens_from_labels(labels: list[str], template_tokens: list[str]) -> list[str]:
    """Return LaTeX-like tokens used by labels but missing from the template."""
    template_set = set(template_tokens)
    discovered: list[str] = []
    seen: set[str] = set()
    for label in labels:
        i = 0
        while i < len(label):
            if label[i] != "\\":
                i += 1
                continue
            token = read_discoverable_latex_token(label, i)
            if token is None:
                i += 1
                continue
            token_text, end = token
            if token_text not in template_set and token_text not in seen:
                discovered.append(token_text)
                seen.add(token_text)
            i = max(end, i + 1)
    return discovered


def split_hybrid_labels_into_tokens_and_chars(
    labels: list[str],
    template_tokens: list[str],
    *,
    add_discovered_tokens: bool = True,
) -> tuple[list[str], set[str], list[str]]:
    """Select LaTeX tokens used in labels and collect remaining fallback chars.

    Template tokens keep their original template order after canonical guarded
    token normalization. Newly discovered tokens are appended in sorted order,
    then used during splitting so they do not inflate charset_train with their
    individual characters.
    """
    # Labels are expected to already be normalized by canonical guarded token
    # mode. Canonicalize the template token spellings too so a template token
    # such as \theta is treated as the canonical \theta{} token in the
    # generated charset preview.
    template_tokens = canonicalize_latex_token_list_for_guarded_mode(template_tokens)
    all_discovered_tokens = sorted(
        discover_latex_tokens_from_labels(labels, template_tokens),
        key=lambda token: token.casefold(),
    )
    if add_discovered_tokens:
        discovered_tokens = all_discovered_tokens
    else:
        # Guard-normalized command forms such as \to{} must be available as
        # atomic string tokens whenever they appear in labels, even when the
        # broader discovered-token option is off. Otherwise the preview/export
        # text and charset disagree about the token class.
        discovered_tokens = [token for token in all_discovered_tokens if token.endswith(FORMAT_GUARD_TOKEN)]
    scan_tokens = list(dict.fromkeys([*template_tokens, *discovered_tokens]))

    selected_tokens: set[str] = set()
    fallback_chars: set[str] = set()
    token_scan_order = sorted(scan_tokens, key=len, reverse=True)

    for label in labels:
        i = 0
        while i < len(label):
            matched_token = ""
            for token in token_scan_order:
                if not token:
                    continue
                if not label.startswith(token, i):
                    continue
                if token.startswith("\\") and token[1:].isalpha() and not _macro_boundary_ok(label, i, token):
                    continue
                matched_token = token
                break
            if matched_token:
                selected_tokens.add(matched_token)
                i += len(matched_token)
            else:
                fallback_chars.add(label[i])
                i += 1

    ordered_template_tokens = [token for token in template_tokens if token in selected_tokens]
    ordered_discovered_tokens = [token for token in discovered_tokens if token in selected_tokens]
    return ordered_template_tokens + ordered_discovered_tokens, fallback_chars, ordered_discovered_tokens

def make_regular_charset_preview(labels: list[str], template_text: str) -> str:
    template_charset = parse_charset_train_from_config(template_text)
    used_chars = {ch for label in labels for ch in label}
    charset = ordered_used_chars(used_chars, template_charset)
    return "\n".join([
        "# @package _global_",
        "# Generated from labels as they would be exported with the current options.",
        "# Ordering: template-first; dataset-only characters appended sorted.",
        "model:",
        f"  charset_train: {yaml_double_quote(charset)}",
        "",
    ])


def make_hybrid_charset_preview(
    labels: list[str],
    template_text: str,
    *,
    add_discovered_tokens: bool = True,
) -> str:
    template_charset = parse_charset_train_from_config(template_text)
    template_tokens = canonicalize_latex_token_list_for_guarded_mode(parse_latex_tokens_from_config(template_text))
    selected_tokens, fallback_chars, discovered_tokens = split_hybrid_labels_into_tokens_and_chars(
        labels,
        template_tokens,
        add_discovered_tokens=add_discovered_tokens,
    )
    charset = ordered_used_chars(fallback_chars, template_charset)

    lines = [
        "# @package _global_",
        "# Generated from labels as they would be exported with the current options.",
        "# Ordering: template-first; dataset-only characters/tokens appended sorted.",
    ]
    if discovered_tokens:
        lines.append(f"# Added {len(discovered_tokens)} discovered/required latex token(s) from labels.")
    lines.extend([
        "model:",
        "  tokenizer_type: latex_hybrid",
        f"  charset_train: {yaml_double_quote(charset)}",
    ])
    if selected_tokens:
        lines.append("  latex_tokens:")
        lines.extend(f"    - {yaml_double_quote(token)}" for token in selected_tokens)
    else:
        lines.append("  latex_tokens: []")
    lines.append("")
    return "\n".join(lines)


@dataclass(frozen=True)
class TokenCoverageRow:
    item: str
    kind: str
    label_count: int
    occurrence_count: int
    label_percent: float
    example_label: str


def display_token_item(item: str) -> str:
    """Return a visible table/report label for whitespace/control characters."""
    if item == " ":
        return "␠ space"
    if item == "\t":
        return r"\t tab"
    if item == "\n":
        return r"\n newline"
    if item == "\r":
        return r"\r return"
    return item


def report_token_item(item: str) -> str:
    """Return a copy-friendly representation that preserves invisible chars."""
    if item in {" ", "\t", "\n", "\r"}:
        return json.dumps(item, ensure_ascii=False)
    return item


def truncate_middle(text: str, max_len: int = 120) -> str:
    if len(text) <= max_len:
        return text
    keep = max(8, (max_len - 1) // 2)
    return text[:keep] + "…" + text[-keep:]


def default_hybrid_audit_tokens() -> list[str]:
    """Return cached string + character tokens used as the baseline for coverage scans."""
    tokens: list[str] = []
    for mode in (
        CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID,
        CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE,
    ):
        cached = cached_builtin_charset_template(mode)
        template_text = cached.text if cached is not None else BUILTIN_CHARSET_TEMPLATE_TEXTS[mode]
        for token in canonicalize_latex_token_list_for_guarded_mode(parse_latex_tokens_from_config(template_text)):
            if token not in tokens:
                tokens.append(token)
    return tokens


def hybrid_audit_scan_tokens(labels: list[str]) -> list[str]:
    """Return known + discovered string + character tokens, longest first for greedy scanning."""
    template_tokens = default_hybrid_audit_tokens()
    discovered_tokens = sorted(
        discover_latex_tokens_from_labels(labels, template_tokens),
        key=lambda token: token.casefold(),
    )
    scan_tokens = list(dict.fromkeys([*template_tokens, *discovered_tokens]))
    return sorted(scan_tokens, key=len, reverse=True)


def tokenize_label_for_coverage(label: str, scan_tokens: list[str] | None) -> list[str]:
    """Tokenize one output label for coverage auditing.

    When scan_tokens is provided, LaTeX/string + character tokens such as \theta, \frac,
    _{, and ^{ are counted as one item. Everything else falls back to a single
    character. When scan_tokens is None, every Unicode code point is counted as
    a character.
    """
    if not scan_tokens:
        return list(label)

    items: list[str] = []
    i = 0
    while i < len(label):
        matched_token = ""
        for token in scan_tokens:
            if not token:
                continue
            if not label.startswith(token, i):
                continue
            if token.startswith("\\") and token[1:].isalpha() and not _macro_boundary_ok(label, i, token):
                continue
            matched_token = token
            break
        if matched_token:
            items.append(matched_token)
            i += len(matched_token)
        else:
            items.append(label[i])
            i += 1
    return items


def build_token_coverage_rows(labels: list[str], *, use_hybrid_tokens: bool) -> list[TokenCoverageRow]:
    """Build token/character coverage rows from output labels.

    label_count is the number of separate labels containing the item at least
    once. occurrence_count is the raw total number of appearances.
    """
    scan_tokens = hybrid_audit_scan_tokens(labels) if use_hybrid_tokens else None
    occurrence_counts: Counter[str] = Counter()
    label_counts: Counter[str] = Counter()
    examples: dict[str, str] = {}

    for label in labels:
        items = tokenize_label_for_coverage(label, scan_tokens)
        occurrence_counts.update(items)
        for item in set(items):
            label_counts[item] += 1
            examples.setdefault(item, label)

    total_labels = max(1, len(labels))
    rows = [
        TokenCoverageRow(
            item=item,
            kind="token" if len(item) > 1 else "char",
            label_count=label_counts[item],
            occurrence_count=occurrence_counts[item],
            label_percent=(label_counts[item] / total_labels) * 100.0,
            example_label=examples.get(item, ""),
        )
        for item in occurrence_counts
    ]
    return sorted(rows, key=lambda row: (row.label_count, row.occurrence_count, row.kind, row.item.casefold()))


class TokenCoverageAuditDialog(QDialog):
    """Audit how well current output labels cover individual chars/tokens."""

    def __init__(
        self,
        label_provider: Callable[[], tuple[list[str], list[str]]],
        conversion_direction: str = OUTPUT_CONVENTION_LATEX,
        initial_unit_mode: str = TOKEN_AUDIT_MODE_AUTO,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.label_provider = label_provider
        self.conversion_direction = conversion_direction
        self.rows: list[TokenCoverageRow] = []
        self.setWindowTitle("Token / Charset Coverage Audit")
        self.setMinimumSize(780, 520)
        self.resize(900, 620)

        self.unit_combo = QComboBox()
        self.unit_combo.addItems(TOKEN_AUDIT_MODES)
        if initial_unit_mode in TOKEN_AUDIT_MODES:
            self.unit_combo.setCurrentText(initial_unit_mode)
        self.unit_combo.setToolTip(
            "Auto uses string + character tokens for LaTeX output and characters-only for other output conventions."
        )
        self.unit_combo.currentTextChanged.connect(self.refresh_report)

        refresh_button = QPushButton("Refresh")
        refresh_button.setToolTip("Recompute the coverage audit from the current output labels.")
        refresh_button.clicked.connect(self.refresh_report)

        copy_button = QPushButton("Copy Report")
        copy_button.setToolTip("Copy the audit table as tab-separated text.")
        copy_button.clicked.connect(self.copy_report)

        close_button = QPushButton("Close")
        close_button.clicked.connect(self.accept)

        self.table = QTableWidget(0, 0)
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(("Item", "Kind", "Labels", "Label %", "Occurrences", "Example output label"))
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.setSortingEnabled(True)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setStretchLastSection(True)
        self.table.setColumnWidth(0, 150)
        self.table.setColumnWidth(1, 70)
        self.table.setColumnWidth(2, 80)
        self.table.setColumnWidth(3, 80)
        self.table.setColumnWidth(4, 95)

        mono = QFont("Menlo")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        mono.setPointSize(12)
        self.table.setFont(mono)

        self.status_label = QLabel(
            "Labels = separate output labels containing the item. Occurrences = total appearances."
        )
        self.status_label.setWordWrap(True)

        top = QHBoxLayout()
        top.addWidget(QLabel("Unit"))
        top.addWidget(self.unit_combo, 1)
        top.addWidget(refresh_button)

        bottom = QHBoxLayout()
        bottom.addStretch(1)
        bottom.addWidget(copy_button)
        bottom.addWidget(close_button)

        layout = QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self.table, 1)
        layout.addWidget(self.status_label)
        layout.addLayout(bottom)

        self.refresh_report()

    def selected_use_hybrid_tokens(self) -> bool:
        mode = self.unit_combo.currentText()
        if mode == TOKEN_AUDIT_MODE_HYBRID:
            return True
        if mode == TOKEN_AUDIT_MODE_CHARS:
            return False
        return self.conversion_direction == OUTPUT_CONVENTION_LATEX

    def refresh_report(self, *_args: object) -> None:
        labels, errors = self.label_provider()
        if not labels:
            self.rows = []
            self.table.setRowCount(0)
            suffix = f" Label-scan errors: {len(errors)}." if errors else ""
            self.status_label.setText("No output labels found yet. Run/update Preview first." + suffix)
            return

        use_hybrid_tokens = self.selected_use_hybrid_tokens()
        self.rows = build_token_coverage_rows(labels, use_hybrid_tokens=use_hybrid_tokens)
        self.populate_table(self.rows)

        rare_count = sum(1 for row in self.rows if row.label_count <= 3)
        unit_text = "string + character tokens" if use_hybrid_tokens else "characters only"
        suffix = f" Label-scan errors: {len(errors)}." if errors else ""
        self.status_label.setText(
            f"Audited {len(labels)} output label(s) using {unit_text}. "
            f"Found {len(self.rows)} unique item(s); {rare_count} appear in 3 or fewer labels. "
            "Rows are initially sorted rarest first. Labels = separate labels containing the item; "
            f"Occurrences = total appearances.{suffix}"
        )

    def populate_table(self, rows: list[TokenCoverageRow]) -> None:
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(rows))
        for row_idx, row in enumerate(rows):
            values: list[tuple[str, object]] = [
                (display_token_item(row.item), row.item.casefold()),
                (row.kind, row.kind),
                (str(row.label_count), row.label_count),
                (f"{row.label_percent:.1f}%", row.label_percent),
                (str(row.occurrence_count), row.occurrence_count),
                (truncate_middle(row.example_label), row.example_label.casefold()),
            ]
            for col_idx, (text, sort_value) in enumerate(values):
                item = SortableTableWidgetItem(text, sort_value)
                if col_idx in {2, 3, 4}:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                self.table.setItem(row_idx, col_idx, item)
        self.table.setSortingEnabled(True)
        self.table.sortItems(2, Qt.SortOrder.AscendingOrder)

    def copy_report(self) -> None:
        if not self.rows:
            return
        lines = ["item\tkind\tlabels\tlabel_percent\toccurrences\texample_output_label"]
        for row in self.rows:
            lines.append(
                "\t".join([
                    report_token_item(row.item),
                    row.kind,
                    str(row.label_count),
                    f"{row.label_percent:.2f}",
                    str(row.occurrence_count),
                    row.example_label.replace("\t", " "),
                ])
            )
        QApplication.clipboard().setText("\n".join(lines))


class RowCheckListWidget(QListWidget):
    """List widget where clicking a row toggles that row's checkbox.

    Native QListWidget checkbox toggling usually requires clicking directly on
    the check indicator. For this small options popup, row-click toggling is
    faster and feels more natural. Clicks near the native checkbox are left to
    Qt so checkbox clicks do not double-toggle.
    """

    CHECK_HOTZONE_PX = 32

    def mouseReleaseEvent(self, event) -> None:  # noqa: ANN001 - Qt event type
        pos = event.position().toPoint() if hasattr(event, "position") else event.pos()
        item = self.itemAt(pos)
        should_toggle_row = False
        if item is not None:
            rect = self.visualItemRect(item)
            should_toggle_row = pos.x() > rect.left() + self.CHECK_HOTZONE_PX

        super().mouseReleaseEvent(event)

        if should_toggle_row and item is not None:
            item.setCheckState(
                Qt.CheckState.Unchecked
                if item.checkState() == Qt.CheckState.Checked
                else Qt.CheckState.Checked
            )


class ColumnOptionsDialog(QDialog):
    """Small popup for choosing preview-table columns."""

    def __init__(self, selected_keys: set[str], parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Preview columns")
        self.resize(360, 380)
        self.list_widget = RowCheckListWidget()
        self.list_widget.setAlternatingRowColors(True)

        for key, title in ALL_COLUMN_SPECS:
            item = QListWidgetItem(title)
            item.setData(Qt.ItemDataRole.UserRole, key)
            item.setFlags(item.flags() | Qt.ItemFlag.ItemIsUserCheckable)
            item.setCheckState(Qt.CheckState.Checked if key in selected_keys else Qt.CheckState.Unchecked)
            self.list_widget.addItem(item)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.addWidget(QLabel("Show preview columns:"))
        layout.addWidget(self.list_widget)
        layout.addWidget(buttons)

    def selected_keys(self) -> set[str]:
        keys: set[str] = set()
        for row in range(self.list_widget.count()):
            item = self.list_widget.item(row)
            if item.checkState() == Qt.CheckState.Checked:
                keys.add(str(item.data(Qt.ItemDataRole.UserRole)))
        return keys


def find_parseq_charset_start_dir() -> Path:
    """Find a likely PARSeq charset config folder, starting from the launch cwd."""
    cwd = Path.cwd().expanduser()
    try:
        cwd = cwd.resolve()
    except Exception:  # noqa: BLE001
        pass

    suffixes = (
        Path("parseq/configs/charset"),
        Path("parseq/config/charset"),
        Path("parsec/configs/charset"),
        Path("parsec/config/charset"),
        Path("configs/charset"),
        Path("config/charset"),
        Path("charset"),
    )

    search_roots: list[Path] = [cwd]
    search_roots.extend(parent for parent in cwd.parents)
    script_dir = Path(__file__).resolve().parent
    if script_dir not in search_roots:
        search_roots.append(script_dir)
    for parent in script_dir.parents:
        if parent not in search_roots:
            search_roots.append(parent)

    for root in search_roots:
        for suffix in suffixes:
            candidate = root / suffix
            if candidate.is_dir():
                return candidate

    # If the app was launched from a workspace root, this finds nested repos
    # such as ./parseq/configs/charset without requiring the exact cwd.
    for pattern in (
        "parseq/configs/charset",
        "parseq/config/charset",
        "parsec/configs/charset",
        "parsec/config/charset",
        "*/parseq/configs/charset",
        "*/parseq/config/charset",
        "*/parsec/configs/charset",
        "*/parsec/config/charset",
        "*/configs/charset",
        "*/config/charset",
    ):
        try:
            for candidate in cwd.glob(pattern):
                if candidate.is_dir():
                    return candidate
        except OSError:
            continue

    return cwd



def load_app_settings() -> dict[str, Any]:
    """Load small app settings without making startup depend on them."""
    try:
        if APP_SETTINGS_PATH.is_file():
            data = json.loads(APP_SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                return data
    except Exception:  # noqa: BLE001
        pass
    return {}


def save_app_settings(settings: dict[str, Any]) -> None:
    """Save small app settings, ignoring permission/location failures."""
    try:
        APP_SETTINGS_PATH.write_text(
            json.dumps(settings, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    except Exception:  # noqa: BLE001
        pass


def last_charset_template_path() -> Path | None:
    value = load_app_settings().get("last_charset_template_path")
    if not isinstance(value, str) or not value.strip():
        return None
    return Path(value).expanduser()


def remember_charset_template_path(path: Path) -> None:
    settings = load_app_settings()
    try:
        value = str(path.expanduser().resolve())
    except Exception:  # noqa: BLE001
        value = str(path.expanduser())
    settings["last_charset_template_path"] = value
    save_app_settings(settings)


def likely_charset_template_dirs() -> list[Path]:
    """Return likely charset-template folders in priority order."""
    dirs: list[Path] = []
    suffixes = (
        Path("."),
        Path("parseq/configs/charset"),
        Path("parseq/config/charset"),
        Path("parsec/configs/charset"),
        Path("parsec/config/charset"),
        Path("configs/charset"),
        Path("config/charset"),
        Path("charset"),
    )

    candidates: list[Path] = [find_parseq_charset_start_dir()]
    cwd = Path.cwd().expanduser()
    try:
        cwd = cwd.resolve()
    except Exception:  # noqa: BLE001
        pass
    candidates.append(cwd)
    candidates.extend(cwd.parents)

    script_dir = Path(__file__).resolve().parent
    candidates.append(script_dir)
    candidates.extend(script_dir.parents)

    for root in candidates:
        for suffix in suffixes:
            directory = root / suffix
            try:
                directory = directory.resolve()
            except Exception:  # noqa: BLE001
                pass
            if directory.is_dir() and directory not in dirs:
                dirs.append(directory)
    return dirs


def find_charset_template_file_by_names(names: Iterable[str]) -> Path | None:
    """Find a nearby template file by filename, without requiring manual browse."""
    wanted = tuple(name for name in names if name)
    if not wanted:
        return None
    for directory in likely_charset_template_dirs():
        for name in wanted:
            candidate = directory / name
            if candidate.is_file():
                return candidate

    # Limited recursive fallback from the current/script directories. This
    # catches common "repo is one level down" layouts without scanning the world.
    roots: list[Path] = []
    for root in (Path.cwd().expanduser(), Path(__file__).resolve().parent):
        try:
            root = root.resolve()
        except Exception:  # noqa: BLE001
            pass
        if root.is_dir() and root not in roots:
            roots.append(root)

    for root in roots:
        for pattern in (
            "parseq/configs/charset/*",
            "parseq/config/charset/*",
            "parsec/configs/charset/*",
            "parsec/config/charset/*",
            "*/parseq/configs/charset/*",
            "*/parseq/config/charset/*",
            "*/parsec/configs/charset/*",
            "*/parsec/config/charset/*",
            "*/configs/charset/*",
            "*/config/charset/*",
        ):
            try:
                for candidate in root.glob(pattern):
                    if candidate.is_file() and candidate.name in wanted:
                        return candidate
            except OSError:
                continue
    return None


def compact_path_for_display(path: Path | str, *, max_parts: int = 3) -> str:
    """Return a short, readable path label while keeping the full path in tooltips."""
    raw = str(path).strip()
    if not raw:
        return ""
    path_obj = Path(raw).expanduser()
    name = path_obj.name or raw
    parts = path_obj.parts
    if len(parts) <= max_parts:
        return raw
    tail = Path(*parts[-max_parts:])
    return f"…/{tail}"


def compact_template_source_for_display(source: str) -> str:
    """Shorten template-source messages that contain long absolute paths."""
    for prefix in ("Auto file: ", "Last used: ", "Custom file: "):
        if source.startswith(prefix):
            path_text = source[len(prefix):].strip()
            if path_text:
                return prefix + compact_path_for_display(path_text, max_parts=3)
    return source


class CharsetPreviewDialog(QDialog):
    """Preview a regular or hybrid PARSeq charset config for current output labels."""

    def __init__(
        self,
        label_provider: Callable[[], tuple[list[str], list[str]]],
        space_mode: str = SPACE_MODE_PRESERVE,
        conversion_direction: str = OUTPUT_CONVENTION_LATEX,
        parent: QWidget | None = None,
    ) -> None:
        super().__init__(parent)
        self.label_provider = label_provider
        self.space_mode = space_mode
        self.conversion_direction = conversion_direction
        self.setWindowTitle("Preview PARSeq charset config")
        self.setMinimumSize(760, 520)
        self.resize(820, 590)
        self.custom_template_path_text = ""
        self.watched_template_file_signature: tuple[Path, tuple[int, int] | None] | None = None
        load_builtin_charset_templates()

        self.template_mode_combo = QComboBox()
        self.template_mode_combo.addItems(CHARSET_TEMPLATE_MODE_CHOICES)
        self.template_mode_combo.setToolTip(CHARSET_TEMPLATE_SOURCE_TOOLTIP)
        self.template_mode_combo.currentTextChanged.connect(self.on_charset_option_changed)

        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Template appears here")
        self.path_edit.setToolTip(CHARSET_TEMPLATE_TOOLTIP)
        self.path_edit.setReadOnly(True)
        self.path_edit.setMinimumWidth(260)
        self.path_edit.textEdited.connect(self.on_path_manually_edited)

        self.browse_button = QPushButton("Browse…")
        self.browse_button.setToolTip(CHARSET_BROWSE_TOOLTIP)
        self.browse_button.clicked.connect(self.choose_config_file)

        self.kind_combo = QComboBox()
        self.kind_combo.addItems(("Auto", "Regular charset", "String + character token charset"))
        self.kind_combo.setToolTip(CHARSET_TYPE_TOOLTIP)
        self.kind_combo.currentTextChanged.connect(self.schedule_preview_update)

        self.discover_tokens_check = QCheckBox("Add discovered tokens from labels")
        self.discover_tokens_check.setChecked(True)
        self.discover_tokens_check.setToolTip(CHARSET_DISCOVER_TOKENS_TOOLTIP)
        self.discover_tokens_check.stateChanged.connect(self.schedule_preview_update)

        self.preview_update_timer = QTimer(self)
        self.preview_update_timer.setSingleShot(True)
        self.preview_update_timer.setInterval(250)
        self.preview_update_timer.timeout.connect(self.auto_update_preview)

        self.template_file_refresh_timer = QTimer(self)
        self.template_file_refresh_timer.setInterval(1500)
        self.template_file_refresh_timer.timeout.connect(self.refresh_template_files_if_needed)
        self.template_file_refresh_timer.start()

        generate_button = QPushButton("Refresh")
        generate_button.setToolTip("Refresh the charset preview now. The preview also auto-updates when options change.")
        generate_button.clicked.connect(lambda _checked=False: self.generate_preview(show_warnings=True))
        copy_button = QPushButton("Copy")
        copy_button.setToolTip("Copy the generated charset config preview to the clipboard.")
        copy_button.clicked.connect(self.copy_preview)
        save_button = QPushButton("Save As…")
        save_button.setToolTip("Save the generated charset config preview to a YAML file.")
        save_button.clicked.connect(self.save_preview)

        self.preview_edit = QTextEdit()
        self.preview_edit.setReadOnly(True)
        self.preview_edit.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.preview_edit.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        mono = QFont("Menlo")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        mono.setPointSize(12)
        self.preview_edit.setFont(mono)

        self.status_label = QLabel("Generated from labels as they would be exported with the current options.")
        self.status_label.setWordWrap(True)
        self.status_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        top = QGridLayout()
        top.setColumnStretch(1, 1)
        top.setColumnMinimumWidth(1, 260)
        self.template_source_label = QLabel("Template source")
        self.template_source_label.setToolTip(CHARSET_TEMPLATE_SOURCE_TOOLTIP)
        top.addWidget(self.template_source_label, 0, 0)
        top.addWidget(self.template_mode_combo, 0, 1)
        top.addWidget(self.browse_button, 0, 2)

        self.template_config_label = QLabel("Template")
        self.template_config_label.setToolTip(CHARSET_TEMPLATE_TOOLTIP)
        top.addWidget(self.template_config_label, 1, 0)
        top.addWidget(self.path_edit, 1, 1, 1, 2)

        self.type_label = QLabel("Type")
        self.type_label.setToolTip(CHARSET_TYPE_TOOLTIP)
        top.addWidget(self.type_label, 2, 0)
        top.addWidget(self.kind_combo, 2, 1)
        top.addWidget(generate_button, 2, 2)
        top.addWidget(self.discover_tokens_check, 3, 1, 1, 2)

        bottom = QHBoxLayout()
        bottom.addStretch(1)
        bottom.addWidget(copy_button)
        bottom.addWidget(save_button)
        close_button = QPushButton("Close")
        close_button.setToolTip("Close this preview window.")
        close_button.clicked.connect(self.accept)
        bottom.addWidget(close_button)

        layout = QVBoxLayout(self)
        layout.addLayout(top)
        layout.addWidget(self.preview_edit, 1)
        layout.addWidget(self.status_label)
        layout.addLayout(bottom)

        last_path = last_charset_template_path()
        if last_path and last_path.is_file():
            self.template_mode_combo.setCurrentText(CHARSET_TEMPLATE_MODE_LAST_USED)
        else:
            self.template_mode_combo.setCurrentText(CHARSET_TEMPLATE_MODE_AUTO)
        self.update_template_controls()
        self.schedule_preview_update()

    def on_charset_option_changed(self, *_args: object) -> None:
        self.update_template_controls()
        self.schedule_preview_update()

    def schedule_preview_update(self, *_args: object) -> None:
        self.preview_update_timer.start()

    def auto_update_preview(self) -> None:
        self.generate_preview(show_warnings=False)

    def current_template_file_path_to_watch(self) -> Path | None:
        """Return the template file whose changes should refresh this dialog."""
        mode = self.template_mode_combo.currentText()
        if mode == CHARSET_TEMPLATE_MODE_AUTO:
            cached = cached_builtin_charset_template(self.recommended_builtin_template_mode())
            return cached.path if cached is not None else None
        if mode in BUILTIN_CHARSET_TEMPLATE_TEXTS:
            cached = cached_builtin_charset_template(mode)
            return cached.path if cached is not None else None
        if mode == CHARSET_TEMPLATE_MODE_LAST_USED:
            return last_charset_template_path()
        if mode == CHARSET_TEMPLATE_MODE_CUSTOM and self.custom_template_path_text.strip():
            return Path(self.custom_template_path_text).expanduser()
        return None

    def refresh_template_files_if_needed(self) -> None:
        """Periodically refresh template files while the charset dialog is open."""
        changed = refresh_builtin_charset_templates()
        watch_path = self.current_template_file_path_to_watch()
        if watch_path is not None:
            try:
                watch_path = watch_path.resolve()
            except Exception:  # noqa: BLE001
                pass
            signature = charset_template_file_signature(watch_path)
            current = (watch_path, signature)
            if self.watched_template_file_signature is None:
                self.watched_template_file_signature = current
            elif self.watched_template_file_signature != current:
                self.watched_template_file_signature = current
                changed = True
        else:
            self.watched_template_file_signature = None

        if changed:
            self.update_template_controls()
            self.schedule_preview_update()

    def on_path_manually_edited(self, text: str) -> None:
        self.custom_template_path_text = text.strip()
        if self.template_mode_combo.currentText() != CHARSET_TEMPLATE_MODE_CUSTOM:
            self.template_mode_combo.setCurrentText(CHARSET_TEMPLATE_MODE_CUSTOM)
        self.schedule_preview_update()

    def recommended_builtin_template_mode(self) -> str:
        """Choose a practical default from the current export settings."""
        if self.conversion_direction == OUTPUT_CONVENTION_LATEX:
            if self.space_mode == SPACE_MODE_REMOVE:
                return CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID_NO_SPACE
            return CHARSET_TEMPLATE_MODE_BUILTIN_LATEX_HYBRID

        # Non-LaTeX output should usually be a regular charset config. The
        # generated charset still adds any extra Unicode characters found in
        # labels after the 94_full ordering baseline.
        return CHARSET_TEMPLATE_MODE_BUILTIN_94_FULL

    def describe_auto_template_choice(self) -> str:
        recommended = self.recommended_builtin_template_mode()
        cached = cached_builtin_charset_template(recommended)
        if cached is not None and cached.path is not None:
            return f"Auto: {cached.source}"
        return f"Auto: {recommended}"

    def set_resolved_template_display(self, display_text: str, full_text: str | None = None) -> None:
        """Show a compact template identifier without letting long paths resize the dialog."""
        self.path_edit.setText(display_text)
        self.path_edit.setToolTip(full_text or display_text or CHARSET_TEMPLATE_TOOLTIP)

    def update_template_controls(self) -> None:
        mode = self.template_mode_combo.currentText()
        self.path_edit.setReadOnly(True)
        self.browse_button.setEnabled(True)

        if mode == CHARSET_TEMPLATE_MODE_AUTO:
            full_text = self.describe_auto_template_choice()
            display_text = full_text
            if full_text.startswith("Auto: "):
                rest = full_text[len("Auto: "):]
                if "/" in rest or "\\" in rest:
                    display_text = "Auto: " + compact_path_for_display(rest, max_parts=3)
            self.set_resolved_template_display(display_text, full_text)
            return

        if mode == CHARSET_TEMPLATE_MODE_LAST_USED:
            path = last_charset_template_path()
            if path is None:
                self.set_resolved_template_display("No last-used template saved yet")
            else:
                self.set_resolved_template_display(path.name or compact_path_for_display(path), str(path))
            return

        if mode in BUILTIN_CHARSET_TEMPLATE_TEXTS:
            cached = cached_builtin_charset_template(mode)
            if cached is not None and cached.path is not None:
                self.set_resolved_template_display(
                    cached.path.name or compact_path_for_display(cached.path),
                    cached.source,
                )
            else:
                self.set_resolved_template_display("Embedded fallback", mode)
            return

        if mode == CHARSET_TEMPLATE_MODE_CUSTOM:
            if not self.custom_template_path_text:
                last_path = last_charset_template_path()
                if last_path is not None:
                    self.custom_template_path_text = str(last_path)
            if self.custom_template_path_text:
                path = Path(self.custom_template_path_text).expanduser()
                self.set_resolved_template_display(path.name or compact_path_for_display(path), str(path))
            else:
                self.set_resolved_template_display("Choose a custom file with Browse…")

    def choose_config_file(self) -> None:
        typed_path = Path(self.custom_template_path_text).expanduser() if self.custom_template_path_text.strip() else None
        if typed_path and typed_path.is_file():
            start = str(typed_path.parent)
        elif typed_path and typed_path.is_dir():
            start = str(typed_path)
        else:
            last_path = last_charset_template_path()
            if last_path and last_path.is_file():
                start = str(last_path.parent)
            else:
                start = str(find_parseq_charset_start_dir())
        filename, _selected_filter = QFileDialog.getOpenFileName(
            self,
            "Choose PARSeq charset config",
            start,
            "YAML files (*.yaml *.yml);;All files (*)",
        )
        if filename:
            path = Path(filename).expanduser()
            remember_charset_template_path(path)
            self.custom_template_path_text = str(path)
            self.template_mode_combo.setCurrentText(CHARSET_TEMPLATE_MODE_CUSTOM)
            self.update_template_controls()
            self.generate_preview()

    def selected_kind(self, template_text: str) -> str:
        mode = self.kind_combo.currentText()
        if mode == "Regular charset":
            return "regular"
        if mode == "String + character token charset":
            return "hybrid"
        return detect_charset_config_kind(template_text)

    def read_template_file(self, path: Path, *, show_warnings: bool = True) -> tuple[str, str] | None:
        try:
            template_text = path.read_text(encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            if show_warnings:
                QMessageBox.warning(self, APP_TITLE, f"Could not read config:\n{exc}")
            return None
        return template_text, str(path)

    def resolve_auto_template(self, *, show_warnings: bool = True) -> tuple[str, str] | None:
        recommended = self.recommended_builtin_template_mode()
        cached = cached_builtin_charset_template(recommended)
        if cached is None:
            return None
        if cached.path is not None:
            return cached.text, f"Auto file: {cached.source}"
        return cached.text, f"Auto built-in: {recommended}"

    def resolve_template(self, *, show_warnings: bool = True) -> tuple[str, str] | None:
        mode = self.template_mode_combo.currentText()

        if mode == CHARSET_TEMPLATE_MODE_AUTO:
            return self.resolve_auto_template(show_warnings=show_warnings)

        if mode == CHARSET_TEMPLATE_MODE_LAST_USED:
            path = last_charset_template_path()
            if path is None:
                if show_warnings:
                    QMessageBox.warning(self, APP_TITLE, "No last-used charset template has been saved yet.")
                return None
            if not path.is_file():
                if show_warnings:
                    QMessageBox.warning(self, APP_TITLE, f"Last-used config file does not exist:\n{path}")
                return None
            loaded = self.read_template_file(path, show_warnings=show_warnings)
            if loaded is None:
                return None
            template_text, source = loaded
            return template_text, f"Last used: {source}"

        if mode in BUILTIN_CHARSET_TEMPLATE_TEXTS:
            cached = cached_builtin_charset_template(mode)
            if cached is None:
                return None
            if cached.path is not None:
                return cached.text, f"Built-in file: {cached.source}"
            return cached.text, mode

        path_text = self.custom_template_path_text.strip()
        if not path_text:
            if show_warnings:
                QMessageBox.warning(self, APP_TITLE, "Choose a custom PARSeq charset config, or switch Template to Auto/Built-in.")
            return None
        path = Path(path_text).expanduser()
        if not path.is_file():
            if show_warnings:
                QMessageBox.warning(self, APP_TITLE, f"Config file does not exist:\n{path}")
            return None
        loaded = self.read_template_file(path, show_warnings=show_warnings)
        if loaded is None:
            return None
        remember_charset_template_path(path)
        template_text, source = loaded
        return template_text, f"Custom file: {source}"

    def generate_preview(self, show_warnings: bool = True) -> None:
        resolved = self.resolve_template(show_warnings=show_warnings)
        if resolved is None:
            return
        template_text, template_source = resolved

        labels, errors = self.label_provider()
        if not labels:
            if show_warnings:
                QMessageBox.warning(self, APP_TITLE, "No labels were found for the current input/options.")
            else:
                self.status_label.setText("No labels found yet. Run/update Preview in the main window first.")
            return

        kind = self.selected_kind(template_text)
        discovered_count: int | None = None
        added_chars: set[str] = set()
        added_tokens: set[str] = set()

        if kind == "hybrid":
            add_discovered = self.discover_tokens_check.isChecked()
            template_charset = parse_charset_train_from_config(template_text)
            template_tokens = canonicalize_latex_token_list_for_guarded_mode(parse_latex_tokens_from_config(template_text))
            selected_tokens, fallback_chars, discovered_tokens = split_hybrid_labels_into_tokens_and_chars(
                labels,
                template_tokens,
                add_discovered_tokens=add_discovered,
            )
            discovered_count = len(discovered_tokens)
            added_chars = fallback_chars - set(template_charset)
            added_tokens = set(selected_tokens) - set(template_tokens)
            text = make_hybrid_charset_preview(labels, template_text, add_discovered_tokens=add_discovered)
        else:
            template_charset = parse_charset_train_from_config(template_text)
            used_chars = {ch for label in labels for ch in label}
            added_chars = used_chars - set(template_charset)
            text = make_regular_charset_preview(labels, template_text)

        self.set_preview_text_with_highlights(text, added_chars=added_chars, added_tokens=added_tokens)

        suffix = f"  Label-scan errors: {len(errors)}." if errors else ""
        if discovered_count is not None:
            suffix = f"  Added {discovered_count} discovered token(s)." + suffix
        highlight_parts: list[str] = []
        if added_chars:
            highlight_parts.append(f"{len(added_chars)} new char(s)")
        if added_tokens:
            highlight_parts.append(f"{len(added_tokens)} new token(s)")
        if highlight_parts:
            suffix += "  Highlighted: " + ", ".join(highlight_parts) + "."
        template_display = compact_template_source_for_display(template_source)
        status_text = (
            f"Generated {kind} config from {len(labels)} output label(s).  "
            f"Template: {template_display}.  Ordering: template-first; dataset-only additions sorted.{suffix}"
        )
        self.status_label.setText(status_text)
        self.status_label.setToolTip(
            f"Template: {template_source}\n"
            "Highlighted text = characters/tokens that were not in the selected template."
        )
        self.update_template_controls()

    def set_preview_text_with_highlights(
        self,
        text: str,
        *,
        added_chars: set[str],
        added_tokens: set[str],
    ) -> None:
        self.preview_edit.setPlainText(text)
        spans = self.charset_highlight_spans(text, added_chars=added_chars, added_tokens=added_tokens)
        if not spans:
            return

        highlight_format = QTextCharFormat()
        highlight_format.setBackground(QColor(255, 249, 196))
        highlight_format.setForeground(QColor(27, 94, 32))
        highlight_format.setFontWeight(QFont.Weight.DemiBold)

        cursor = self.preview_edit.textCursor()
        cursor.beginEditBlock()
        for start, end in spans:
            if end <= start:
                continue
            cursor.setPosition(start)
            cursor.setPosition(end, QTextCursor.MoveMode.KeepAnchor)
            cursor.mergeCharFormat(highlight_format)
        cursor.endEditBlock()
        cursor.clearSelection()
        cursor.movePosition(QTextCursor.MoveOperation.Start)
        self.preview_edit.setTextCursor(cursor)
        self.preview_edit.setToolTip(
            "Highlighted text = characters/tokens that were not in the selected template."
        )

    def charset_highlight_spans(
        self,
        text: str,
        *,
        added_chars: set[str],
        added_tokens: set[str],
    ) -> list[tuple[int, int]]:
        spans: list[tuple[int, int]] = []

        charset = parse_charset_train_from_config(text)
        if charset and added_chars:
            quoted_charset = yaml_double_quote(charset)
            prefix = "  charset_train: "
            line_start = text.find(prefix)
            quoted_start = text.find(quoted_charset, line_start) if line_start != -1 else -1
            if quoted_start != -1 and quoted_charset.startswith('"'):
                pos = quoted_start + 1
                for ch in charset:
                    encoded_piece = yaml_double_quote(ch)[1:-1]
                    next_pos = pos + len(encoded_piece)
                    if ch in added_chars:
                        spans.append((pos, next_pos))
                    pos = next_pos

        for token in added_tokens:
            quoted_token = yaml_double_quote(token)
            needle = f"    - {quoted_token}"
            search_start = 0
            while True:
                line_start = text.find(needle, search_start)
                if line_start == -1:
                    break
                value_start = line_start + len("    - ")
                if quoted_token.startswith('"') and len(quoted_token) >= 2:
                    spans.append((value_start + 1, value_start + len(quoted_token) - 1))
                else:
                    spans.append((value_start, value_start + len(quoted_token)))
                search_start = line_start + len(needle)

        return spans

    def copy_preview(self) -> None:
        text = self.preview_edit.toPlainText()
        if text:
            QApplication.clipboard().setText(text)

    def save_preview(self) -> None:
        text = self.preview_edit.toPlainText()
        if not text:
            QMessageBox.warning(self, APP_TITLE, "Preview is empty.")
            return
        start_dir = find_parseq_charset_start_dir()
        default_path = start_dir / "charset_filtered.yaml" if start_dir.is_dir() else Path.home() / "charset_filtered.yaml"
        filename, _selected_filter = QFileDialog.getSaveFileName(
            self,
            "Save charset config preview",
            str(default_path),
            "YAML files (*.yaml *.yml);;All files (*)",
        )
        if not filename:
            return
        try:
            Path(filename).write_text(text, encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            QMessageBox.warning(self, APP_TITLE, f"Could not save file:\n{exc}")

class PreviewThread(QThread):
    finished_preview = pyqtSignal(list, list, int, int, int, list, float)  # rows, candidate_rows, files, labels, changed, errors, elapsed

    def __init__(
        self,
        input_dir: Path,
        recursive: bool,
        space_mode: str,
        existing_latex_mode: str,
        escape_literal_specials: bool,
        conversion_direction: str,
        frequency_options: FrequencyFilterOptions,
    ) -> None:
        super().__init__()
        self.input_dir = input_dir
        self.recursive = recursive
        self.space_mode = space_mode
        self.existing_latex_mode = existing_latex_mode
        self.escape_literal_specials = escape_literal_specials
        self.conversion_direction = conversion_direction
        self.frequency_options = frequency_options

    def run(self) -> None:
        started_at = time.perf_counter()
        candidate_rows, file_count, _candidate_changed, errors, _frequency_counts = build_candidate_preview_rows(
            self.input_dir,
            self.recursive,
            self.space_mode,
            self.existing_latex_mode,
            self.escape_literal_specials,
            self.conversion_direction,
            use_hybrid_tokens=self.frequency_options.token_use_hybrid_tokens,
        )
        rows = select_rows_with_class_balance(candidate_rows, self.frequency_options)
        changed_count = sum(1 for row in rows if row.changed)
        elapsed_seconds = time.perf_counter() - started_at
        self.finished_preview.emit(rows, candidate_rows, file_count, len(rows), changed_count, errors, elapsed_seconds)

class ConvertThread(QThread):
    progress = pyqtSignal(int, int)
    finished_convert = pyqtSignal(int, int, int, list, float)  # files_written, labels_changed, images_copied, errors, elapsed

    def __init__(
        self,
        input_dir: Path,
        output_dir: Path,
        recursive: bool,
        suffix: str,
        space_mode: str,
        existing_latex_mode: str,
        escape_literal_specials: bool,
        copy_images: bool,
        conversion_direction: str,
        frequency_options: FrequencyFilterOptions,
    ) -> None:
        super().__init__()
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.recursive = recursive
        self.suffix = suffix
        self.space_mode = space_mode
        self.existing_latex_mode = existing_latex_mode
        self.escape_literal_specials = escape_literal_specials
        self.copy_images = copy_images
        self.conversion_direction = conversion_direction
        self.frequency_options = frequency_options

    def output_path_for(self, src: Path) -> Path:
        rel = src.relative_to(self.input_dir)
        if self.suffix:
            rel = rel.with_name(f"{rel.stem}{self.suffix}{rel.suffix}")
        return self.output_dir / rel

    def run(self) -> None:
        started_at = time.perf_counter()
        files = iter_json_files(self.input_dir, self.recursive)
        errors: list[str] = []
        files_written = 0
        labels_changed = 0
        images_copied = 0

        selected_rows, _file_count, _changed_count, selection_errors, _frequency_counts = build_filtered_preview_rows(
            self.input_dir,
            self.recursive,
            self.space_mode,
            self.existing_latex_mode,
            self.escape_literal_specials,
            self.conversion_direction,
            self.frequency_options,
        )
        errors.extend(selection_errors)
        selected_label_ids = {label_entry_id(row.file_path, row.label_path) for row in selected_rows}
        converted_labels_by_id = {label_entry_id(row.file_path, row.label_path): row.after for row in selected_rows}

        for idx, src in enumerate(files, start=1):
            try:
                data = load_json(src)
                new_data, changed, considered = convert_labels_in_obj(
                    data,
                    src,
                    selected_label_ids,
                    self.space_mode,
                    self.existing_latex_mode,
                    self.escape_literal_specials,
                    self.conversion_direction,
                    converted_labels_by_id,
                )
                # Filters and output-label balancing define the exported subset.
                # Files with no selected labels are skipped entirely. Files with
                # selected labels are pruned to only those label entries.
                if considered == 0:
                    self.progress.emit(idx, len(files))
                    continue
                labels_changed += changed

                dst = self.output_path_for(src)
                if dst.resolve() == src.resolve():
                    raise ValueError("Refusing to overwrite the input JSON. Choose an output folder or add a suffix.")
                write_json(dst, new_data)
                files_written += 1

                if self.copy_images:
                    try:
                        images_copied += int(copy_referenced_image(new_data, src, dst))
                    except Exception as image_exc:  # noqa: BLE001
                        errors.append(f"{src.name}: {image_exc}")
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{src.name}: {exc}")
            self.progress.emit(idx, len(files))

        elapsed_seconds = time.perf_counter() - started_at
        self.finished_convert.emit(files_written, labels_changed, images_copied, errors, elapsed_seconds)

class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1120, 720)
        load_builtin_charset_templates()
        self.preview_thread: PreviewThread | None = None
        self.convert_thread: ConvertThread | None = None
        self.preview_has_run = False
        self.output_auto_managed = True
        self.preview_rows: list[LabelPreview] = []
        self.preview_candidate_rows: list[LabelPreview] = []
        self.preview_candidate_signature: tuple[object, ...] | None = None
        self.preview_rows_signature: tuple[object, ...] | None = None
        self.preview_errors: list[str] = []
        self.preview_file_count = 0
        self.visible_column_keys: set[str] = set(COLUMN_VIEW_PRESETS[DEFAULT_COLUMN_VIEW])
        self.filter_limits = FilterMetricLimits()
        self._updating_filter_limits = False
        self.pending_preview_full_rescan = False
        self.preview_refresh_timer = QTimer(self)
        self.preview_refresh_timer.setSingleShot(True)
        self.preview_refresh_timer.setInterval(450)
        self.preview_refresh_timer.timeout.connect(self._run_debounced_preview_refresh)
        self.preview_search_timer = QTimer(self)
        self.preview_search_timer.setSingleShot(True)
        self.preview_search_timer.setInterval(200)
        self.preview_search_timer.timeout.connect(self.apply_preview_search)

        self.input_edit = QLineEdit(str(DEFAULT_INPUT_JSON_FOLDER))
        self.output_edit = QLineEdit(str(DEFAULT_INPUT_JSON_FOLDER / DEFAULT_OUTPUT_FOLDER_NAME))
        self.suffix_edit = QLineEdit("")
        self.suffix_edit.setPlaceholderText("optional, e.g. _latex")

        self.recursive_check = QCheckBox("Include JSON files in subfolders")
        self.recursive_check.setChecked(False)
        self.recursive_check.setToolTip("Scan JSON files in the selected folder and all nested subfolders.")

        self.conversion_direction = CONVERSION_DIRECTION_SYMBOLS_TO_LATEX
        self.direction_combo = QComboBox()
        self.direction_combo.addItems(CONVERSION_DIRECTIONS)
        self.direction_combo.setCurrentText(self.conversion_direction)
        self.direction_combo.setToolTip("Choose the target label convention for preview/export.")

        self.space_mode = SPACE_MODE_PRESERVE
        self.space_mode_combo = QComboBox()
        self.space_mode_combo.addItems(SPACE_MODES)
        self.space_mode_combo.setCurrentText(self.space_mode)
        self.space_mode_combo.setToolTip("Choose how whitespace is handled before conversion and export.")

        self.existing_latex_mode = EXISTING_LATEX_MODE_PRESERVE
        self.existing_latex_combo = QComboBox()
        self.existing_latex_combo.addItems(EXISTING_LATEX_MODES)
        self.existing_latex_combo.setCurrentText(self.existing_latex_mode)
        self.existing_latex_combo.setToolTip("Choose whether existing LaTeX syntax in labels is preserved or escaped as literal text.")

        self.escape_specials_check = QCheckBox("Escape literal LaTeX specials")
        self.escape_specials_check.setChecked(False)
        self.escape_specials_check.setToolTip("Escape literal %, _, #, quotes, and other LaTeX-special characters copied from source labels.")

        self.frequency_filter_check = QCheckBox("Freq balance")
        self.frequency_filter_check.setChecked(False)
        self.frequency_filter_check.setToolTip("Balance by final output label. Classes below Min class count are excluded; each remaining class keeps up to Max per label.")
        self.frequency_min_spin = QSpinBox()
        self.frequency_min_spin.setRange(1, MAX_FILTER_VALUE)
        self.frequency_min_spin.setValue(DEFAULT_MIN_CLASS_COUNT)
        self.frequency_min_spin.setFixedWidth(64)
        self.frequency_min_spin.setToolTip("Minimum output-label class count required for a class to be exported.")
        self.frequency_max_mode_combo = QComboBox()
        self.frequency_max_mode_combo.addItems(MAX_PER_LABEL_MODES)
        for idx, mode in enumerate(MAX_PER_LABEL_MODES):
            self.frequency_max_mode_combo.setItemData(
                idx,
                tooltip_for_max_per_label_mode(mode),
                Qt.ItemDataRole.ToolTipRole,
            )
        self.frequency_max_mode_combo.setCurrentText(MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN)
        self.frequency_max_mode_combo.setToolTip(tooltip_for_max_per_label_mode(MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN))
        self.frequency_max_spin = QSpinBox()
        self.frequency_max_spin.setRange(1, MAX_FILTER_VALUE)
        self.frequency_max_spin.setValue(DEFAULT_MIN_CLASS_COUNT)
        self.frequency_max_spin.setFixedWidth(76)
        self.frequency_max_spin.setToolTip("Manual maximum entries to keep per output-label class.")
        self.length_filter_check = QCheckBox("Tokens")
        self.length_filter_check.setChecked(False)
        self.length_filter_check.setToolTip("Only preview/convert labels whose output token length is in this range.")
        self.length_min_spin = QSpinBox()
        self.length_min_spin.setRange(0, self.filter_limits.max_length)
        self.length_min_spin.setValue(0)
        self.length_min_spin.setFixedWidth(64)
        self.length_min_spin.setToolTip("Minimum output token length, inclusive.")
        self.length_max_spin = QSpinBox()
        self.length_max_spin.setRange(0, self.filter_limits.max_length)
        self.length_max_spin.setValue(self.filter_limits.max_length)
        self.length_max_spin.setFixedWidth(76)
        self.length_max_spin.setToolTip("Maximum output token length, inclusive.")
        self.unique_filter_check = QCheckBox("Unique tokens")
        self.unique_filter_check.setChecked(False)
        self.unique_filter_check.setToolTip("Only preview/convert labels whose output unique-token count is in this range.")
        self.unique_min_spin = QSpinBox()
        self.unique_min_spin.setRange(0, self.filter_limits.max_unique)
        self.unique_min_spin.setValue(0)
        self.unique_min_spin.setFixedWidth(64)
        self.unique_min_spin.setToolTip("Minimum output unique-token count, inclusive.")
        self.unique_max_spin = QSpinBox()
        self.unique_max_spin.setRange(0, self.filter_limits.max_unique)
        self.unique_max_spin.setValue(self.filter_limits.max_unique)
        self.unique_max_spin.setFixedWidth(76)
        self.unique_max_spin.setToolTip("Maximum output unique-token count, inclusive.")
        self.filters_toggle = QPushButton("Filters ▸")
        self.filters_toggle.setCheckable(True)
        self.filters_toggle.setChecked(False)
        self.filters_toggle.setToolTip("Show or hide the filter controls.")
        self.filters_panel = QWidget()

        self.search_toggle = QPushButton("Search ▸")
        self.search_toggle.setCheckable(True)
        self.search_toggle.setChecked(False)
        self.search_toggle.setToolTip("Show or hide the preview search controls. Cmd-F opens this section.")
        self.search_panel = QWidget()

        self.token_coverage_toggle = QPushButton("Token / Charset Coverage ▸")
        self.token_coverage_toggle.setCheckable(True)
        self.token_coverage_toggle.setChecked(False)
        self.token_coverage_toggle.setToolTip("Show or hide token/character coverage audit and export controls.")
        self.token_coverage_panel = QWidget()
        self.token_coverage_unit_combo = QComboBox()
        self.token_coverage_unit_combo.addItems(TOKEN_AUDIT_MODES)
        self.token_coverage_unit_combo.setCurrentText(TOKEN_AUDIT_MODE_AUTO)
        self.token_coverage_unit_combo.setToolTip(
            "Auto uses string + character tokens for LaTeX output and characters-only for other output conventions."
        )
        self.token_exclude_low_count_check = QCheckBox("Exclude labels containing tokens below label-count")
        self.token_exclude_low_count_check.setChecked(False)
        self.token_exclude_low_count_check.setToolTip(
            "Export filter: remove labels containing any token/character that appears in fewer than N separate output labels. "
            "Useful for strict supported-token datasets, but it can remove rare-symbol examples."
        )
        self.token_exclude_low_count_spin = QSpinBox()
        self.token_exclude_low_count_spin.setRange(1, MAX_FILTER_VALUE)
        self.token_exclude_low_count_spin.setValue(3)
        self.token_exclude_low_count_spin.setFixedWidth(64)
        self.token_exclude_low_count_spin.setToolTip(
            "Minimum number of separate output labels that must contain each token/character."
        )
        self.token_prefer_rare_check = QCheckBox("Prefer rare-token labels when balancing")
        self.token_prefer_rare_check.setChecked(True)
        self.token_prefer_rare_check.setToolTip(
            "When frequency balancing must downsample rows, prefer rows whose output labels contain rarer tokens/characters."
        )

        self.charset_filter_check = QCheckBox("Filter by charset file")
        self.charset_filter_check.setChecked(False)
        self.charset_filter_check.setToolTip(
            "Export filter: keep only labels compatible with the selected PARSeq charset file. "
            "Uses strict string-token coverage: LaTeX commands/string tokens must be explicit latex_tokens."
        )
        self.charset_filter_path_edit = QLineEdit("")
        self.charset_filter_path_edit.setPlaceholderText("Choose PARSeq charset YAML…")
        self.charset_filter_path_edit.setToolTip("Charset YAML used for strict string-token compatibility filtering.")
        self.charset_filter_browse_button = QPushButton("Browse…")
        self.charset_filter_browse_button.setToolTip("Choose a PARSeq charset YAML file for strict compatibility filtering.")
        self.charset_filter_note_label = QLabel("Strict canonical string-token coverage")
        self.charset_filter_note_label.setToolTip(
            "No loose fallback mode: canonical guarded command tokens like \theta{} plus structural string tokens like _{ and ^{ must be listed as latex_tokens."
        )

        self.token_occurrence_toggle = QPushButton("Token occurrence balance ▸")
        self.token_occurrence_toggle.setCheckable(True)
        self.token_occurrence_toggle.setChecked(False)
        self.token_occurrence_toggle.setVisible(False)
        self.token_occurrence_toggle.setToolTip("Total token-occurrence balancing controls are shown inside Token / Charset Coverage.")
        self.token_occurrence_panel = QGroupBox("Token occurrence balance")
        self.token_occurrence_balance_check = QCheckBox("Balance total token occurrences")
        self.token_occurrence_balance_check.setChecked(False)
        self.token_occurrence_balance_check.setToolTip(
            "Hard-balance total token occurrences in the generated dataset. "
            "Rows containing tokens below the min are excluded; selected rows are clipped so no token exceeds max."
        )
        self.token_occurrence_target_mode_combo = QComboBox()
        self.token_occurrence_target_mode_combo.addItems(MAX_PER_LABEL_MODES)
        for idx, mode in enumerate(MAX_PER_LABEL_MODES):
            self.token_occurrence_target_mode_combo.setItemData(
                idx,
                tooltip_for_max_per_label_mode(mode),
                Qt.ItemDataRole.ToolTipRole,
            )
        self.token_occurrence_target_mode_combo.setCurrentText(MAX_PER_LABEL_MODE_AUTO_LOWER_MEDIAN)
        self.token_occurrence_target_mode_combo.setToolTip(
            "Resolve the hard maximum total occurrences allowed per token. The minimum is set separately."
        )
        self.token_occurrence_target_spin = QSpinBox()
        self.token_occurrence_target_spin.setRange(1, MAX_FILTER_VALUE)
        self.token_occurrence_target_spin.setValue(DEFAULT_MIN_CLASS_COUNT)
        self.token_occurrence_target_spin.setFixedWidth(76)
        self.token_occurrence_target_spin.setToolTip("Manual hard maximum total occurrences allowed per token.")
        self.token_occurrence_min_target_spin = QSpinBox()
        self.token_occurrence_min_target_spin.setRange(0, MAX_FILTER_VALUE)
        self.token_occurrence_min_target_spin.setValue(0)
        self.token_occurrence_min_target_spin.setFixedWidth(64)
        self.token_occurrence_min_target_spin.setToolTip(
            "Hard minimum total occurrences required per token. Rows containing tokens below this total are excluded."
        )
        self.token_occurrence_mode_combo = QComboBox()
        self.token_occurrence_mode_combo.addItems(TOKEN_OCCURRENCE_BALANCE_MODES)
        for idx, mode in enumerate(TOKEN_OCCURRENCE_BALANCE_MODES):
            self.token_occurrence_mode_combo.setItemData(
                idx,
                TOKEN_OCCURRENCE_BALANCE_TOOLTIPS.get(mode, ""),
                Qt.ItemDataRole.ToolTipRole,
            )
        self.token_occurrence_mode_combo.setCurrentText(TOKEN_OCCURRENCE_BALANCE_METHOD_CURRENT)
        self.token_occurrence_mode_combo.setToolTip(
            "Choose the algorithm used after the hard min/max token-occurrence range is resolved."
        )
        self.token_occurrence_help_label = QLabel(
            "Hard range: exclude rows with tokens below min total occurrences; then select rows without letting any token exceed max. "
            "Use Algorithm to compare the original adaptive method, optimized adaptive method, and fast two-pass method."
        )
        self.token_occurrence_help_label.setWordWrap(True)

        self.filter_spinboxes = (
            self.frequency_min_spin,
            self.frequency_max_spin,
            self.length_min_spin,
            self.length_max_spin,
            self.unique_min_spin,
            self.unique_max_spin,
            self.token_exclude_low_count_spin,
            self.token_occurrence_target_spin,
            self.token_occurrence_min_target_spin,
        )
        for spin in self.filter_spinboxes:
            # Keep keyboard tracking off so valueChanged does not fire on every
            # digit, then listen to the embedded line edit and debounce from
            # there. current_frequency_options() commits the typed text with
            # interpretText(), so a user does not have to click away first.
            spin.setKeyboardTracking(False)
            spin.lineEdit().textEdited.connect(self.on_filter_spin_text_edited)

        self.copy_images_check = QCheckBox("Copy images referenced by JSON")
        self.copy_images_check.setChecked(True)
        self.copy_images_check.setToolTip("Copy each file named by the JSON image field into the matching output folder.")

        self.column_view_combo = QComboBox()
        self.column_view_combo.addItems(COLUMN_VIEW_CHOICES)
        self.column_view_combo.setCurrentText(DEFAULT_COLUMN_VIEW)
        self.column_view_combo.setToolTip(
            "Choose a preset set of preview columns. Use Columns… for a custom view."
        )
        self.columns_button = QPushButton("Columns…")
        self.columns_button.setToolTip("Choose preview columns and switch the View preset to Custom.")
        self.charset_preview_button = QPushButton("Charset Preview…")
        self.charset_preview_button.setToolTip("Preview a filtered regular or string-token PARSeq charset config from current output labels.")
        self.token_audit_button = QPushButton("Token Audit…")
        self.token_audit_button.setToolTip("Audit how many separate output labels contain each token/character, plus total occurrences.")
        self.preview_button = QPushButton("Preview")
        self.convert_button = QPushButton("Convert")
        self.convert_button.setEnabled(False)

        self.progress = QProgressBar()
        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.status_label = QLabel("Choose an input folder of JSON files.")

        self.log_toggle = QPushButton("Log ▸")
        self.log_toggle.setCheckable(True)
        self.log_toggle.setChecked(False)
        self.log_toggle.setToolTip("Show or hide the status and token-balance log.")
        self.log_panel = QWidget()
        self.log_text = QTextEdit()
        self.log_text.setReadOnly(True)
        self.log_text.setLineWrapMode(QTextEdit.LineWrapMode.NoWrap)
        self.log_text.setPlaceholderText("Preview/export status and token-balance details will appear here.")
        self.log_text.setMinimumHeight(110)
        self.log_text.setMaximumHeight(240)
        log_mono = QFont("Menlo")
        log_mono.setStyleHint(QFont.StyleHint.Monospace)
        log_mono.setPointSize(11)
        self.log_text.setFont(log_mono)

        self.table = QTableWidget(0, 0)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        header = self.table.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        header.setSectionsMovable(True)
        header.setStretchLastSection(False)
        vertical_header = self.table.verticalHeader()
        vertical_header.setVisible(True)
        vertical_header.setSectionResizeMode(QHeaderView.ResizeMode.Interactive)

        mono = QFont("Menlo")
        mono.setStyleHint(QFont.StyleHint.Monospace)
        mono.setPointSize(12)
        self.table.setFont(mono)

        self.preview_search_edit = QLineEdit()
        self.preview_search_edit.setPlaceholderText(r"Search preview rows, e.g. \to, →, _{, ²")
        self.preview_search_edit.setToolTip(
            "Filter the visible preview table only. This does not change conversion/export output."
        )
        self.preview_search_scope_combo = QComboBox()
        self.preview_search_scope_combo.addItems((
            "Before + After",
            "Before only",
            "After only",
            "File / path",
            "Status",
            "All visible columns",
        ))
        self.preview_search_scope_combo.setCurrentText("Before + After")
        self.preview_search_scope_combo.setToolTip("Choose which preview columns the search filter checks.")
        self.preview_search_case_check = QCheckBox("Case")
        self.preview_search_case_check.setToolTip("Match uppercase/lowercase exactly.")
        self.preview_search_whole_word_check = QCheckBox("Whole word")
        self.preview_search_whole_word_check.setToolTip(
            "Match the search text as a whole word/token instead of as a substring."
        )
        self.preview_search_regex_check = QCheckBox("Regex")
        self.preview_search_regex_check.setToolTip("Treat the search text as a Python regular expression.")
        self.clear_preview_search_button = QPushButton("Clear Search")
        self.clear_preview_search_button.setToolTip("Clear the preview search filter and show all preview rows again.")
        self.preview_search_count_label = QLabel("Preview search inactive.")
        self.preview_search_count_label.setToolTip("Search affects only the table view. Export still uses the full current preview.")

        self._build_layout()
        self._connect_signals()
        self._install_shortcuts()
        self.update_direction_dependent_controls()
        self.update_frequency_controls_enabled()

    def _build_layout(self) -> None:
        root = QWidget()
        layout = QVBoxLayout(root)
        layout.setContentsMargins(12, 12, 12, 12)
        layout.setSpacing(10)

        box = QGroupBox("Folders")
        grid = QGridLayout(box)
        grid.setColumnStretch(1, 1)

        input_browse = QPushButton("Browse…")
        input_browse.clicked.connect(self.choose_input_dir)
        output_browse = QPushButton("Browse…")
        output_browse.clicked.connect(self.choose_output_dir)

        grid.addWidget(QLabel("Input JSON folder"), 0, 0)
        grid.addWidget(self.input_edit, 0, 1)
        grid.addWidget(input_browse, 0, 2)
        grid.addWidget(QLabel("Output folder"), 1, 0)
        grid.addWidget(self.output_edit, 1, 1)
        grid.addWidget(output_browse, 1, 2)
        grid.addWidget(QLabel("Filename suffix"), 2, 0)
        grid.addWidget(self.suffix_edit, 2, 1)
        grid.addWidget(self.copy_images_check, 3, 1, 1, 2)
        grid.addWidget(self.recursive_check, 4, 1, 1, 2)
        layout.addWidget(box)

        options = QWidget()
        options_layout = QGridLayout(options)
        options_layout.setContentsMargins(0, 0, 0, 0)
        options_layout.setHorizontalSpacing(8)
        options_layout.setVerticalSpacing(4)
        options_layout.addWidget(QLabel("Convert to"), 0, 0)
        options_layout.addWidget(self.direction_combo, 0, 1)
        options_layout.addWidget(QLabel("Spaces"), 0, 2)
        options_layout.addWidget(self.space_mode_combo, 0, 3)
        options_layout.addWidget(QLabel("Existing LaTeX"), 0, 4)
        options_layout.addWidget(self.existing_latex_combo, 0, 5)
        options_layout.addWidget(self.escape_specials_check, 0, 6)
        options_layout.addWidget(QLabel("View"), 0, 7)
        options_layout.addWidget(self.column_view_combo, 0, 8)
        options_layout.addWidget(self.columns_button, 0, 9)
        options_layout.addWidget(self.charset_preview_button, 0, 10)
        options_layout.addWidget(self.preview_button, 0, 11)
        options_layout.addWidget(self.convert_button, 0, 12)
        options_layout.setColumnStretch(13, 1)
        layout.addWidget(options)

        filter_header = QWidget()
        filter_header_layout = QHBoxLayout(filter_header)
        filter_header_layout.setContentsMargins(0, 0, 0, 0)
        filter_header_layout.addWidget(self.filters_toggle)
        filter_header_layout.addStretch(1)
        layout.addWidget(filter_header)

        filters_layout = QGridLayout(self.filters_panel)
        filters_layout.setContentsMargins(16, 0, 0, 0)
        filters_layout.setHorizontalSpacing(8)
        filters_layout.setVerticalSpacing(4)
        filters_layout.addWidget(self.frequency_filter_check, 0, 0)
        filters_layout.addWidget(QLabel("Min class count"), 0, 1)
        filters_layout.addWidget(self.frequency_min_spin, 0, 2)
        filters_layout.addWidget(QLabel("Max per label"), 0, 3)
        filters_layout.addWidget(self.frequency_max_mode_combo, 0, 4)
        filters_layout.addWidget(self.frequency_max_spin, 0, 5)

        filters_layout.addWidget(self.length_filter_check, 1, 0)
        filters_layout.addWidget(QLabel("Min"), 1, 1)
        filters_layout.addWidget(self.length_min_spin, 1, 2)
        filters_layout.addWidget(QLabel("Max"), 1, 3)
        filters_layout.addWidget(self.length_max_spin, 1, 4)

        filters_layout.addWidget(self.unique_filter_check, 2, 0)
        filters_layout.addWidget(QLabel("Min"), 2, 1)
        filters_layout.addWidget(self.unique_min_spin, 2, 2)
        filters_layout.addWidget(QLabel("Max"), 2, 3)
        filters_layout.addWidget(self.unique_max_spin, 2, 4)
        filters_layout.setColumnStretch(5, 1)
        layout.addWidget(self.filters_panel)
        self.filters_panel.setVisible(self.filters_toggle.isChecked())

        token_header = QWidget()
        token_header_layout = QHBoxLayout(token_header)
        token_header_layout.setContentsMargins(0, 0, 0, 0)
        token_header_layout.addWidget(self.token_coverage_toggle)
        token_header_layout.addStretch(1)
        layout.addWidget(token_header)

        token_layout = QGridLayout(self.token_coverage_panel)
        token_layout.setContentsMargins(16, 0, 0, 0)
        token_layout.setHorizontalSpacing(8)
        token_layout.setVerticalSpacing(4)
        token_layout.addWidget(self.token_audit_button, 0, 0)
        token_layout.addWidget(QLabel("Unit"), 0, 1)
        token_layout.addWidget(self.token_coverage_unit_combo, 0, 2)
        token_layout.addWidget(QLabel("Export filters"), 1, 0)
        token_layout.addWidget(self.token_exclude_low_count_check, 1, 1, 1, 2)
        token_layout.addWidget(self.token_exclude_low_count_spin, 1, 3)
        token_layout.addWidget(QLabel("Balancing"), 2, 0)
        token_layout.addWidget(self.token_prefer_rare_check, 2, 1, 1, 3)
        token_layout.addWidget(QLabel("Charset file"), 3, 0)
        token_layout.addWidget(self.charset_filter_check, 3, 1)
        token_layout.addWidget(self.charset_filter_path_edit, 3, 2, 1, 3)
        token_layout.addWidget(self.charset_filter_browse_button, 3, 5)
        token_layout.addWidget(self.charset_filter_note_label, 3, 6, 1, 2)

        occurrence_layout = QGridLayout(self.token_occurrence_panel)
        occurrence_layout.setContentsMargins(8, 6, 8, 8)
        occurrence_layout.setHorizontalSpacing(8)
        occurrence_layout.setVerticalSpacing(4)
        occurrence_layout.addWidget(self.token_occurrence_balance_check, 0, 0, 1, 6)
        occurrence_layout.addWidget(QLabel("Total occurrences/token"), 1, 0)
        occurrence_layout.addWidget(QLabel("Min"), 1, 1)
        occurrence_layout.addWidget(self.token_occurrence_min_target_spin, 1, 2)
        occurrence_layout.addWidget(QLabel("Max"), 1, 3)
        occurrence_layout.addWidget(self.token_occurrence_target_mode_combo, 1, 4)
        occurrence_layout.addWidget(self.token_occurrence_target_spin, 1, 5)
        occurrence_layout.addWidget(QLabel("Algorithm"), 2, 0)
        occurrence_layout.addWidget(self.token_occurrence_mode_combo, 2, 1)
        occurrence_layout.addWidget(self.token_occurrence_help_label, 3, 0, 1, 6)
        occurrence_layout.setColumnStretch(6, 1)
        token_layout.addWidget(self.token_occurrence_panel, 0, 4, 3, 4)
        self.token_occurrence_panel.setVisible(True)

        token_layout.setColumnStretch(3, 1)
        token_layout.setColumnStretch(7, 2)
        layout.addWidget(self.token_coverage_panel)
        self.token_coverage_panel.setVisible(self.token_coverage_toggle.isChecked())

        search_header = QWidget()
        search_header_layout = QHBoxLayout(search_header)
        search_header_layout.setContentsMargins(0, 0, 0, 0)
        search_header_layout.addWidget(self.search_toggle)
        search_header_layout.addWidget(self.preview_search_count_label)
        search_header_layout.addStretch(1)
        layout.addWidget(search_header)

        search_layout = QHBoxLayout(self.search_panel)
        search_layout.setContentsMargins(16, 0, 0, 0)
        search_layout.setSpacing(8)
        search_layout.addWidget(QLabel("Search preview"))
        search_layout.addWidget(self.preview_search_edit, 1)
        search_layout.addWidget(QLabel("In"))
        search_layout.addWidget(self.preview_search_scope_combo)
        search_layout.addWidget(self.preview_search_case_check)
        search_layout.addWidget(self.preview_search_whole_word_check)
        search_layout.addWidget(self.preview_search_regex_check)
        search_layout.addWidget(self.clear_preview_search_button)
        layout.addWidget(self.search_panel)
        self.search_panel.setVisible(self.search_toggle.isChecked())

        layout.addWidget(self.table, 1)
        layout.addWidget(self.progress)
        layout.addWidget(self.log_toggle)
        log_layout = QVBoxLayout(self.log_panel)
        log_layout.setContentsMargins(16, 0, 0, 0)
        log_layout.setSpacing(4)
        log_layout.addWidget(self.log_text)
        layout.addWidget(self.log_panel)
        self.log_panel.setVisible(self.log_toggle.isChecked())
        layout.addWidget(self.status_label)
        self.status_label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        self.setCentralWidget(root)

    def _connect_signals(self) -> None:
        self.filters_toggle.toggled.connect(self.on_filters_toggled)
        self.search_toggle.toggled.connect(self.on_search_toggled)
        self.log_toggle.toggled.connect(self.on_log_toggled)
        self.token_coverage_toggle.toggled.connect(self.on_token_coverage_toggled)
        # Token occurrence controls are displayed inline inside Token / Charset Coverage.
        self.column_view_combo.currentTextChanged.connect(self.on_column_view_changed)
        self.columns_button.clicked.connect(self.show_column_options)
        self.charset_preview_button.clicked.connect(self.show_charset_preview)
        self.token_audit_button.clicked.connect(self.show_token_audit)
        self.preview_button.clicked.connect(self.preview)
        self.convert_button.clicked.connect(self.convert)
        self.recursive_check.toggled.connect(self.on_recursive_changed)
        self.input_edit.textChanged.connect(self.on_input_changed)
        self.output_edit.textEdited.connect(self.on_output_manually_edited)
        self.direction_combo.currentTextChanged.connect(self.on_conversion_direction_changed)
        self.space_mode_combo.currentTextChanged.connect(self.on_space_mode_changed)
        self.existing_latex_combo.currentTextChanged.connect(self.on_existing_latex_mode_changed)
        self.escape_specials_check.toggled.connect(self.on_escape_specials_changed)
        self.frequency_filter_check.toggled.connect(self.on_frequency_filter_changed)
        self.frequency_min_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.frequency_max_mode_combo.currentTextChanged.connect(self.on_max_per_label_mode_changed)
        self.frequency_max_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.length_filter_check.toggled.connect(self.on_frequency_filter_changed)
        self.length_min_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.length_max_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.unique_filter_check.toggled.connect(self.on_frequency_filter_changed)
        self.unique_min_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.unique_max_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.token_coverage_unit_combo.currentTextChanged.connect(self.on_token_coverage_filter_changed)
        self.token_exclude_low_count_check.toggled.connect(self.on_token_coverage_filter_changed)
        self.token_exclude_low_count_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.token_prefer_rare_check.toggled.connect(self.on_token_coverage_filter_changed)
        self.charset_filter_check.toggled.connect(self.on_charset_filter_changed)
        self.charset_filter_path_edit.textEdited.connect(self.on_charset_filter_path_edited)
        self.charset_filter_browse_button.clicked.connect(self.choose_charset_filter_file)
        self.token_occurrence_balance_check.toggled.connect(self.on_token_coverage_filter_changed)
        self.token_occurrence_target_mode_combo.currentTextChanged.connect(self.on_token_occurrence_target_mode_changed)
        self.token_occurrence_target_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.token_occurrence_min_target_spin.valueChanged.connect(self.on_frequency_range_changed)
        self.token_occurrence_mode_combo.currentTextChanged.connect(self.on_token_occurrence_algorithm_changed)
        self.preview_search_edit.textChanged.connect(self.schedule_preview_search)
        self.preview_search_scope_combo.currentTextChanged.connect(self.apply_preview_search)
        self.preview_search_case_check.toggled.connect(self.apply_preview_search)
        self.preview_search_whole_word_check.toggled.connect(self.apply_preview_search)
        self.preview_search_regex_check.toggled.connect(self.apply_preview_search)
        self.clear_preview_search_button.clicked.connect(self.clear_preview_search)

    def _install_shortcuts(self) -> None:
        """Install app-level shortcuts for preview search."""
        self.preview_find_shortcut = QShortcut(QKeySequence.StandardKey.Find, self)
        self.preview_find_shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
        self.preview_find_shortcut.activated.connect(self.open_preview_search)

        self.preview_search_escape_shortcut = QShortcut(QKeySequence("Esc"), self)
        self.preview_search_escape_shortcut.setContext(Qt.ShortcutContext.WindowShortcut)
        self.preview_search_escape_shortcut.activated.connect(self.handle_preview_search_escape)

    def on_filters_toggled(self, checked: bool) -> None:
        self.filters_panel.setVisible(checked)
        self.filters_toggle.setText("Filters ▾" if checked else "Filters ▸")

    def on_search_toggled(self, checked: bool) -> None:
        self.search_panel.setVisible(checked)
        self.search_toggle.setText("Search ▾" if checked else "Search ▸")
        if checked:
            self.preview_search_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
            self.preview_search_edit.selectAll()

    def on_log_toggled(self, checked: bool) -> None:
        self.log_panel.setVisible(checked)
        self.log_toggle.setText("Log ▾" if checked else "Log ▸")

    def append_log_message(self, message: str) -> None:
        if not message or not hasattr(self, "log_text"):
            return
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.append(f"[{timestamp}] {message}")
        self.log_text.moveCursor(QTextCursor.MoveOperation.End)

    def append_log_block(self, title: str, body: str) -> None:
        if not hasattr(self, "log_text"):
            return
        timestamp = time.strftime("%H:%M:%S")
        self.log_text.append(f"\n[{timestamp}] {title}")
        if body:
            self.log_text.append(body)
        self.log_text.moveCursor(QTextCursor.MoveOperation.End)

    def set_status_message(self, message: str, *, log: bool = True) -> None:
        self.status_label.setText(message)
        if log:
            self.append_log_message(message)

    def append_current_token_occurrence_log(self, options: FrequencyFilterOptions | None = None) -> None:
        if options is None:
            options = self.current_frequency_options(show_warning=False)
        if options is None:
            return
        charset_body = build_charset_filter_log_text(
            self.preview_rows,
            self.preview_candidate_rows,
            options,
        )
        self.append_log_block("Charset compatibility audit", charset_body)
        body = build_token_occurrence_log_text(
            self.preview_rows,
            self.preview_candidate_rows,
            options,
        )
        self.append_log_block("Token occurrence audit", body)

    def on_token_coverage_toggled(self, checked: bool) -> None:
        self.token_coverage_panel.setVisible(checked)
        self.token_coverage_toggle.setText("Token / Charset Coverage ▾" if checked else "Token / Charset Coverage ▸")

    def on_token_occurrence_toggled(self, checked: bool) -> None:
        self.token_occurrence_panel.setVisible(checked)
        self.token_occurrence_toggle.setText("Token occurrence balance ▾" if checked else "Token occurrence balance ▸")

    def on_token_occurrence_target_mode_changed(self, mode: str) -> None:
        self.token_occurrence_target_mode_combo.setToolTip(
            f"Resolve the hard maximum total occurrences allowed per token. The minimum is set separately. {tooltip_for_max_per_label_mode(mode)}"
        )
        self.update_frequency_controls_enabled()
        self.schedule_preview_refresh(full_rescan=False, delay_ms=250)

    def token_coverage_use_hybrid_tokens(self) -> bool:
        mode = self.token_coverage_unit_combo.currentText()
        if mode == TOKEN_AUDIT_MODE_HYBRID:
            return True
        if mode == TOKEN_AUDIT_MODE_CHARS:
            return False
        return self.conversion_direction == OUTPUT_CONVENTION_LATEX

    def on_token_coverage_filter_changed(self, *_args: object) -> None:
        self.update_frequency_controls_enabled()
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def choose_charset_filter_file(self) -> None:
        start_text = self.charset_filter_path_edit.text().strip()
        if start_text:
            start = str(Path(start_text).expanduser().parent)
        else:
            start = str(find_parseq_charset_start_dir())
        path_text, _filter = QFileDialog.getOpenFileName(
            self,
            "Choose charset YAML for filtering",
            start,
            "YAML files (*.yaml *.yml);;All files (*)",
        )
        if not path_text:
            return
        self.charset_filter_path_edit.setText(path_text)
        remember_charset_template_path(Path(path_text))
        self.charset_filter_check.setChecked(True)
        self.on_charset_filter_changed()

    def on_charset_filter_changed(self, *_args: object) -> None:
        self.update_frequency_controls_enabled()
        self.schedule_preview_refresh(full_rescan=False, delay_ms=250)

    def on_charset_filter_path_edited(self, _text: str) -> None:
        self.schedule_preview_refresh(full_rescan=False, delay_ms=650)

    def open_preview_search(self) -> None:
        """Open the preview search section and focus the search box."""
        if not self.search_toggle.isChecked():
            self.search_toggle.setChecked(True)
        self.preview_search_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
        self.preview_search_edit.selectAll()

    def handle_preview_search_escape(self) -> None:
        """Esc clears search text first, then collapses the search section."""
        if not self.search_toggle.isChecked():
            return
        if self.preview_search_edit.text():
            self.clear_preview_search()
            self.preview_search_edit.setFocus(Qt.FocusReason.ShortcutFocusReason)
            return
        self.search_toggle.setChecked(False)
        self.table.setFocus(Qt.FocusReason.ShortcutFocusReason)

    def on_filter_spin_text_edited(self, _text: str) -> None:
        if self._updating_filter_limits:
            return
        self.schedule_preview_refresh(full_rescan=False, delay_ms=650)

    def commit_filter_spinbox_text(self) -> None:
        """Commit typed spinbox text without requiring focus to leave the field."""
        if self._updating_filter_limits:
            return
        self._updating_filter_limits = True
        try:
            for spin in self.filter_spinboxes:
                spin.interpretText()
        finally:
            self._updating_filter_limits = False

    def on_conversion_direction_changed(self, mode: str) -> None:
        if not isinstance(mode, str) or mode == self.conversion_direction:
            return
        self.conversion_direction = mode
        self.update_direction_dependent_controls()
        if self.output_auto_managed:
            self.update_default_output_folder()
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def on_space_mode_changed(self, mode: str) -> None:
        if not isinstance(mode, str) or mode == self.space_mode:
            return
        self.space_mode = mode
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def on_existing_latex_mode_changed(self, mode: str) -> None:
        if not isinstance(mode, str) or mode == self.existing_latex_mode:
            return
        self.existing_latex_mode = mode
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def on_escape_specials_changed(self, _checked: bool) -> None:
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def on_recursive_changed(self, _checked: bool) -> None:
        self.refresh_filter_limit_ranges()
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def on_frequency_filter_changed(self, _checked: bool) -> None:
        self.update_frequency_controls_enabled()
        self.schedule_preview_refresh(full_rescan=False, delay_ms=250)

    def on_frequency_range_changed(self, _value: int) -> None:
        if self._updating_filter_limits:
            return
        self.schedule_preview_refresh(full_rescan=False, delay_ms=450)

    def on_token_occurrence_algorithm_changed(self, mode: str) -> None:
        self.token_occurrence_mode_combo.setToolTip(
            TOKEN_OCCURRENCE_BALANCE_TOOLTIPS.get(
                normalized_token_occurrence_balance_mode(mode),
                "Choose the token-occurrence balancing algorithm.",
            )
        )
        self.on_token_coverage_filter_changed()

    def on_max_per_label_mode_changed(self, mode: str) -> None:
        self.frequency_max_mode_combo.setToolTip(tooltip_for_max_per_label_mode(mode))
        self.update_frequency_controls_enabled()
        self.schedule_preview_refresh(full_rescan=False, delay_ms=250)

    def update_frequency_controls_enabled(self) -> None:
        freq_enabled = self.frequency_filter_check.isChecked()
        manual_max = self.frequency_max_mode_combo.currentText() == MAX_PER_LABEL_MODE_MANUAL
        length_enabled = self.length_filter_check.isChecked()
        unique_enabled = self.unique_filter_check.isChecked()
        self.frequency_min_spin.setEnabled(freq_enabled)
        self.frequency_max_mode_combo.setEnabled(freq_enabled)
        self.frequency_max_spin.setVisible(manual_max)
        self.frequency_max_spin.setEnabled(freq_enabled and manual_max)
        self.length_min_spin.setEnabled(length_enabled)
        self.length_max_spin.setEnabled(length_enabled)
        token_filter_enabled = self.token_exclude_low_count_check.isChecked()
        occurrence_enabled = self.token_occurrence_balance_check.isChecked()
        occurrence_manual = self.token_occurrence_target_mode_combo.currentText() == MAX_PER_LABEL_MODE_MANUAL
        self.unique_min_spin.setEnabled(unique_enabled)
        self.unique_max_spin.setEnabled(unique_enabled)
        self.token_exclude_low_count_spin.setEnabled(token_filter_enabled)
        self.token_occurrence_balance_check.setEnabled(True)
        self.token_occurrence_target_mode_combo.setEnabled(occurrence_enabled)
        self.token_occurrence_target_spin.setVisible(occurrence_manual)
        self.token_occurrence_target_spin.setEnabled(occurrence_enabled and occurrence_manual)
        self.token_occurrence_min_target_spin.setEnabled(occurrence_enabled)
        self.token_occurrence_mode_combo.setEnabled(occurrence_enabled)

    def _set_filter_spin_pair(
        self,
        min_spin: QSpinBox,
        max_spin: QSpinBox,
        low: int,
        high: int,
    ) -> None:
        """Clamp a min/max spinbox pair to an actual observed maximum."""
        high = max(low, high)
        old_maximum = max_spin.maximum()
        old_max_value = max_spin.value()
        max_was_at_ceiling = old_max_value >= old_maximum

        min_spin.setRange(low, high)
        max_spin.setRange(low, high)

        new_min = min(max(min_spin.value(), low), high)
        if max_was_at_ceiling or old_max_value > high:
            new_max = high
        else:
            new_max = min(max(old_max_value, low), high)
        if new_min > new_max:
            new_min = low
        min_spin.setValue(new_min)
        max_spin.setValue(new_max)

    def _set_class_balance_spin_ranges(self, max_frequency: int) -> None:
        """Clamp class-balance spinboxes to the observed output-label frequency."""
        max_frequency = max(1, max_frequency)
        self.frequency_min_spin.setRange(1, max_frequency)
        self.frequency_min_spin.setValue(min(max(self.frequency_min_spin.value(), 1), max_frequency))

        old_max_per_label = self.frequency_max_spin.value()
        self.frequency_max_spin.setRange(1, max_frequency)
        fallback = min(max(DEFAULT_MIN_CLASS_COUNT, 1), max_frequency)
        self.frequency_max_spin.setValue(min(max(old_max_per_label or fallback, 1), max_frequency))

    def refresh_filter_limit_ranges(self) -> None:
        """Update filter spinbox ranges to the actual maxima in the dataset."""
        input_dir = self.current_input_dir_if_valid()
        if input_dir is None:
            return
        self.commit_filter_spinbox_text()

        limits, _frequency_counts, _errors = collect_filter_metric_limits(
            input_dir,
            self.recursive_check.isChecked(),
            self.space_mode,
            self.existing_latex_mode,
            self.escape_specials_check.isChecked(),
            self.conversion_direction,
            use_hybrid_tokens=self.token_coverage_use_hybrid_tokens() if hasattr(self, "token_coverage_unit_combo") else self.conversion_direction == OUTPUT_CONVENTION_LATEX,
        )
        self.filter_limits = limits
        self._updating_filter_limits = True
        try:
            self._set_class_balance_spin_ranges(limits.max_frequency)
            self._set_filter_spin_pair(self.length_min_spin, self.length_max_spin, 0, limits.max_length)
            self._set_filter_spin_pair(self.unique_min_spin, self.unique_max_spin, 0, limits.max_unique)
            self.frequency_max_mode_combo.setToolTip(
                f"{tooltip_for_max_per_label_mode(self.frequency_max_mode_combo.currentText())} "
                f"Actual max class count: {limits.max_frequency}."
            )
            self.frequency_max_spin.setToolTip(
                f"Manual maximum entries to keep per output-label class. Actual max class count: {limits.max_frequency}."
            )
            self.length_max_spin.setToolTip(f"Maximum output token length, inclusive. Actual max: {limits.max_length}.")
            self.unique_max_spin.setToolTip(f"Maximum output unique-token count, inclusive. Actual max: {limits.max_unique}.")
        finally:
            self._updating_filter_limits = False
        self.update_frequency_controls_enabled()

    def update_direction_dependent_controls(self) -> None:
        latex_options_enabled = self.conversion_direction == OUTPUT_CONVENTION_LATEX
        self.existing_latex_combo.setEnabled(latex_options_enabled)
        self.escape_specials_check.setEnabled(latex_options_enabled)

    def current_table_columns(self) -> list[tuple[str, str]]:
        columns = [(key, title) for key, title in ALL_COLUMN_SPECS if key in self.visible_column_keys]
        if not columns:
            columns = [(key, title) for key, title in ALL_COLUMN_SPECS if key in {"before", "after", "status"}]
        return columns

    def preview_row_status_text(self, row: LabelPreview) -> str:
        """Build the same status text used in the preview table."""
        status_parts: list[str] = []
        status_parts.append("changed" if row.changed else "unchanged")
        if row.space_action:
            status_parts.append(row.space_action)
        if row.escape_action:
            status_parts.append(row.escape_action)
        if row.preserve_action:
            status_parts.append(row.preserve_action)
        if row.unicode_action:
            status_parts.append(row.unicode_action)
        return "; ".join(status_parts)

    def preview_row_search_fields(self, row: LabelPreview, scope: str) -> list[str]:
        """Return row text fields checked by the preview-only search filter."""
        base = self.current_input_dir_if_valid() or Path.cwd()
        try:
            rel_file = str(row.file_path.relative_to(base))
        except ValueError:
            rel_file = str(row.file_path)

        status = self.preview_row_status_text(row)
        all_visible: dict[str, str] = {
            "file": rel_file,
            "label_path": row.label_path,
            "before": row.before,
            "after": row.after,
            "status": status,
            "label_frequency": str(row.label_frequency),
            "before_raw_length": str(row.before_raw_length),
            "after_raw_length": str(row.after_raw_length),
            "after_token_length": str(row.after_token_length),
            "token_length_delta": str(row.token_length_delta),
            "unique_after_tokens": str(row.unique_after_tokens),
            "label_stats": row.label_stats,
        }

        if scope == "Before only":
            return [row.before]
        if scope == "After only":
            return [row.after]
        if scope == "File / path":
            return [rel_file, row.label_path]
        if scope == "Status":
            return [status]
        if scope == "All visible columns":
            return [all_visible.get(key, "") for key, _title in self.current_table_columns()]
        return [row.before, row.after]

    def preview_search_word_boundary_pattern(self, inner_pattern: str) -> str:
        """Wrap a search pattern so it matches as a whole word/token.

        The boundary is intentionally math-label friendly: letters, digits, and
        underscore count as word/token characters. This lets searches such as
        `to` avoid matching `into`, and `\\to` avoid matching `\\top`,
        while still working with LaTeX backslash commands.
        """
        return rf"(?<![A-Za-z0-9_])(?:{inner_pattern})(?![A-Za-z0-9_])"

    def compile_preview_search_pattern(self, query: str) -> tuple[re.Pattern[str] | None, str | None]:
        """Compile regex/whole-word preview search when needed."""
        use_regex = self.preview_search_regex_check.isChecked()
        whole_word = self.preview_search_whole_word_check.isChecked()
        if not use_regex and not whole_word:
            return None, None

        pattern_text = query if use_regex else re.escape(query)
        if whole_word:
            pattern_text = self.preview_search_word_boundary_pattern(pattern_text)

        flags = 0 if self.preview_search_case_check.isChecked() else re.IGNORECASE
        try:
            return re.compile(pattern_text, flags), None
        except re.error as exc:
            return None, f"Invalid regex: {exc}"

    def row_matches_preview_search(
        self,
        row: LabelPreview,
        query: str,
        scope: str,
        search_pattern: re.Pattern[str] | None = None,
    ) -> bool:
        """Return True when a row should be visible under the preview search."""
        fields = self.preview_row_search_fields(row, scope)
        if search_pattern is not None:
            return any(search_pattern.search(field) is not None for field in fields)

        if self.preview_search_case_check.isChecked():
            return any(query in field for field in fields)

        folded_query = query.casefold()
        return any(folded_query in field.casefold() for field in fields)

    def filtered_preview_rows_for_search(self) -> tuple[list[LabelPreview], str | None]:
        """Return current preview rows filtered by the preview-only search box."""
        query = self.preview_search_edit.text().strip()
        if not query:
            return list(self.preview_rows), None

        scope = self.preview_search_scope_combo.currentText()
        search_pattern, error_message = self.compile_preview_search_pattern(query)
        if error_message is not None:
            return [], error_message

        rows = [
            row
            for row in self.preview_rows
            if self.row_matches_preview_search(row, query, scope, search_pattern)
        ]
        return rows, None

    def schedule_preview_search(self, _text: str = "") -> None:
        """Debounce preview-search filtering while typing."""
        self.preview_search_timer.start()

    def clear_preview_search(self) -> None:
        """Clear the preview-only search filter and restore all current preview rows."""
        if self.preview_search_edit.text():
            self.preview_search_edit.clear()
        else:
            self.apply_preview_search()

    def apply_preview_search(self, *_args: object) -> None:
        """Apply the table-only search filter without changing export rows."""
        rows, error = self.filtered_preview_rows_for_search()
        self.populate_table(rows)

        total = len(self.preview_rows)
        query_active = bool(self.preview_search_edit.text().strip())
        visible_count = min(len(rows), 5000)
        if error:
            self.preview_search_count_label.setText(error)
            self.convert_button.setEnabled(self.preview_file_count > 0 and total > 0)
            return
        if query_active:
            if len(rows) > visible_count:
                self.preview_search_count_label.setText(
                    f"Showing first {visible_count} of {len(rows)} matches ({total} preview rows). Export unaffected."
                )
            else:
                self.preview_search_count_label.setText(
                    f"Showing {len(rows)} of {total} preview rows. Export unaffected."
                )
        elif total:
            if len(rows) > visible_count:
                self.preview_search_count_label.setText(
                    f"Showing first {visible_count} of {total} preview rows."
                )
            else:
                self.preview_search_count_label.setText(f"Showing all {total} preview rows.")
        else:
            self.preview_search_count_label.setText("Preview search inactive.")
        self.convert_button.setEnabled(self.preview_file_count > 0 and total > 0)

    def on_column_view_changed(self, view_name: str) -> None:
        """Apply a column-view preset without changing export behavior."""
        preset_keys = COLUMN_VIEW_PRESETS.get(view_name)
        if preset_keys is None:
            return
        self.visible_column_keys = set(preset_keys)
        self.apply_preview_search()

    def set_column_view_custom(self) -> None:
        old_block = self.column_view_combo.blockSignals(True)
        try:
            self.column_view_combo.setCurrentText(COLUMN_VIEW_CUSTOM)
        finally:
            self.column_view_combo.blockSignals(old_block)

    def show_column_options(self) -> None:
        dialog = ColumnOptionsDialog(self.visible_column_keys, self)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        selected_keys = dialog.selected_keys()
        if not selected_keys:
            QMessageBox.warning(self, APP_TITLE, "Choose at least one preview column.")
            return
        self.visible_column_keys = selected_keys
        self.set_column_view_custom()
        self.apply_preview_search()

    def show_charset_preview(self) -> None:
        dialog = CharsetPreviewDialog(
            self.collect_output_labels_for_charset_preview,
            space_mode=self.space_mode,
            conversion_direction=self.conversion_direction,
            parent=self,
        )
        dialog.exec()

    def show_token_audit(self) -> None:
        dialog = TokenCoverageAuditDialog(
            self.collect_output_labels_for_charset_preview,
            conversion_direction=self.conversion_direction,
            initial_unit_mode=self.token_coverage_unit_combo.currentText(),
            parent=self,
        )
        dialog.exec()

    def collect_output_labels_for_charset_preview(self) -> tuple[list[str], list[str]]:
        """Collect labels exactly as Convert would write them with current options.

        Prefer the current preview rows when they match the active options. This
        avoids recomputing expensive token-occurrence balancing when opening the
        charset preview or token audit immediately after Preview has already run.
        """
        input_dir = self.validate_input_dir()
        if input_dir is None:
            return [], []
        frequency_options = self.current_frequency_options()
        if frequency_options is None:
            return [], []

        row_signature = self.current_preview_rows_signature()
        if self.preview_has_run and row_signature is not None and self.preview_rows_signature == row_signature:
            return [row.after for row in self.preview_rows], list(self.preview_errors)

        data_signature = self.current_preview_data_signature()
        if (
            self.preview_candidate_rows
            and data_signature is not None
            and self.preview_candidate_signature == data_signature
        ):
            rows = select_rows_with_class_balance(self.preview_candidate_rows, frequency_options)
            self.preview_rows = rows
            self.preview_rows_signature = row_signature
            self.apply_preview_search()
            self.convert_button.setEnabled(self.preview_file_count > 0 and len(self.preview_rows) > 0)
            return [row.after for row in rows], list(self.preview_errors)

        rows, _file_count, _changed_count, errors, _frequency_counts = build_filtered_preview_rows(
            input_dir,
            self.recursive_check.isChecked(),
            self.space_mode,
            self.existing_latex_mode,
            self.escape_specials_check.isChecked(),
            self.conversion_direction,
            frequency_options,
        )
        return [row.after for row in rows], errors

    def on_output_manually_edited(self, _text: str) -> None:
        self.output_auto_managed = False

    def update_default_output_folder(self) -> None:
        input_dir = self.current_input_dir_if_valid()
        if input_dir is None:
            text = self.input_edit.text().strip()
            if not text:
                return
            input_dir = Path(text).expanduser()
        default_name = default_output_folder_name_for(self.conversion_direction)
        self.output_edit.setText(str(input_dir / default_name))

    def current_frequency_options(self, *, show_warning: bool = True) -> FrequencyFilterOptions | None:
        self.commit_filter_spinbox_text()
        freq_enabled = self.frequency_filter_check.isChecked()
        length_enabled = self.length_filter_check.isChecked()
        unique_enabled = self.unique_filter_check.isChecked()

        min_count = self.frequency_min_spin.value()
        max_count_mode = self.frequency_max_mode_combo.currentText()
        max_count_auto = max_count_mode != MAX_PER_LABEL_MODE_MANUAL
        max_count = self.frequency_max_spin.value()
        min_length = self.length_min_spin.value()
        max_length = self.length_max_spin.value()
        min_unique = self.unique_min_spin.value()
        max_unique = self.unique_max_spin.value()
        token_filter_enabled = self.token_exclude_low_count_check.isChecked()
        token_min_label_count = self.token_exclude_low_count_spin.value()
        token_unit_mode = self.token_coverage_unit_combo.currentText()
        token_use_hybrid_tokens = self.token_coverage_use_hybrid_tokens()
        prefer_rare_tokens = self.token_prefer_rare_check.isChecked()
        token_occurrence_balance_enabled = self.token_occurrence_balance_check.isChecked()
        token_occurrence_target_mode = self.token_occurrence_target_mode_combo.currentText()
        token_occurrence_target_auto = token_occurrence_target_mode != MAX_PER_LABEL_MODE_MANUAL
        token_occurrence_target_max = self.token_occurrence_target_spin.value()
        token_occurrence_min_target = self.token_occurrence_min_target_spin.value()
        token_occurrence_balance_mode = self.token_occurrence_mode_combo.currentText()
        charset_filter_enabled = self.charset_filter_check.isChecked()
        charset_filter_path = self.charset_filter_path_edit.text().strip()

        problems: list[str] = []
        if length_enabled and max_length < min_length:
            problems.append("Token-length max must be greater than or equal to min.")
        if unique_enabled and max_unique < min_unique:
            problems.append("Unique-token max must be greater than or equal to min.")
        if (
            token_occurrence_balance_enabled
            and not token_occurrence_target_auto
            and token_occurrence_target_max < token_occurrence_min_target
        ):
            problems.append("Token-occurrence max must be greater than or equal to min.")
        if charset_filter_enabled:
            if not charset_filter_path:
                problems.append("Choose a charset YAML file, or turn off Filter by charset file.")
            else:
                charset_path = Path(charset_filter_path).expanduser()
                if not charset_path.is_file():
                    problems.append(f"Charset filter file does not exist: {charset_path}")
                else:
                    try:
                        load_charset_filter_spec(charset_filter_path)
                    except Exception as exc:  # noqa: BLE001
                        problems.append(f"Could not read charset filter file: {exc}")
        if problems:
            if show_warning:
                QMessageBox.warning(self, APP_TITLE, "\n".join(problems))
            return None

        return FrequencyFilterOptions(
            enabled=freq_enabled,
            min_count=min_count,
            max_count_auto=max_count_auto,
            max_count_mode=max_count_mode,
            max_count=max_count,
            length_enabled=length_enabled,
            min_length=min_length,
            max_length=max_length,
            unique_enabled=unique_enabled,
            min_unique=min_unique,
            max_unique=max_unique,
            token_filter_enabled=token_filter_enabled,
            token_min_label_count=token_min_label_count,
            token_unit_mode=token_unit_mode,
            token_use_hybrid_tokens=token_use_hybrid_tokens,
            prefer_rare_tokens=prefer_rare_tokens,
            token_occurrence_balance_enabled=token_occurrence_balance_enabled,
            token_occurrence_target_auto=token_occurrence_target_auto,
            token_occurrence_target_mode=token_occurrence_target_mode,
            token_occurrence_target_max=token_occurrence_target_max,
            token_occurrence_min_target=token_occurrence_min_target,
            token_occurrence_balance_mode=token_occurrence_balance_mode,
            charset_filter_enabled=charset_filter_enabled,
            charset_filter_path=charset_filter_path,
        )

    def current_preview_data_signature(self) -> tuple[object, ...] | None:
        input_dir = self.current_input_dir_if_valid()
        if input_dir is None:
            return None
        try:
            input_key = str(input_dir.resolve())
        except Exception:  # noqa: BLE001
            input_key = str(input_dir)
        return (
            input_key,
            self.recursive_check.isChecked(),
            self.space_mode,
            self.existing_latex_mode,
            self.escape_specials_check.isChecked(),
            self.conversion_direction,
            self.token_coverage_use_hybrid_tokens() if hasattr(self, "token_coverage_unit_combo") else self.conversion_direction == OUTPUT_CONVENTION_LATEX,
        )

    def current_preview_rows_signature(self) -> tuple[object, ...] | None:
        """Return a signature for the exact rows that Convert/Preview would output."""
        data_signature = self.current_preview_data_signature()
        if data_signature is None:
            return None
        frequency_options = self.current_frequency_options(show_warning=False)
        if frequency_options is None:
            return None
        return (*data_signature, frequency_options)

    def schedule_preview_refresh(self, *, full_rescan: bool, delay_ms: int = 450) -> None:
        """Debounce preview updates so spinner edits do not rescan on every tick."""
        if not self.preview_has_run or self.current_input_dir_if_valid() is None:
            return
        self.pending_preview_full_rescan = self.pending_preview_full_rescan or full_rescan
        self.preview_refresh_timer.start(delay_ms)
        self.set_status_message("Preview update scheduled…")

    def _run_debounced_preview_refresh(self) -> None:
        if not self.preview_has_run or self.current_input_dir_if_valid() is None:
            return
        full_rescan = self.pending_preview_full_rescan
        self.pending_preview_full_rescan = False
        signature = self.current_preview_data_signature()
        if full_rescan or not self.preview_candidate_rows or signature != self.preview_candidate_signature:
            self.preview(refresh_limits=False)
        else:
            self.update_preview_from_cached_candidates()

    def refresh_preview_if_ready(self) -> None:
        self.schedule_preview_refresh(full_rescan=True, delay_ms=250)

    def current_input_dir_if_valid(self) -> Path | None:
        text = self.input_edit.text().strip()
        if not text:
            return None
        path = Path(text).expanduser()
        return path if path.is_dir() else None

    def choose_input_dir(self) -> None:
        start = self.input_edit.text().strip() or str(Path(__file__).resolve().parent)
        folder = QFileDialog.getExistingDirectory(self, "Choose input JSON folder", start)
        if not folder:
            return
        # Choosing a new input folder should move the managed output folder too.
        self.output_auto_managed = True
        self.input_edit.setText(folder)
        self.update_default_output_folder()
        self.refresh_filter_limit_ranges()

    def choose_output_dir(self) -> None:
        start = self.output_edit.text().strip() or self.input_edit.text().strip() or str(Path(__file__).resolve().parent)
        folder = QFileDialog.getExistingDirectory(self, "Choose output folder", start)
        if folder:
            self.output_auto_managed = False
            self.output_edit.setText(folder)

    def on_input_changed(self) -> None:
        had_preview = self.preview_has_run
        input_text = self.input_edit.text().strip()
        if input_text and (self.output_auto_managed or not self.output_edit.text().strip()):
            self.update_default_output_folder()
        self.preview_has_run = False
        self.preview_rows = []
        self.preview_candidate_rows = []
        self.preview_candidate_signature = None
        self.preview_rows_signature = None
        self.preview_errors = []
        self.preview_file_count = 0
        self.apply_preview_search()
        self.convert_button.setEnabled(False)
        if self.current_input_dir_if_valid() is not None:
            self.refresh_filter_limit_ranges()
        if had_preview and self.current_input_dir_if_valid() is not None:
            self.preview()

    def set_busy(self, busy: bool) -> None:
        self.filters_toggle.setEnabled(not busy)
        self.column_view_combo.setEnabled(not busy)
        self.columns_button.setEnabled(not busy)
        self.charset_preview_button.setEnabled(not busy)
        self.token_audit_button.setEnabled(not busy)
        self.token_coverage_toggle.setEnabled(not busy)
        self.preview_button.setEnabled(not busy)
        self.direction_combo.setEnabled(not busy)
        self.space_mode_combo.setEnabled(not busy)
        latex_options_enabled = self.conversion_direction == OUTPUT_CONVENTION_LATEX
        self.existing_latex_combo.setEnabled((not busy) and latex_options_enabled)
        self.escape_specials_check.setEnabled((not busy) and latex_options_enabled)
        self.frequency_filter_check.setEnabled(not busy)
        freq_enabled = self.frequency_filter_check.isChecked()
        manual_max = self.frequency_max_mode_combo.currentText() == MAX_PER_LABEL_MODE_MANUAL
        self.frequency_min_spin.setEnabled((not busy) and freq_enabled)
        self.frequency_max_mode_combo.setEnabled((not busy) and freq_enabled)
        self.frequency_max_spin.setVisible(manual_max)
        self.frequency_max_spin.setEnabled((not busy) and freq_enabled and manual_max)
        self.length_filter_check.setEnabled(not busy)
        self.length_min_spin.setEnabled((not busy) and self.length_filter_check.isChecked())
        self.length_max_spin.setEnabled((not busy) and self.length_filter_check.isChecked())
        self.unique_filter_check.setEnabled(not busy)
        self.unique_min_spin.setEnabled((not busy) and self.unique_filter_check.isChecked())
        self.unique_max_spin.setEnabled((not busy) and self.unique_filter_check.isChecked())
        self.token_coverage_unit_combo.setEnabled(not busy)
        self.token_exclude_low_count_check.setEnabled(not busy)
        self.token_exclude_low_count_spin.setEnabled((not busy) and self.token_exclude_low_count_check.isChecked())
        self.token_prefer_rare_check.setEnabled(not busy)
        self.charset_filter_check.setEnabled(not busy)
        self.charset_filter_path_edit.setEnabled((not busy) and self.charset_filter_check.isChecked())
        self.charset_filter_browse_button.setEnabled(not busy)
        self.charset_filter_note_label.setEnabled(not busy)
        self.token_occurrence_toggle.setEnabled(not busy)
        occurrence_enabled = self.token_occurrence_balance_check.isChecked()
        occurrence_manual = self.token_occurrence_target_mode_combo.currentText() == MAX_PER_LABEL_MODE_MANUAL
        self.token_occurrence_balance_check.setEnabled(not busy)
        self.token_occurrence_target_mode_combo.setEnabled((not busy) and occurrence_enabled)
        self.token_occurrence_target_spin.setVisible(occurrence_manual)
        self.token_occurrence_target_spin.setEnabled((not busy) and occurrence_enabled and occurrence_manual)
        self.token_occurrence_min_target_spin.setEnabled((not busy) and occurrence_enabled)
        self.token_occurrence_mode_combo.setEnabled((not busy) and occurrence_enabled)
        self.copy_images_check.setEnabled(not busy)
        self.convert_button.setEnabled((not busy) and self.preview_file_count > 0 and len(self.preview_rows) > 0)

    def validate_input_dir(self) -> Path | None:
        text = self.input_edit.text().strip()
        if not text:
            QMessageBox.warning(self, APP_TITLE, "Choose an input folder first.")
            return None
        path = Path(text).expanduser()
        if not path.is_dir():
            QMessageBox.warning(self, APP_TITLE, f"Input folder does not exist:\n{path}")
            return None
        return path

    def validate_output_dir(self) -> Path | None:
        text = self.output_edit.text().strip()
        if not text:
            QMessageBox.warning(self, APP_TITLE, "Choose an output folder first.")
            return None
        return Path(text).expanduser()

    def preview(self, _checked: bool = False, *, refresh_limits: bool = True) -> None:
        input_dir = self.validate_input_dir()
        if input_dir is None:
            return
        if refresh_limits:
            self.refresh_filter_limit_ranges()
        frequency_options = self.current_frequency_options()
        if frequency_options is None:
            return

        # Keep the old table visible while the new preview is being computed.
        # Clearing first made the window visually jump when users adjusted filters.
        self.progress.setRange(0, 0)
        self.set_status_message("Scanning JSON labels…")
        self.convert_button.setEnabled(False)
        self.preview_rows_signature = None
        self.set_busy(True)

        self.preview_thread = PreviewThread(
            input_dir=input_dir,
            recursive=self.recursive_check.isChecked(),
            space_mode=self.space_mode,
            existing_latex_mode=self.existing_latex_mode,
            escape_literal_specials=self.escape_specials_check.isChecked(),
            conversion_direction=self.conversion_direction,
            frequency_options=frequency_options,
        )
        self.preview_thread.finished_preview.connect(self.on_preview_finished)
        self.preview_thread.start()

    def update_preview_from_cached_candidates(self) -> None:
        """Apply filter/balancing changes to cached rows without rescanning JSON."""
        frequency_options = self.current_frequency_options(show_warning=False)
        if frequency_options is None:
            return
        started_at = time.perf_counter()
        rows = select_rows_with_class_balance(self.preview_candidate_rows, frequency_options)
        elapsed_seconds = time.perf_counter() - started_at
        changed_count = sum(1 for row in rows if row.changed)
        self.preview_rows = rows
        self.preview_rows_signature = self.current_preview_rows_signature()
        self.apply_preview_search()
        self.preview_has_run = True
        self.convert_button.setEnabled(self.preview_file_count > 0 and len(self.preview_rows) > 0)

        freq_summary = format_frequency_filter_summary(frequency_options, self.preview_candidate_rows)
        suffix = f", {freq_summary}" if freq_summary else ""
        self.set_status_message(
            f"Preview: scanned {self.preview_file_count} JSON file(s), showing {len(rows)} label(s){suffix}, "
            f"{changed_count} changed in {format_elapsed_seconds(elapsed_seconds)}."
        )
        self.append_current_token_occurrence_log(frequency_options)

    def on_preview_finished(
        self,
        rows: list[LabelPreview],
        candidate_rows: list[LabelPreview],
        file_count: int,
        label_count: int,
        changed_count: int,
        errors: list[str],
        elapsed_seconds: float,
    ) -> None:
        self.progress.setRange(0, 1)
        self.progress.setValue(1)
        self.preview_candidate_rows = candidate_rows
        self.preview_candidate_signature = self.current_preview_data_signature()
        self.preview_rows_signature = self.current_preview_rows_signature()
        self.preview_errors = list(errors)
        self.preview_file_count = file_count
        self.preview_rows = rows
        self.apply_preview_search()
        self.preview_has_run = True
        self.set_busy(False)
        self.convert_button.setEnabled(file_count > 0 and len(self.preview_rows) > 0)

        freq_summary = format_frequency_filter_summary(self.current_frequency_options(show_warning=False) or FrequencyFilterOptions(False), candidate_rows)
        suffix = f", {freq_summary}" if freq_summary else ""
        msg = f"Preview: scanned {file_count} JSON file(s), showing {label_count} label(s){suffix}, {changed_count} changed in {format_elapsed_seconds(elapsed_seconds)}."
        if errors:
            msg += f"  Errors: {len(errors)}."
            self.show_error_summary("Preview errors", errors)
        self.set_status_message(msg)
        self.append_current_token_occurrence_log(self.current_frequency_options(show_warning=False) or FrequencyFilterOptions(False))

    def populate_table(self, rows: list[LabelPreview]) -> None:
        max_rows = 5000
        shown = rows[:max_rows]
        columns = self.current_table_columns()
        old_v_scroll = self.table.verticalScrollBar().value()
        old_h_scroll = self.table.horizontalScrollBar().value()

        self.table.setUpdatesEnabled(False)
        try:
            self.table.setSortingEnabled(False)
            self.table.clear()
            self.table.setColumnCount(len(columns))
            self.table.setHorizontalHeaderLabels([title for _key, title in columns])
            self.table.setRowCount(len(shown))

            base = self.current_input_dir_if_valid() or Path.cwd()
            for row_idx, item in enumerate(shown):
                try:
                    rel_file = str(item.file_path.relative_to(base))
                except ValueError:
                    rel_file = str(item.file_path)

                status = self.preview_row_status_text(item)

                values_by_key: dict[str, str] = {
                    "file": rel_file,
                    "label_path": item.label_path,
                    "before": item.before,
                    "after": item.after,
                    "status": status,
                    "label_frequency": str(item.label_frequency),
                    "before_raw_length": str(item.before_raw_length),
                    "after_raw_length": str(item.after_raw_length),
                    "after_token_length": str(item.after_token_length),
                    "token_length_delta": str(item.token_length_delta),
                    "unique_after_tokens": str(item.unique_after_tokens),
                    "label_stats": item.label_stats,
                }
                sort_values_by_key: dict[str, object] = {
                    "file": natural_sort_key(rel_file),
                    "label_path": natural_sort_key(item.label_path),
                    "before": natural_sort_key(item.before),
                    "after": natural_sort_key(item.after),
                    "status": natural_sort_key(status),
                    "label_frequency": item.label_frequency,
                    "before_raw_length": item.before_raw_length,
                    "after_raw_length": item.after_raw_length,
                    "after_token_length": item.after_token_length,
                    "token_length_delta": item.token_length_delta,
                    "unique_after_tokens": item.unique_after_tokens,
                    "label_stats": label_stats_sort_key(item.label_stats),
                }
                for col, (key, _title) in enumerate(columns):
                    table_item = SortableTableWidgetItem(
                        values_by_key.get(key, ""),
                        sort_values_by_key.get(key),
                    )
                    if key in NUMERIC_COLUMN_KEYS:
                        table_item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                    self.table.setItem(row_idx, col, table_item)

            self.apply_default_column_widths(columns)
            self.table.setSortingEnabled(True)
            self.table.verticalScrollBar().setValue(min(old_v_scroll, self.table.verticalScrollBar().maximum()))
            self.table.horizontalScrollBar().setValue(min(old_h_scroll, self.table.horizontalScrollBar().maximum()))
        finally:
            self.table.setUpdatesEnabled(True)

        if len(rows) > max_rows:
            self.preview_search_count_label.setText(
                f"Showing first {max_rows} of {len(rows)} matching preview rows. Export unaffected."
            )

    def apply_default_column_widths(self, columns: list[tuple[str, str]]) -> None:
        base_widths = {
            "file": 160,
            "label_path": 260,
            "before": 260,
            "after": 280,
            "status": 190,
            "label_frequency": 90,
            "before_raw_length": 115,
            "after_raw_length": 105,
            "after_token_length": 95,
            "token_length_delta": 75,
            "unique_after_tokens": 105,
            "label_stats": 340,
        }
        widths = [base_widths.get(key, 120) for key, _title in columns]

        # Avoid the initial blank area to the right of the base columns. Keep
        # columns interactive/resizable, but distribute spare viewport width to
        # useful text columns when the default widths would otherwise leave a gap.
        viewport_width = max(0, self.table.viewport().width() - 4)
        extra = viewport_width - sum(widths)
        if extra > 0 and widths:
            preferred_keys = ["before", "after"]
            stretch_cols = [idx for idx, (key, _title) in enumerate(columns) if key in preferred_keys]
            if not stretch_cols:
                stretch_cols = list(range(len(widths)))
            per_col, remainder = divmod(extra, len(stretch_cols))
            for order, col in enumerate(stretch_cols):
                widths[col] += per_col + (1 if order < remainder else 0)

        for col, width in enumerate(widths):
            self.table.setColumnWidth(col, width)

    def convert(self) -> None:
        input_dir = self.validate_input_dir()
        output_dir = self.validate_output_dir()
        if input_dir is None or output_dir is None:
            return
        self.refresh_filter_limit_ranges()
        frequency_options = self.current_frequency_options()
        if frequency_options is None:
            return

        suffix = self.suffix_edit.text().strip()
        if output_dir.resolve() == input_dir.resolve() and not suffix:
            QMessageBox.warning(
                self,
                APP_TITLE,
                "The output folder is the same as the input folder. Add a filename suffix, such as _latex, or choose a different output folder.",
            )
            return

        self.progress.setRange(0, 1)
        self.progress.setValue(0)
        self.set_status_message("Converting JSON files…")
        self.set_busy(True)

        self.convert_thread = ConvertThread(
            input_dir=input_dir,
            output_dir=output_dir,
            recursive=self.recursive_check.isChecked(),
            suffix=suffix,
            space_mode=self.space_mode,
            existing_latex_mode=self.existing_latex_mode,
            escape_literal_specials=self.escape_specials_check.isChecked(),
            copy_images=self.copy_images_check.isChecked(),
            conversion_direction=self.conversion_direction,
            frequency_options=frequency_options,
        )
        self.convert_thread.progress.connect(self.on_convert_progress)
        self.convert_thread.finished_convert.connect(self.on_convert_finished)
        self.convert_thread.start()

    def on_convert_progress(self, current: int, total: int) -> None:
        self.progress.setRange(0, max(total, 1))
        self.progress.setValue(current)

    def on_convert_finished(self, files_written: int, labels_changed: int, images_copied: int, errors: list[str], elapsed_seconds: float) -> None:
        self.set_busy(False)
        self.set_status_message(
            f"Done in {format_elapsed_seconds(elapsed_seconds)}: wrote {files_written} JSON file(s), "
            f"changed {labels_changed} label(s), copied {images_copied} image file(s)."
        )
        if errors:
            self.show_error_summary("Convert errors", errors)

    def show_error_summary(self, title: str, errors: list[str]) -> None:
        preview = "\n".join(errors[:12])
        if len(errors) > 12:
            preview += f"\n… and {len(errors) - 12} more"
        QMessageBox.warning(self, title, preview)

def main() -> int:
    app = QApplication(sys.argv)
    app.setApplicationName(APP_TITLE)
    win = MainWindow()
    win.show()
    return app.exec()

if __name__ == "__main__":
    raise SystemExit(main())
