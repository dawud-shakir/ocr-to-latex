#!/usr/bin/env python3
"""
inspect_crops_craft_curator.py

Small standalone PyQt6 app for curating word/crop labels for OCR training.

Workflow
--------
1. Open an image.
2. EasyOCR/CRAFT loads through craft_worker_process_v1.py in a separate helper process when the app starts.
3. After an image is loaded, CRAFT detection runs automatically in the helper process.
4. Keep/drop/edit/label detected crop rectangles.
5. Export a minimal JSON file.
6. Rotate a selected bounding box by holding Meta (Command on macOS) or Control and dragging left/right.

    {
      "image": "image.png",
      "crops": [
        {
          "index": 1,
          "label": "text",
          "points": [[x1, y1], [x2, y2], [x3, y3], [x4, y4]]
        }
      ]
    }

Notes
-----
- EasyOCR is used for CRAFT detection only: detector=True, recognizer=False.
- No OCR recognition is run.
- JSON import/export supports only the minimal format above.


I see the thumbnail function is still doing an axis-aligned crop from the polygon’s bounding rectangle. I’m replacing that with a perspective/warped crop so the selected slanted quadrilateral is flattened horizontally for the thumbnail.

Update:
Rotated/slanted boxes now use a perspective warp instead of a plain bounding-rectangle crop.
A slanted formula inside a slanted bbox should now appear horizontal/deskewed in the thumbnail.
Added a fallback to the old axis-aligned crop if the warp fails.
Also fixed JSON import so rotated "points" are preserved instead of being converted back into an axis-aligned rectangle.
Install
-------
    python -m pip install PyQt6 easyocr opencv-python numpy

Run
---
    python inspect_crops_craft_curator_rotate_shift_v21_thumbnail_friendly_copy.py
"""

from __future__ import annotations

import importlib.util
import json
import math
import os
import sys
import time
import traceback
import numpy as np
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from PyQt6.QtCore import (
    QEvent,
    QObject,
    QPoint,
    QPointF,
    QRect,
    QRectF,
    QSize,
    Qt,
    QProcess,
    QThread,
    QTimer,
    pyqtSignal,
)
from PyQt6.QtGui import QAction, QColor, QImage, QKeySequence, QPainter, QPen, QPixmap, QPolygonF
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QFileDialog,
    QFrame,
    QGraphicsItem,
    QGraphicsPixmapItem,
    QGraphicsPolygonItem,
    QGraphicsScene,
    QGraphicsView,
    QGridLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSizePolicy,
    QSplitter,
    QVBoxLayout,
    QWidget,
)

from inspector.crop_label_table_v11_script_cycle_skip_missing import CropTableController, LabelLineEdit

try:
    from inspector.SymbolPopup_v9_focus_restore import SymbolPopup
except Exception:
    SymbolPopup = None  # type: ignore[assignment]

try:
    from PyQt6 import sip as _pyqt_sip  # type: ignore
except Exception:
    _pyqt_sip = None  # type: ignore[assignment]


def qt_object_is_deleted(obj: object | None) -> bool:
    if obj is None:
        return True
    if _pyqt_sip is not None:
        try:
            return bool(_pyqt_sip.isdeleted(obj))
        except Exception:
            pass
    try:
        obj.objectName()  # type: ignore[attr-defined]
        return False
    except RuntimeError:
        return True
    except Exception:
        return False

IMAGE_SUFFIXES = {".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff", ".webp"}
PARSEQ_BATCH_SIZE = 32
PARSEQ_DEBUG_TOP_K = 6
PARSEQ_DEBUG_MAX_POSITIONS = 3
PARSEQ_DEBUG_MAX_WATCH_TOKENS = 12

DEFAULT_PARSEQ_REPO = Path("/Users/macintosh/UNM/Demos/ocr-to-latex/code/parseq/")
DEFAULT_CHECKPOINT_PATH = Path(
    "/Users/macintosh/Library/CloudStorage/GoogleDrive-dsshakir@gmail.com/My Drive/Parseq/Training/"
    "total occurances_5_41/runs/2026-05-29_04-32-58/checkpoints/last.ckpt"
)
DEFAULT_PARSEQ_CHECKPOINT_PATH = DEFAULT_CHECKPOINT_PATH
CRAFT_WORKER_MODULE = "inspector.craft_worker_process_v1"


# ---------------------------------------------------------------------------
# PARSeq import / prediction helpers
# ---------------------------------------------------------------------------


def _looks_like_parseq_repo(path: Path) -> bool:
    """Return True when path looks like the PARSeq repo root."""
    path = path.expanduser()
    return (path / "strhub").is_dir() and (path / "strhub" / "models").is_dir()


def _parseq_candidate_roots(path_like: object) -> list[Path]:
    """Return plausible PARSeq repo roots from a file/folder anchor."""
    if not path_like:
        return []
    try:
        p = Path(str(path_like)).expanduser()
    except Exception:
        return []

    candidates: list[Path] = []

    def add(q: Path) -> None:
        q = q.expanduser()
        if q not in candidates:
            candidates.append(q)

    # User may accidentally choose the strhub package folder itself.
    if p.name == "strhub":
        add(p.parent)

    anchors = list(p.parents) if p.suffix and not p.is_dir() else [p] + list(p.parents)
    for anchor in anchors[:8]:
        add(anchor)
        add(anchor / "parseq")
        add(anchor / "PARSeq")
        add(anchor / "baudm_parseq")
    return candidates


def find_parseq_repo(*anchors: object) -> Optional[Path]:
    """Find a local PARSeq repo folder that contains the strhub package."""
    all_candidates: list[Path] = []

    def extend(items: list[Path]) -> None:
        for item in items:
            if item not in all_candidates:
                all_candidates.append(item)

    extend(_parseq_candidate_roots(os.environ.get("PARSEQ_REPO", "")))
    extend(_parseq_candidate_roots(DEFAULT_PARSEQ_REPO))
    extend(_parseq_candidate_roots(Path.cwd()))
    extend(_parseq_candidate_roots(Path(__file__).resolve().parent))
    for anchor in anchors:
        extend(_parseq_candidate_roots(anchor))

    for cand in all_candidates:
        try:
            if _looks_like_parseq_repo(cand):
                return cand.resolve()
        except Exception:
            continue
    return None


def _path_is_relative_to(path: Path, parent: Path) -> bool:
    """Compatibility helper for checking whether path is inside parent."""
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def _purge_imported_strhub_if_not_from(repo: Path) -> None:
    """Remove already-imported strhub modules if they came from another repo/install.

    This matters for hybrid-tokenizer checkpoints. If an older installed `strhub`
    wins before the patched PARSeq repo, Lightning may not know how to rebuild
    HybridLatexTokenizer from the checkpoint.
    """
    loaded = sys.modules.get("strhub")
    if loaded is None:
        return
    loaded_file = getattr(loaded, "__file__", None)
    if not loaded_file:
        return
    try:
        loaded_path = Path(str(loaded_file)).resolve()
    except Exception:
        return
    if _path_is_relative_to(loaded_path, repo):
        return

    for name in list(sys.modules):
        if name == "strhub" or name.startswith("strhub."):
            sys.modules.pop(name, None)


def _imported_strhub_path() -> str:
    """Return the filesystem location of the currently imported/importable strhub."""
    loaded = sys.modules.get("strhub")
    loaded_file = getattr(loaded, "__file__", None) if loaded is not None else None
    if loaded_file:
        return str(loaded_file)
    spec = importlib.util.find_spec("strhub")
    origin = getattr(spec, "origin", None) if spec is not None else None
    return str(origin) if origin else "not found"


def ensure_parseq_importable(*anchors: object) -> Optional[Path]:
    """Make the intended PARSeq repo import first. Returns the repo if found/added.

    PARSEQ_REPO has priority even if another `strhub` is already importable.
    This avoids accidentally loading an older/unpatched PARSeq install when a
    checkpoint was trained with the hybrid LaTeX tokenizer.
    """
    repo: Optional[Path] = None

    # Highest priority: explicit PARSEQ_REPO.
    for cand in _parseq_candidate_roots(os.environ.get("PARSEQ_REPO", "")):
        try:
            if _looks_like_parseq_repo(cand):
                repo = cand.resolve()
                break
        except Exception:
            continue

    # Fallback: infer from cwd, this script, checkpoint path, etc.
    if repo is None:
        repo = find_parseq_repo(*anchors)

    if repo is not None:
        repo_str = str(repo)
        # Put the chosen repo at the absolute front, even if it was already
        # present later in sys.path.
        sys.path[:] = [p for p in sys.path if p != repo_str]
        sys.path.insert(0, repo_str)
        _purge_imported_strhub_if_not_from(repo)
        return repo

    # No local repo found. Fall back to whatever the environment can import.
    if importlib.util.find_spec("strhub") is not None:
        return None
    return None


def choose_parseq_device():
    """Choose the fastest available torch device for PARSeq inference."""
    import torch

    if torch.cuda.is_available():
        return torch.device("cuda")
    if hasattr(torch.backends, "mps") and torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")


def get_model_img_size(model: Any) -> tuple[int, int]:
    """Best-effort PARSeq input size lookup."""
    candidates: list[Any] = []
    for obj in (model, getattr(model, "model", None), getattr(model, "hparams", None)):
        if obj is None:
            continue
        for attr in ("img_size", "image_size"):
            value = getattr(obj, attr, None)
            if value is not None:
                candidates.append(value)
    hp = getattr(model, "hparams", None)
    if hp is not None:
        for key in ("img_size", "image_size"):
            try:
                value = hp[key]
            except Exception:
                value = None
            if value is not None:
                candidates.append(value)

    for value in candidates:
        if isinstance(value, int):
            return (int(value), int(value))
        if isinstance(value, (list, tuple)) and len(value) == 2:
            return (int(value[0]), int(value[1]))
    return (32, 128)  # Common PARSeq default: height 32, width 128.


def parseq_decode_texts(model: Any, probs: Any) -> list[str]:
    """Decode PARSeq probability tensors into strings with a simple fallback."""
    tokenizer = getattr(model, "tokenizer", None)
    if tokenizer is not None and hasattr(tokenizer, "decode"):
        try:
            decoded = tokenizer.decode(probs)
            texts = decoded[0] if isinstance(decoded, tuple) else decoded
            if isinstance(texts, str):
                return [texts]
            return [str(x) for x in texts]
        except Exception:
            pass

    token_rows = parseq_token_rows_from_probs(model, probs)
    return ["".join(tokens) for tokens in token_rows]


def parseq_token_rows_from_probs(model: Any, probs: Any) -> list[list[str]]:
    """Return greedy PARSeq token rows for debugging hybrid-token predictions.

    This intentionally shows the actual decoded token pieces, so a hybrid model
    can be checked for ['\\theta'] versus ['t', 'h', 'e', 't', 'a'].
    """
    tokenizer = getattr(model, "tokenizer", None)
    pred_ids = probs.argmax(dim=-1).detach().cpu().tolist()
    id_to_token = _parseq_id_to_token(tokenizer)
    out: list[list[str]] = []
    for row in pred_ids:
        tokens: list[str] = []
        for idx in row:
            token = id_to_token.get(int(idx), f"<id:{int(idx)}>")
            if token in ("<eos>", "[E]", "<pad>", "[P]"):
                break
            if token not in ("<bos>", "[B]"):
                tokens.append(token)
        out.append(tokens)
    return out


def format_parseq_token_row(tokens: list[str]) -> str:
    """Compact display format for raw PARSeq token rows."""
    return " ".join(f"[{token}]" for token in tokens) if tokens else "[]"


def _parseq_token_to_id(tokenizer: Any) -> dict[str, int]:
    """Best-effort token-to-id map for debug probability lookups."""
    mapping: dict[str, int] = {}
    if tokenizer is None:
        return mapping

    for attr in ("_stoi", "stoi", "token_to_id"):
        obj = getattr(tokenizer, attr, None)
        if isinstance(obj, dict):
            for token, idx in obj.items():
                try:
                    token_text = str(token)
                    mapping[token_text] = int(idx)
                    mapping[_normalize_parseq_token(token_text)] = int(idx)
                except Exception:
                    pass

    # Fallback: reverse the id-to-token map.
    for idx, token in _parseq_id_to_token(tokenizer).items():
        mapping.setdefault(str(token), int(idx))
    return mapping


def parseq_topk_debug_rows_from_probs(
    model: Any,
    probs: Any,
    *,
    top_k: int = PARSEQ_DEBUG_TOP_K,
    max_positions: int = PARSEQ_DEBUG_MAX_POSITIONS,
) -> list[str]:
    """Return top-k token probability summaries for each sample.

    This is hybrid-token aware: probability indices are mapped through the
    tokenizer vocabulary, so a single class such as '\\theta' is displayed as
    [\\theta] rather than being interpreted as several characters.
    """
    tokenizer = getattr(model, "tokenizer", None)
    id_to_token = _parseq_id_to_token(tokenizer)
    token_to_id = _parseq_token_to_id(tokenizer)

    latex_tokens = getattr(tokenizer, "latex_tokens", None)
    watch_tokens: list[str] = []
    if latex_tokens is not None:
        try:
            watch_tokens = [str(t) for t in list(latex_tokens)[:PARSEQ_DEBUG_MAX_WATCH_TOKENS]]
        except Exception:
            watch_tokens = []

    arr = probs.detach().float().cpu()
    out: list[str] = []
    for sample in arr:
        sample_parts: list[str] = []
        num_positions = min(int(max_positions), int(sample.shape[0]))
        num_classes = int(sample.shape[-1]) if sample.ndim == 2 else 0
        k = min(max(1, int(top_k)), max(1, num_classes))

        for pos in range(num_positions):
            vals, ids = sample[pos].topk(k)
            items: list[str] = []
            for prob, idx in zip(vals.tolist(), ids.tolist()):
                token = id_to_token.get(int(idx), f"<id:{int(idx)}>")
                items.append(f"[{token}]={float(prob):.3f}")
            sample_parts.append(f"pos{pos + 1} top{k}: " + ", ".join(items))

        # Directly report position-1 probability for each known hybrid token.
        # This answers questions like: was \theta considered, and how close was it?
        watched: list[str] = []
        if num_classes and int(sample.shape[0]) > 0:
            for token in watch_tokens:
                token_id = token_to_id.get(token)
                if token_id is None:
                    continue
                # PARSeq does not predict BOS/PAD. Their ids may be outside the
                # output probability vector, so skip ids not present in probs.
                if 0 <= int(token_id) < num_classes:
                    watched.append(f"[{token}]@pos1={float(sample[0, int(token_id)]):.3f}")
        if watched:
            sample_parts.append("watch: " + ", ".join(watched))

        out.append("\n".join(sample_parts))
    return out


def _parseq_id_to_token(tokenizer: Any) -> dict[int, str]:
    mapping: dict[int, str] = {}
    if tokenizer is None:
        return mapping
    for attr in ("_itos", "itos", "id_to_token", "idx_to_token"):
        obj = getattr(tokenizer, attr, None)
        if isinstance(obj, dict):
            for k, v in obj.items():
                try:
                    mapping[int(k)] = _normalize_parseq_token(v)
                except Exception:
                    pass
        elif isinstance(obj, (list, tuple)):
            for i, v in enumerate(obj):
                mapping[i] = _normalize_parseq_token(v)
    for attr in ("_stoi", "stoi", "token_to_id"):
        obj = getattr(tokenizer, attr, None)
        if isinstance(obj, dict):
            for token, idx in obj.items():
                try:
                    mapping[int(idx)] = _normalize_parseq_token(token)
                except Exception:
                    pass
    return mapping


def _normalize_parseq_token(token: Any) -> str:
    text = str(token)
    return {
        "[B]": "<bos>",
        "<BOS>": "<bos>",
        "[E]": "<eos>",
        "<EOS>": "<eos>",
        "[P]": "<pad>",
        "<PAD>": "<pad>",
    }.get(text, text)


def parseq_confidence_mean(conf: Any) -> float:
    """Mean character confidence for status/reporting only."""
    if conf is None:
        return float("nan")
    try:
        if hasattr(conf, "detach"):
            vals = conf.detach().float().cpu().reshape(-1).tolist()
        elif isinstance(conf, (list, tuple)):
            vals = [float(x) for x in conf]
        else:
            vals = [float(conf)]
        vals = [float(v) for v in vals if not math.isnan(float(v))]
        return sum(vals) / len(vals) if vals else float("nan")
    except Exception:
        return float("nan")




def describe_parseq_tokenizer(model: Any) -> str:
    """Return a concise tokenizer/debug summary for PARSeq inference."""
    tokenizer = getattr(model, "tokenizer", None)
    if tokenizer is None:
        return "tokenizer=none"

    tokenizer_name = type(tokenizer).__name__
    try:
        vocab_size = len(tokenizer)
    except Exception:
        vocab_size = "?"

    latex_tokens = getattr(tokenizer, "latex_tokens", None)
    latex_token_count = 0
    latex_token_preview = ""
    if latex_tokens is not None:
        try:
            latex_token_list = [str(x) for x in list(latex_tokens)]
            latex_token_count = len(latex_token_list)
            if latex_token_list:
                latex_token_preview = ", tokens=" + repr(latex_token_list[:12])
                if len(latex_token_list) > 12:
                    latex_token_preview += "..."
        except Exception:
            latex_token_count = -1

    hparams = getattr(model, "hparams", None)
    tokenizer_type = None
    if hparams is not None:
        try:
            tokenizer_type = hparams.get("tokenizer_type", None)
        except Exception:
            try:
                tokenizer_type = getattr(hparams, "tokenizer_type", None)
            except Exception:
                tokenizer_type = None

    pieces = [f"tokenizer={tokenizer_name}", f"vocab={vocab_size}"]
    if tokenizer_type is not None:
        pieces.append(f"tokenizer_type={tokenizer_type}")
    if latex_tokens is not None:
        pieces.append(f"latex_tokens={latex_token_count}{latex_token_preview}")
    return ", ".join(pieces)


def warn_if_hybrid_checkpoint_looks_unpatched(model: Any) -> Optional[str]:
    """Return a warning if hparams suggest latex_hybrid but tokenizer is not hybrid."""
    hparams = getattr(model, "hparams", None)
    tokenizer_type = None
    if hparams is not None:
        try:
            tokenizer_type = hparams.get("tokenizer_type", None)
        except Exception:
            tokenizer_type = getattr(hparams, "tokenizer_type", None)

    tokenizer = getattr(model, "tokenizer", None)
    tokenizer_name = type(tokenizer).__name__ if tokenizer is not None else "none"
    if str(tokenizer_type) == "latex_hybrid" and "Hybrid" not in tokenizer_name:
        return (
            "Checkpoint hparams say tokenizer_type=latex_hybrid, but the loaded "
            f"tokenizer is {tokenizer_name}. Make sure PARSEQ_REPO points to the "
            "patched PARSeq repo that contains strhub/data/latex_tokenizer.py."
        )
    return None

def load_parseq_model_for_inference(checkpoint_path: Path, device: Any) -> tuple[Any, Any, Any]:
    """Load a PARSeq checkpoint without relying on strhub's filename inference.

    strhub.models.utils.load_from_checkpoint tries to infer the model class from
    the checkpoint path/name. That fails for normal absolute checkpoint names like
    epoch=198-step=4179-...ckpt, so load the concrete PARSeq LightningModule.
    """
    repo = ensure_parseq_importable(checkpoint_path)
    try:
        from strhub.models.parseq.system import PARSeq
        from strhub.data.module import SceneTextDataModule
    except ModuleNotFoundError as exc:
        if getattr(exc, "name", "") == "strhub":
            searched = find_parseq_repo(checkpoint_path)
            raise RuntimeError(
                "Could not import PARSeq's `strhub` package.\n\n"
                "Fix options:\n"
                "  1. Run this script from inside/near the PARSeq repo, or\n"
                "  2. Set PARSEQ_REPO=/path/to/parseq before launching, or\n"
                "  3. Install PARSeq into this environment:\n"
                "       cd /path/to/parseq\n"
                "       python -m pip install -e .\n\n"
                f"Auto-detected repo: {repo or searched or 'none'}"
            ) from exc
        raise
    except Exception as exc:
        raise RuntimeError(
            "PARSeq/strhub was found, but importing PARSeq failed. "
            "Check that this Python environment has the same dependencies used for training.\n\n"
            f"PARSeq repo added: {repo or 'already importable'}"
        ) from exc

    model = PARSeq.load_from_checkpoint(str(checkpoint_path.expanduser().resolve()))
    model = model.eval().to(device)

    tokenizer_summary = describe_parseq_tokenizer(model)
    repo_summary = str(repo) if repo is not None else f"already importable ({_imported_strhub_path()})"
    warning = warn_if_hybrid_checkpoint_looks_unpatched(model)
    model._parseq_inference_summary = tokenizer_summary  # type: ignore[attr-defined]
    model._parseq_repo_summary = repo_summary  # type: ignore[attr-defined]
    if warning:
        model._parseq_inference_warning = warning  # type: ignore[attr-defined]
    print(f"PARSeq repo/import source: {repo_summary}", flush=True)
    print(f"PARSeq tokenizer: {tokenizer_summary}", flush=True)
    if warning:
        print(f"PARSeq tokenizer warning: {warning}", flush=True)

    img_size = get_model_img_size(model)
    try:
        transform = SceneTextDataModule.get_transform(img_size)
    except Exception:
        from torchvision import transforms
        transform = transforms.Compose([
            transforms.Resize(img_size),
            transforms.ToTensor(),
            transforms.Normalize([0.5, 0.5, 0.5], [0.5, 0.5, 0.5]),
        ])
    return model, transform, img_size


@dataclass
class ParseqCropJob:
    row: int
    index: int
    points: list[list[float]]
    label: str
    keep: bool


@dataclass
class ParseqModelBundle:
    checkpoint_path: Path
    device: Any
    model: Any
    transform: Any
    img_size: tuple[int, int]
    repo_summary: str = ""
    tokenizer_summary: str = ""
    tokenizer_warning: str = ""


class ParseqLoadWorker(QThread):
    progress = pyqtSignal(int, str)
    loaded = pyqtSignal(int, object)
    failed = pyqtSignal(int, str)
    load_finished = pyqtSignal(int)

    def __init__(self, checkpoint_path: Path, generation: int) -> None:
        super().__init__()
        self.checkpoint_path = checkpoint_path.expanduser().resolve()
        self.generation = int(generation)

    def run(self) -> None:  # pragma: no cover - GUI worker thread
        try:
            device = choose_parseq_device()
            ckpt_full = str(self.checkpoint_path)
            self.progress.emit(self.generation, f"PARSeq: loading {ckpt_full} on {device}")
            print(f"PARSeq checkpoint: {ckpt_full}", flush=True)
            t0 = time.perf_counter()
            model, transform, img_size = load_parseq_model_for_inference(self.checkpoint_path, device)
            repo_summary = str(getattr(model, "_parseq_repo_summary", ""))
            tokenizer_summary = str(getattr(model, "_parseq_inference_summary", ""))
            tokenizer_warning = str(getattr(model, "_parseq_inference_warning", ""))
            bundle = ParseqModelBundle(
                checkpoint_path=self.checkpoint_path,
                device=device,
                model=model,
                transform=transform,
                img_size=img_size,
                repo_summary=repo_summary,
                tokenizer_summary=tokenizer_summary,
                tokenizer_warning=tokenizer_warning,
            )
            self.progress.emit(self.generation, f"PARSeq: model loaded in {time.perf_counter() - t0:.1f}s")
            self.loaded.emit(self.generation, bundle)
        except Exception:
            self.failed.emit(self.generation, traceback.format_exc())
        finally:
            self.load_finished.emit(self.generation)


class ParseqPredictWorker(QThread):
    progress = pyqtSignal(str, int, int)
    prediction_ready = pyqtSignal(int, str, float)
    token_debug_ready = pyqtSignal(int, int, str, str, float)
    topk_debug_ready = pyqtSignal(int, int, str)
    failed = pyqtSignal(str)
    fill_finished = pyqtSignal(int, int, bool)

    def __init__(
        self,
        bundle: ParseqModelBundle,
        source_rgb: np.ndarray,
        jobs: list[ParseqCropJob],
        *,
        overwrite_labels: bool,
        batch_size: int = PARSEQ_BATCH_SIZE,
        debug_tokens: bool = False,
    ) -> None:
        super().__init__()
        self.bundle = bundle
        self.source_rgb = np.ascontiguousarray(source_rgb, dtype=np.uint8)
        self.jobs = jobs
        self.overwrite_labels = bool(overwrite_labels)
        self.batch_size = max(1, int(batch_size))
        self.debug_tokens = bool(debug_tokens)
        self._cancel = False

    def cancel(self) -> None:
        self._cancel = True

    def run(self) -> None:  # pragma: no cover - GUI worker thread
        updated = 0
        total = 0
        cancelled = False
        try:
            import torch
            from PIL import Image

            jobs = [
                job for job in self.jobs
                if job.keep and (self.overwrite_labels or not job.label.strip())
            ]
            total = len(jobs)
            if not jobs:
                self.progress.emit("PARSeq: no blank kept labels to fill", 0, 0)
                return

            model = self.bundle.model
            transform = self.bundle.transform
            device = self.bundle.device
            try:
                model.eval()
            except Exception:
                pass

            ckpt_name = self.bundle.checkpoint_path.name
            self.progress.emit(f"PARSeq: predicting with {ckpt_name}", 0, total)

            done = 0
            with torch.inference_mode():
                for start in range(0, total, self.batch_size):
                    if self._cancel:
                        cancelled = True
                        break

                    batch_jobs = jobs[start:start + self.batch_size]
                    pil_images: list[Any] = []
                    valid_jobs: list[ParseqCropJob] = []
                    for job in batch_jobs:
                        if self._cancel:
                            cancelled = True
                            break
                        try:
                            crop = warped_crop_array_rgb(self.source_rgb, job.points)
                            if crop.size == 0:
                                raise ValueError("empty crop")
                            pil_images.append(Image.fromarray(np.ascontiguousarray(crop)).convert("RGB"))
                            valid_jobs.append(job)
                        except Exception as exc:
                            done += 1
                            self.progress.emit(f"PARSeq: skipped crop #{job.index}: {exc}", done, total)
                    if cancelled:
                        break
                    if not pil_images:
                        continue

                    x = torch.stack([transform(im) for im in pil_images], dim=0).to(device, non_blocking=True)
                    logits = model(x)
                    probs = logits.softmax(dim=-1)
                    pred_texts = parseq_decode_texts(model, probs)
                    pred_token_rows = parseq_token_rows_from_probs(model, probs) if self.debug_tokens else []
                    pred_topk_rows = parseq_topk_debug_rows_from_probs(model, probs) if self.debug_tokens else []

                    decoded = None
                    pred_confs = [None] * len(valid_jobs)
                    tokenizer = getattr(model, "tokenizer", None)
                    if tokenizer is not None and hasattr(tokenizer, "decode"):
                        try:
                            decoded = tokenizer.decode(probs)
                        except Exception:
                            decoded = None
                    if isinstance(decoded, tuple) and len(decoded) >= 2:
                        pred_confs = list(decoded[1])

                    for j, job in enumerate(valid_jobs):
                        if self._cancel:
                            cancelled = True
                            break
                        pred = pred_texts[j] if j < len(pred_texts) else ""
                        conf = parseq_confidence_mean(pred_confs[j]) if j < len(pred_confs) else float("nan")
                        if self.debug_tokens:
                            token_row = pred_token_rows[j] if j < len(pred_token_rows) else []
                            self.token_debug_ready.emit(
                                job.row,
                                job.index,
                                str(pred),
                                format_parseq_token_row(token_row),
                                conf,
                            )
                            topk_row = pred_topk_rows[j] if j < len(pred_topk_rows) else ""
                            if topk_row:
                                self.topk_debug_ready.emit(job.row, job.index, topk_row)
                        self.prediction_ready.emit(job.row, str(pred), conf)
                        updated += 1
                        done += 1
                    self.progress.emit(f"PARSeq: filled {done}/{total}", done, total)
                    if cancelled:
                        break

        except Exception:
            self.failed.emit(traceback.format_exc())
        finally:
            self.fill_finished.emit(updated, total, cancelled)


# ---------------------------------------------------------------------------
# Geometry and JSON helpers
# ---------------------------------------------------------------------------


def clamp(value: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, value))


def clean_points(points: Any) -> list[list[float]]:
    """Return four [[x, y], ...] points as floats, or raise ValueError."""
    if not isinstance(points, (list, tuple)) or len(points) != 4:
        raise ValueError("points must contain exactly four [x, y] pairs")
    out: list[list[float]] = []
    for p in points:
        if not isinstance(p, (list, tuple)) or len(p) != 2:
            raise ValueError("each point must be [x, y]")
        out.append([float(p[0]), float(p[1])])
    return out


def points_to_rect(points: list[list[float]]) -> QRectF:
    xs = [float(p[0]) for p in points]
    ys = [float(p[1]) for p in points]
    return QRectF(min(xs), min(ys), max(xs) - min(xs), max(ys) - min(ys)).normalized()


def rect_to_points(rect: QRectF) -> list[list[float]]:
    r = rect.normalized()
    return [
        [float(r.left()), float(r.top())],
        [float(r.right()), float(r.top())],
        [float(r.right()), float(r.bottom())],
        [float(r.left()), float(r.bottom())],
    ]


def points_to_export(points: list[list[float]]) -> list[list[int]]:
    return [[int(round(x)), int(round(y))] for x, y in points]


def clamp_rect_to_image(rect: QRectF, image_size: QSize, min_size: float = 2.0) -> QRectF:
    r = rect.normalized()
    w_img = max(1.0, float(image_size.width()))
    h_img = max(1.0, float(image_size.height()))

    x1 = clamp(r.left(), 0.0, w_img)
    y1 = clamp(r.top(), 0.0, h_img)
    x2 = clamp(r.right(), 0.0, w_img)
    y2 = clamp(r.bottom(), 0.0, h_img)

    if x2 - x1 < min_size:
        mid = (x1 + x2) * 0.5
        x1 = clamp(mid - min_size * 0.5, 0.0, w_img - min_size)
        x2 = clamp(x1 + min_size, min_size, w_img)
    if y2 - y1 < min_size:
        mid = (y1 + y2) * 0.5
        y1 = clamp(mid - min_size * 0.5, 0.0, h_img - min_size)
        y2 = clamp(y1 + min_size, min_size, h_img)

    return QRectF(QPointF(x1, y1), QPointF(x2, y2)).normalized()


def qimage_to_numpy_rgb(image: QImage) -> np.ndarray:
    """Return a copied RGB ndarray for a QImage.

    The copy matters because the temporary QImage backing buffer can disappear
    once this helper returns.
    """
    rgb = image.convertToFormat(QImage.Format.Format_RGB888)
    ptr = rgb.bits()
    ptr.setsize(rgb.sizeInBytes())
    arr = np.frombuffer(ptr, dtype=np.uint8).reshape(rgb.height(), rgb.bytesPerLine())
    arr = arr[:, : rgb.width() * 3].reshape(rgb.height(), rgb.width(), 3)
    return arr.copy()


def numpy_rgb_to_qimage(array: np.ndarray) -> QImage:
    """Return a copied RGB888 QImage from an RGB ndarray."""
    arr = np.ascontiguousarray(array, dtype=np.uint8)
    if arr.ndim != 3 or arr.shape[2] != 3:
        raise ValueError("Expected an RGB image array with shape (h, w, 3)")
    h, w = arr.shape[:2]
    return QImage(arr.data, w, h, 3 * w, QImage.Format.Format_RGB888).copy()


def order_quad_points_for_preview(points: Any) -> np.ndarray:
    """Return a stable TL-ish, clockwise 4-point order for preview warping.

    Some detector/free-box points arrive as [tl, bl, br, tr] rather than
    [tl, tr, br, bl]. The thumbnail warp needs a consistent order, otherwise
    the preview can come out vertical or upside down.
    """
    import cv2  # type: ignore

    pts = np.asarray(clean_points(points), dtype=np.float32).reshape(4, 2)
    center = np.mean(pts, axis=0)
    angles = np.arctan2(pts[:, 1] - center[1], pts[:, 0] - center[0])
    ordered = pts[np.argsort(angles)]

    # Match the tightener app's convention: clockwise in image coordinates,
    # then rotate so the top-left-ish corner is first.
    if cv2.contourArea(ordered.astype(np.float32)) > 0:
        ordered = ordered[::-1]

    scores = ordered[:, 0] + ordered[:, 1]
    start = int(np.argmin(scores))
    return np.roll(ordered, -start, axis=0).astype(np.float32)


def warped_crop_qimage(image: QImage, points: list[list[float]]) -> QImage:
    """Perspective-crop a 4-point box and orient the thumbnail horizontally.

    This mirrors the preview-orientation fix from the tightener app: after
    sorting the quadrilateral, keep the top-left-ish point fixed and choose the
    longer adjacent edge as the output's top edge. That handles detector/free
    boxes that arrive as [tl, bl, br, tr] without flipping the crop upside down.
    """
    import cv2  # type: ignore

    pts = order_quad_points_for_preview(points)

    # Keep the TL-ish corner fixed. If the edge to the previous point is longer
    # than the edge to the next point, use that previous edge as the horizontal
    # top edge. For the common bad order [tl, bl, br, tr], this becomes
    # [tl, tr, br, bl].
    # edge_to_next = float(np.linalg.norm(pts[1] - pts[0]))
    # edge_to_prev = float(np.linalg.norm(pts[3] - pts[0]))
    # if edge_to_prev > edge_to_next:
    #     pts = np.array([pts[0], pts[3], pts[2], pts[1]], dtype=np.float32)

    v_next = pts[1] - pts[0]
    v_prev = pts[3] - pts[0]

    next_is_more_horizontal = abs(float(v_next[0])) >= abs(float(v_next[1]))
    prev_is_more_horizontal = abs(float(v_prev[0])) >= abs(float(v_prev[1]))

    # If the "previous" edge is the horizontal one, rotate ordering so it becomes top.
    if prev_is_more_horizontal and not next_is_more_horizontal:
        pts = np.array([pts[0], pts[3], pts[2], pts[1]], dtype=np.float32)
    # Tie-breaker: if both look similarly horizontal/vertical, prefer the one that points right.
    elif abs(abs(float(v_next[0])) - abs(float(v_next[1]))) < 1e-3 and abs(abs(float(v_prev[0])) - abs(float(v_prev[1]))) < 1e-3:
        if float(v_prev[0]) > float(v_next[0]):
            pts = np.array([pts[0], pts[3], pts[2], pts[1]], dtype=np.float32)
    # ...existing code..

    tl, tr, br, bl = pts
    width_top = float(np.linalg.norm(tr - tl))
    width_bottom = float(np.linalg.norm(br - bl))
    height_left = float(np.linalg.norm(bl - tl))
    height_right = float(np.linalg.norm(br - tr))

    out_w = max(1, int(round(max(width_top, width_bottom))))
    out_h = max(1, int(round(max(height_left, height_right))))
    if out_w <= 1 or out_h <= 1:
        return QImage()

    src = qimage_to_numpy_rgb(image)
    dst = np.array(
        [[0, 0], [out_w - 1, 0], [out_w - 1, out_h - 1], [0, out_h - 1]],
        dtype=np.float32,
    )
    matrix = cv2.getPerspectiveTransform(pts.astype(np.float32), dst)
    warped = cv2.warpPerspective(
        src,
        matrix,
        (out_w, out_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )
    return numpy_rgb_to_qimage(warped)


def warped_crop_array_rgb(source_rgb: np.ndarray, points: list[list[float]]) -> np.ndarray:
    """Perspective-crop a 4-point box from an RGB ndarray for PARSeq."""
    import cv2  # type: ignore

    pts = order_quad_points_for_preview(points)
    v_next = pts[1] - pts[0]
    v_prev = pts[3] - pts[0]

    next_is_more_horizontal = abs(float(v_next[0])) >= abs(float(v_next[1]))
    prev_is_more_horizontal = abs(float(v_prev[0])) >= abs(float(v_prev[1]))
    if prev_is_more_horizontal and not next_is_more_horizontal:
        pts = np.array([pts[0], pts[3], pts[2], pts[1]], dtype=np.float32)
    elif abs(abs(float(v_next[0])) - abs(float(v_next[1]))) < 1e-3 and abs(abs(float(v_prev[0])) - abs(float(v_prev[1]))) < 1e-3:
        if float(v_prev[0]) > float(v_next[0]):
            pts = np.array([pts[0], pts[3], pts[2], pts[1]], dtype=np.float32)

    tl, tr, br, bl = pts
    width_top = float(np.linalg.norm(tr - tl))
    width_bottom = float(np.linalg.norm(br - bl))
    height_left = float(np.linalg.norm(bl - tl))
    height_right = float(np.linalg.norm(br - tr))
    out_w = max(1, int(round(max(width_top, width_bottom))))
    out_h = max(1, int(round(max(height_left, height_right))))
    if out_w <= 1 or out_h <= 1:
        return np.zeros((0, 0, 3), dtype=np.uint8)

    dst = np.array(
        [[0, 0], [out_w - 1, 0], [out_w - 1, out_h - 1], [0, out_h - 1]],
        dtype=np.float32,
    )
    matrix = cv2.getPerspectiveTransform(pts.astype(np.float32), dst)
    return cv2.warpPerspective(
        source_rgb,
        matrix,
        (out_w, out_h),
        flags=cv2.INTER_CUBIC,
        borderMode=cv2.BORDER_REPLICATE,
    )


def axis_aligned_crop_qimage(image: QImage, points: list[list[float]]) -> QImage:
    """Fallback crop using the polygon's bounding rectangle."""
    rect = points_to_rect(points)
    x1 = max(0, int(math.floor(rect.left())))
    y1 = max(0, int(math.floor(rect.top())))
    x2 = min(image.width(), int(math.ceil(rect.right())))
    y2 = min(image.height(), int(math.ceil(rect.bottom())))
    if x2 <= x1 or y2 <= y1:
        return QImage()
    return image.copy(QRect(x1, y1, x2 - x1, y2 - y1))


def qimage_crop_pixmap(image: Optional[QImage], points: list[list[float]], max_size: QSize) -> QPixmap:
    """Create a thumbnail for a crop polygon.

    For rotated/skewed boxes, use a perspective warp so the thumbnail shows the
    boxed content horizontally instead of showing the larger axis-aligned
    bounding rectangle around it.
    """
    if image is None or image.isNull():
        return QPixmap()

    try:
        crop = warped_crop_qimage(image, points)
    except Exception:
        # Keep the UI usable even if OpenCV is missing or a malformed polygon
        # slips through. Detection already depends on OpenCV, so this is mostly
        # a safety fallback.
        crop = axis_aligned_crop_qimage(image, points)

    if crop.isNull():
        return QPixmap()

    return QPixmap.fromImage(crop).scaled(
        max_size,
        Qt.AspectRatioMode.KeepAspectRatio,
        Qt.TransformationMode.SmoothTransformation,
    )


def points_array_to_list(points: Any) -> list[list[float]]:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    return [[float(x), float(y)] for x, y in pts.tolist()]


def clamp_points_to_image(points: Any, image_size: QSize) -> list[list[float]]:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2).copy()
    max_x = max(1.0, float(image_size.width()))
    max_y = max(1.0, float(image_size.height()))
    pts[:, 0] = np.clip(pts[:, 0], 0.0, max_x)
    pts[:, 1] = np.clip(pts[:, 1], 0.0, max_y)
    return points_array_to_list(pts)


def qpolygon_to_points(poly: QPolygonF) -> list[list[float]]:
    """Convert a QPolygonF to four [[x, y], ...] point pairs."""
    points: list[list[float]] = []
    try:
        count = int(poly.count())
    except Exception:
        count = len(poly)  # type: ignore[arg-type]
    for i in range(min(4, count)):
        p = poly[i]
        points.append([float(p.x()), float(p.y())])
    if len(points) != 4:
        raise ValueError("polygon must contain exactly four points")
    return points


def points_to_qpolygon(points: Any) -> QPolygonF:
    return QPolygonF([QPointF(float(x), float(y)) for x, y in clean_points(points)])


def polygon_center(points: Any) -> QPointF:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    return QPointF(float(np.mean(pts[:, 0])), float(np.mean(pts[:, 1])))


def translate_points(points: Any, dx: float, dy: float) -> list[list[float]]:
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2).copy()
    pts[:, 0] += float(dx)
    pts[:, 1] += float(dy)
    return points_array_to_list(pts)


def rotate_points_about_center(points: Any, angle_degrees: float) -> list[list[float]]:
    """Rotate polygon points in image/screen coordinates.

    Positive angles are clockwise because image coordinates use y-down.
    """
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    center = np.mean(pts, axis=0)
    rad = math.radians(float(angle_degrees))
    c = math.cos(rad)
    s = math.sin(rad)
    centered = pts - center
    rotated = np.empty_like(centered)
    rotated[:, 0] = centered[:, 0] * c - centered[:, 1] * s
    rotated[:, 1] = centered[:, 0] * s + centered[:, 1] * c
    rotated += center
    return points_array_to_list(rotated)


def resize_points_along_local_axes(points: Any, scene_pos: QPointF, hit: str, min_size: float = 2.0) -> list[list[float]]:
    """Resize a four-point crop in its own rotated coordinate system.

    The stored point order is top-left, top-right, bottom-right, bottom-left.
    Dragging an edge changes only that edge's local x or y coordinate, so a
    rotated box stays rotated instead of snapping back to an image-aligned rect.
    """
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2)
    p0, p1, _p2, p3 = pts

    width_vec = p1 - p0
    height_vec = p3 - p0
    width = float(np.linalg.norm(width_vec))
    height = float(np.linalg.norm(height_vec))
    if width <= 1e-6 or height <= 1e-6:
        return points_array_to_list(pts)

    u = width_vec / width
    v = height_vec / height
    pointer = np.array([float(scene_pos.x()), float(scene_pos.y())], dtype=np.float32)
    rel = pointer - p0
    local_x = float(np.dot(rel, u))
    local_y = float(np.dot(rel, v))

    x_min, x_max = 0.0, width
    y_min, y_max = 0.0, height
    min_size = max(float(min_size), 1.0)

    if hit in (EditHit.LEFT, EditHit.TOP_LEFT, EditHit.BOTTOM_LEFT):
        x_min = min(local_x, x_max - min_size)
    if hit in (EditHit.RIGHT, EditHit.TOP_RIGHT, EditHit.BOTTOM_RIGHT):
        x_max = max(local_x, x_min + min_size)
    if hit in (EditHit.TOP, EditHit.TOP_LEFT, EditHit.TOP_RIGHT):
        y_min = min(local_y, y_max - min_size)
    if hit in (EditHit.BOTTOM, EditHit.BOTTOM_LEFT, EditHit.BOTTOM_RIGHT):
        y_max = max(local_y, y_min + min_size)

    new_pts = np.array(
        [
            p0 + (x_min * u) + (y_min * v),
            p0 + (x_max * u) + (y_min * v),
            p0 + (x_max * u) + (y_max * v),
            p0 + (x_min * u) + (y_max * v),
        ],
        dtype=np.float32,
    )
    return points_array_to_list(new_pts)


def constrain_points_to_image_by_translation(points: Any, image_size: QSize) -> list[list[float]]:
    """Keep a rotated rectangle inside the image without changing its angle/shape.

    If the polygon is larger than the image in either dimension, fall back to
    point-wise clamping for that extreme case.
    """
    pts = np.asarray(points, dtype=np.float32).reshape(4, 2).copy()
    max_x = max(1.0, float(image_size.width()))
    max_y = max(1.0, float(image_size.height()))

    min_x, min_y = float(np.min(pts[:, 0])), float(np.min(pts[:, 1]))
    max_px, max_py = float(np.max(pts[:, 0])), float(np.max(pts[:, 1]))

    dx = 0.0
    if max_px - min_x <= max_x:
        if min_x < 0.0:
            dx = -min_x
        elif max_px > max_x:
            dx = max_x - max_px
    else:
        pts[:, 0] = np.clip(pts[:, 0], 0.0, max_x)

    dy = 0.0
    if max_py - min_y <= max_y:
        if min_y < 0.0:
            dy = -min_y
        elif max_py > max_y:
            dy = max_y - max_py
    else:
        pts[:, 1] = np.clip(pts[:, 1], 0.0, max_y)

    pts[:, 0] += dx
    pts[:, 1] += dy
    return points_array_to_list(pts)


def point_segment_distance(point: QPointF, a: QPointF, b: QPointF) -> float:
    px, py = float(point.x()), float(point.y())
    ax, ay = float(a.x()), float(a.y())
    bx, by = float(b.x()), float(b.y())
    dx = bx - ax
    dy = by - ay
    denom = dx * dx + dy * dy
    if denom <= 1e-9:
        return math.hypot(px - ax, py - ay)
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / denom))
    cx = ax + t * dx
    cy = ay + t * dy
    return math.hypot(px - cx, py - cy)


@dataclass
class CropRecord:
    index: int
    points: list[list[float]]
    label: str = ""
    keep: bool = True

    @property
    def rect(self) -> QRectF:
        return points_to_rect(self.points)

    def set_rect(self, rect: QRectF) -> None:
        self.points = rect_to_points(rect)

    def set_points(self, points: Any) -> None:
        self.points = clean_points(points)


# ---------------------------------------------------------------------------
# Main image viewer with editable crop rectangles
# ---------------------------------------------------------------------------


class EditHit:
    NONE = "none"
    MOVE = "move"
    ROTATE = "rotate"
    LEFT = "left"
    RIGHT = "right"
    TOP = "top"
    BOTTOM = "bottom"
    TOP_LEFT = "top_left"
    TOP_RIGHT = "top_right"
    BOTTOM_LEFT = "bottom_left"
    BOTTOM_RIGHT = "bottom_right"
    PAN = "pan"


class CropRectItem(QGraphicsPolygonItem):
    """One editable crop polygon in the main QGraphicsScene.

    Normal dragging keeps the previous edit behavior: move the box when dragging
    inside it, or resize it with edge/corner handles. Holding Meta (Command on macOS)
    or Control while pressing and dragging left/right rotates the current polygon in-place.
    """

    ROTATION_DEGREES_PER_PIXEL = 0.25

    def __init__(self, owner: "MainWindow", pos: int, crop: CropRecord):
        super().__init__(points_to_qpolygon(crop.points))
        self.owner = owner
        self.crop_pos = int(pos)
        self.drag_hit = EditHit.NONE
        self.drag_start_scene = QPointF()
        self.drag_start_rect = QRectF()
        self.drag_start_points: list[list[float]] = []
        self.drag_moved = False
        self.setAcceptHoverEvents(True)
        self.setAcceptedMouseButtons(Qt.MouseButton.LeftButton)
        self.setFlag(QGraphicsItem.GraphicsItemFlag.ItemIsFocusable, True)
        # A nearly transparent brush makes the whole polygon clickable without
        # visibly tinting the source image.
        self.setBrush(QColor(0, 0, 0, 1))
        self.update_style()

    def handle_scene_size(self) -> float:
        return self.owner.canvas.handle_scene_size()

    def rect(self) -> QRectF:
        return self.polygon().boundingRect().normalized()

    def points(self) -> list[list[float]]:
        return qpolygon_to_points(self.polygon())

    def setRect(self, rect: QRectF) -> None:
        r = rect.normalized()
        self.setPolygon(points_to_qpolygon(rect_to_points(r)))

    def set_points(self, points: Any) -> None:
        self.setPolygon(points_to_qpolygon(points))

    def boundingRect(self) -> QRectF:  # type: ignore[override]
        # Pad enough for fixed cosmetic strokes and resize handles at any zoom.
        pad = max(8.0, self.handle_scene_size() + 4.0)
        return super().boundingRect().adjusted(-pad, -pad, pad, pad)

    def update_style(self) -> None:
        """Update z-order/visibility and request a repaint."""
        crop = self.owner.crops[self.crop_pos] if 0 <= self.crop_pos < len(self.owner.crops) else None
        if crop is None:
            self.setVisible(False)
            return
        self.setVisible(True)
        if self.crop_pos == self.owner.selected_pos:
            self.setZValue(40)
        elif crop.keep:
            self.setZValue(20)
        else:
            self.setZValue(18)

        # Keep a non-empty cosmetic pen on the base item for Qt's update/shape
        # bookkeeping. The visible stroke is drawn explicitly in paint().
        base_pen = QPen(QColor(0, 0, 0, 1), 1.0)
        base_pen.setCosmetic(True)
        self.setPen(base_pen)
        self.update()

    def _stroke_style(self) -> tuple[QColor, float]:
        crop = self.owner.crops[self.crop_pos] if 0 <= self.crop_pos < len(self.owner.crops) else None
        if crop is None:
            return QColor(255, 165, 0), 2.5
        if self.crop_pos == self.owner.selected_pos:
            return QColor(70, 135, 255), 4.0
        if crop.keep:
            return QColor(255, 165, 0), 2.8
        return QColor(255, 182, 193), 3.0

    def paint(self, painter: QPainter, option, widget=None) -> None:  # type: ignore[override]
        painter.setRenderHint(QPainter.RenderHint.Antialiasing, True)
        poly = self.polygon()

        # Do not tint the source image. The invisible brush only keeps the item
        # clickable across its interior; the visible UI is the stroked polygon.
        painter.setBrush(QColor(0, 0, 0, 0))

        color, width = self._stroke_style()

        # Contrast under-stroke so orange kept boxes remain visible on bright or
        # similarly colored paper/backgrounds.
        under_pen = QPen(QColor(0, 0, 0, 210), width + 2.2)
        under_pen.setCosmetic(True)
        painter.setPen(under_pen)
        painter.drawPolygon(poly)

        top_pen = QPen(color, width)
        top_pen.setCosmetic(True)
        painter.setPen(top_pen)
        painter.drawPolygon(poly)

        if self.crop_pos != self.owner.selected_pos:
            return

        size = self.handle_scene_size()
        handle_outline = QPen(QColor(0, 0, 0), 1)
        handle_outline.setCosmetic(True)
        painter.setPen(handle_outline)
        painter.setBrush(QColor(255, 255, 255))
        for pt in self._handle_points():
            painter.drawRect(QRectF(pt.x() - size * 0.5, pt.y() - size * 0.5, size, size))

    def _poly_qpoints(self) -> list[QPointF]:
        poly = self.polygon()
        try:
            count = int(poly.count())
        except Exception:
            count = len(poly)  # type: ignore[arg-type]
        return [QPointF(poly[i]) for i in range(count)]

    def _handle_points(self) -> list[QPointF]:
        pts = self._poly_qpoints()
        if len(pts) != 4:
            r = self.rect().normalized()
            pts = [r.topLeft(), r.topRight(), r.bottomRight(), r.bottomLeft()]
        mids = [QPointF((pts[i].x() + pts[(i + 1) % 4].x()) * 0.5, (pts[i].y() + pts[(i + 1) % 4].y()) * 0.5) for i in range(4)]
        return [pts[0], mids[0], pts[1], mids[1], pts[2], mids[2], pts[3], mids[3]]

    def _hit_at(self, p: QPointF) -> str:
        pts = self._poly_qpoints()
        tol = max(4.0, self.handle_scene_size())
        if len(pts) != 4:
            r = self.rect().normalized()
            return EditHit.MOVE if r.contains(p) else EditHit.NONE

        # Corner handles first.
        corner_hits = [EditHit.TOP_LEFT, EditHit.TOP_RIGHT, EditHit.BOTTOM_RIGHT, EditHit.BOTTOM_LEFT]
        for hit, corner in zip(corner_hits, pts):
            if math.hypot(p.x() - corner.x(), p.y() - corner.y()) <= tol:
                return hit

        # Then edge handles / edge hit areas.
        edge_hits = [EditHit.TOP, EditHit.RIGHT, EditHit.BOTTOM, EditHit.LEFT]
        for i, hit in enumerate(edge_hits):
            if point_segment_distance(p, pts[i], pts[(i + 1) % 4]) <= tol:
                return hit

        if self.polygon().containsPoint(p, Qt.FillRule.OddEvenFill):
            return EditHit.MOVE
        return EditHit.NONE

    def hoverMoveEvent(self, event) -> None:  # type: ignore[override]
        if event.modifiers() & (Qt.KeyboardModifier.MetaModifier | Qt.KeyboardModifier.ControlModifier):
            self.setCursor(self.owner.canvas.cursor_for_hit(EditHit.ROTATE))
        else:
            self.setCursor(self.owner.canvas.cursor_for_hit(self._hit_at(event.pos())))
        super().hoverMoveEvent(event)

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        self.owner.select_crop(self.crop_pos, focus=False)
        if event.modifiers() & (Qt.KeyboardModifier.MetaModifier | Qt.KeyboardModifier.ControlModifier):
            self.drag_hit = EditHit.ROTATE
        else:
            self.drag_hit = self._hit_at(event.pos())
            if self.drag_hit == EditHit.NONE:
                self.drag_hit = EditHit.MOVE
        self.drag_start_scene = event.scenePos()
        self.drag_start_rect = QRectF(self.rect()).normalized()
        self.drag_start_points = self.points()
        self.drag_moved = False
        event.accept()

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        if self.drag_hit == EditHit.NONE:
            return
        if (event.scenePos() - self.drag_start_scene).manhattanLength() > 2:
            self.drag_moved = True
        new_points = self._updated_points_for_drag(event.scenePos())
        self.prepareGeometryChange()
        self.set_points(new_points)
        self.owner.set_crop_points(self.crop_pos, new_points, refresh_thumbnail=False, update_canvas_item=False)
        if self.drag_hit == EditHit.ROTATE:
            dx = event.scenePos().x() - self.drag_start_scene.x()
            angle = dx * self.ROTATION_DEGREES_PER_PIXEL
            self.owner.statusBar().showMessage(
                f"Rotating crop #{self.owner.crops[self.crop_pos].index}: {angle:+.1f}° "
                "(drag right = clockwise, left = counter-clockwise)"
            )
        event.accept()

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if self.drag_hit != EditHit.NONE and self.drag_moved:
            # Only refresh the one affected crop after actual geometry edits.
            self.owner.refresh_crop_visuals(self.crop_pos)
            if self.drag_hit == EditHit.ROTATE:
                self.owner.statusBar().showMessage(f"Rotated crop #{self.owner.crops[self.crop_pos].index}")
        self.drag_hit = EditHit.NONE
        self.drag_moved = False
        event.accept()

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        self.owner.select_crop(self.crop_pos, focus=True)
        event.accept()

    def _updated_points_for_drag(self, scene_pos: QPointF) -> list[list[float]]:
        delta = scene_pos - self.drag_start_scene
        hit = self.drag_hit
        image_size = self.owner.canvas.image_size()

        if hit == EditHit.ROTATE:
            dx = scene_pos.x() - self.drag_start_scene.x()
            angle = dx * self.ROTATION_DEGREES_PER_PIXEL
            points = rotate_points_about_center(self.drag_start_points, angle)
            return constrain_points_to_image_by_translation(points, image_size)

        if hit == EditHit.MOVE:
            points = translate_points(self.drag_start_points, delta.x(), delta.y())
            return constrain_points_to_image_by_translation(points, image_size)

        # Resize in the crop's own local coordinate system so rotated boxes stay
        # rotated while their width/height changes along the rotated axes.
        points = resize_points_along_local_axes(self.drag_start_points, scene_pos, hit)
        return constrain_points_to_image_by_translation(points, image_size)

    def _updated_rect_for_resize(self, scene_pos: QPointF) -> QRectF:
        r = QRectF(self.drag_start_rect).normalized()
        hit = self.drag_hit
        x1, y1, x2, y2 = r.left(), r.top(), r.right(), r.bottom()
        if hit in (EditHit.LEFT, EditHit.TOP_LEFT, EditHit.BOTTOM_LEFT):
            x1 = scene_pos.x()
        if hit in (EditHit.RIGHT, EditHit.TOP_RIGHT, EditHit.BOTTOM_RIGHT):
            x2 = scene_pos.x()
        if hit in (EditHit.TOP, EditHit.TOP_LEFT, EditHit.TOP_RIGHT):
            y1 = scene_pos.y()
        if hit in (EditHit.BOTTOM, EditHit.BOTTOM_LEFT, EditHit.BOTTOM_RIGHT):
            y2 = scene_pos.y()
        new_rect = QRectF(QPointF(x1, y1), QPointF(x2, y2)).normalized()
        return clamp_rect_to_image(new_rect, self.owner.canvas.image_size())


class ImageCanvas(QGraphicsView):
    """QGraphicsScene-based main image viewer for fast crop selection/editing."""

    def __init__(self, owner: "MainWindow"):
        super().__init__()
        self.owner = owner
        self.scene = QGraphicsScene(self)
        self.scene.setBackgroundBrush(QColor(32, 32, 32))
        self.setScene(self.scene)
        self.setBackgroundBrush(QColor(32, 32, 32))
        self.setStyleSheet("QGraphicsView { background: #202020; border: 1px solid #555; }")
        self.pix_item: Optional[QGraphicsPixmapItem] = None
        self.crop_items: dict[int, CropRectItem] = {}
        self.image: Optional[QImage] = None
        self._panning = False
        self._pan_start = QPointF()
        self.placeholder_label = QLabel("Click here to open image…", self.viewport())
        self.placeholder_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder_label.setStyleSheet(
            "QLabel { color: #eeeeee; background: transparent; font-size: 18px; font-weight: 600; }"
        )
        self.placeholder_label.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        self.placeholder_label.show()
        self.setMouseTracking(True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.setMinimumSize(640, 480)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self.setRenderHints(self.renderHints() | QPainter.RenderHint.Antialiasing | QPainter.RenderHint.SmoothPixmapTransform)
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorUnderMouse)
        self.setResizeAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        self.setDragMode(QGraphicsView.DragMode.NoDrag)

    def image_size(self) -> QSize:
        if self.image is None or self.image.isNull():
            return QSize(1, 1)
        return self.image.size()

    def has_image(self) -> bool:
        return self.image is not None and not self.image.isNull()

    def update_placeholder(self) -> None:
        self.placeholder_label.setGeometry(self.viewport().rect())
        self.placeholder_label.setVisible(not self.has_image())
        self.viewport().update()

    def resizeEvent(self, event) -> None:  # type: ignore[override]
        super().resizeEvent(event)
        self.update_placeholder()

    def handle_scene_size(self) -> float:
        scale = max(0.001, float(self.transform().m11()))
        return 8.0 / scale

    def set_image(self, image: Optional[QImage]) -> None:
        self.image = image
        self.scene.clear()
        self.scene.setBackgroundBrush(QColor(32, 32, 32))
        self.pix_item = None
        self.crop_items.clear()
        self.resetTransform()
        if image is None or image.isNull():
            self.scene.setSceneRect(QRectF(0, 0, max(1, self.viewport().width()), max(1, self.viewport().height())))
            self.update_placeholder()
            return
        self.pix_item = self.scene.addPixmap(QPixmap.fromImage(image))
        self.pix_item.setZValue(0)
        self.pix_item.setAcceptedMouseButtons(Qt.MouseButton.NoButton)
        self.scene.setSceneRect(QRectF(0, 0, image.width(), image.height()))
        self.rebuild_crop_items()
        self.update_placeholder()
        QTimer.singleShot(0, self.zoom_to_fit)

    def rebuild_crop_items(self) -> None:
        for item in list(self.crop_items.values()):
            self.scene.removeItem(item)
        self.crop_items.clear()
        if self.image is None or self.image.isNull():
            return
        for pos, crop in enumerate(self.owner.crops):
            item = CropRectItem(self.owner, pos, crop)
            self.scene.addItem(item)
            self.crop_items[pos] = item
        self.update_all_crop_item_styles()
        self.viewport().update()

    def update_all_crop_item_styles(self) -> None:
        for item in self.crop_items.values():
            item.update_style()
        self.viewport().update()

    def set_selected_pos(self, old_pos: Optional[int], new_pos: Optional[int]) -> None:
        for pos in {old_pos, new_pos}:
            if pos is not None and pos in self.crop_items:
                self.crop_items[pos].update_style()
        self.viewport().update()

    def update_crop_item(self, pos: int) -> None:
        item = self.crop_items.get(pos)
        if item is None:
            return
        if 0 <= pos < len(self.owner.crops):
            item.prepareGeometryChange()
            item.set_points(self.owner.crops[pos].points)
            item.update_style()

    def zoom_to_fit(self) -> None:
        if self.image is None or self.image.isNull() or self.scene.sceneRect().isEmpty():
            return
        self.resetTransform()
        self.fitInView(self.scene.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)
        self.scale(0.94, 0.94)
        self.update_all_crop_item_styles()

    def _crop_view_rect(self, rect: QRectF, margin: float) -> QRectF:
        """Return a padded crop rect clipped to the current scene bounds."""
        scene_rect = self.scene.sceneRect()
        view_rect = rect.adjusted(-margin, -margin, margin, margin)
        if not scene_rect.isEmpty():
            view_rect = view_rect.intersected(scene_rect)
        if view_rect.isEmpty():
            return rect
        return view_rect

    def center_on_crop_without_zoom_change(self, crop: CropRecord) -> None:
        """Pan to the crop while preserving the user's current zoom level."""
        if self.image is None or self.image.isNull():
            return
        rect = crop.rect.normalized()
        if rect.width() <= 0 or rect.height() <= 0:
            return

        margin = max(20.0, 0.25 * max(rect.width(), rect.height()))
        view_rect = self._crop_view_rect(rect, margin)
        self.centerOn(rect.center())
        self.ensureVisible(view_rect, 40, 40)
        self.update_all_crop_item_styles()

    def focus_on_crop(self, crop: CropRecord, *, preserve_zoom: bool = False) -> None:
        if self.image is None or self.image.isNull():
            return
        rect = crop.rect.normalized()
        if rect.width() <= 0 or rect.height() <= 0:
            return

        if preserve_zoom:
            self.center_on_crop_without_zoom_change(crop)
            return

        margin = max(80.0, 0.8 * max(rect.width(), rect.height()))
        view_rect = self._crop_view_rect(rect, margin)

        # The view normally uses AnchorUnderMouse so manual wheel zoom feels
        # natural. For programmatic crop focusing, temporarily anchor around the
        # view center; otherwise the post-fit padding scale can drift toward the
        # mouse position and leave the selected crop off-screen.
        old_anchor = self.transformationAnchor()
        self.setTransformationAnchor(QGraphicsView.ViewportAnchor.AnchorViewCenter)
        try:
            self.fitInView(view_rect, Qt.AspectRatioMode.KeepAspectRatio)
            self.scale(0.94, 0.94)
            self.centerOn(rect.center())
            self.ensureVisible(rect, 40, 40)
        finally:
            self.setTransformationAnchor(old_anchor)

        self.update_all_crop_item_styles()

    def wheelEvent(self, event) -> None:  # type: ignore[override]
        if self.image is None or self.image.isNull():
            return
        factor = 1.15 if event.angleDelta().y() > 0 else 1 / 1.15
        self.scale(factor, factor)
        self.update_all_crop_item_styles()
        event.accept()

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        if not self.has_image():
            if event.button() == Qt.MouseButton.LeftButton:
                QTimer.singleShot(0, self.owner.choose_image)
            event.accept()
            return
        item = self.itemAt(event.position().toPoint())
        if isinstance(item, CropRectItem):
            super().mousePressEvent(event)
            return
        if event.button() in (Qt.MouseButton.LeftButton, Qt.MouseButton.RightButton, Qt.MouseButton.MiddleButton):
            self._panning = True
            self._pan_start = QPointF(event.position())
            self.setCursor(Qt.CursorShape.ClosedHandCursor)
            event.accept()
            return
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event) -> None:  # type: ignore[override]
        if self._panning:
            delta = QPointF(event.position()) - self._pan_start
            self._pan_start = QPointF(event.position())
            self.horizontalScrollBar().setValue(self.horizontalScrollBar().value() - int(delta.x()))
            self.verticalScrollBar().setValue(self.verticalScrollBar().value() - int(delta.y()))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event) -> None:  # type: ignore[override]
        if self._panning:
            self._panning = False
            self.setCursor(Qt.CursorShape.ArrowCursor)
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def mouseDoubleClickEvent(self, event) -> None:  # type: ignore[override]
        item = self.itemAt(event.position().toPoint())
        if isinstance(item, CropRectItem):
            super().mouseDoubleClickEvent(event)
            return
        self.zoom_to_fit()
        event.accept()

    def cursor_for_hit(self, hit: str):
        if hit == EditHit.ROTATE:
            return Qt.CursorShape.SizeHorCursor
        if hit == EditHit.MOVE:
            return Qt.CursorShape.SizeAllCursor
        if hit in (EditHit.LEFT, EditHit.RIGHT):
            return Qt.CursorShape.SizeHorCursor
        if hit in (EditHit.TOP, EditHit.BOTTOM):
            return Qt.CursorShape.SizeVerCursor
        if hit in (EditHit.TOP_LEFT, EditHit.BOTTOM_RIGHT):
            return Qt.CursorShape.SizeFDiagCursor
        if hit in (EditHit.TOP_RIGHT, EditHit.BOTTOM_LEFT):
            return Qt.CursorShape.SizeBDiagCursor
        return Qt.CursorShape.ArrowCursor


# ---------------------------------------------------------------------------
# Thumbnail widgets
# ---------------------------------------------------------------------------


class ThumbCard(QFrame):
    clicked = pyqtSignal(int)

    def __init__(self, pos: int, crop: CropRecord, pixmap: QPixmap, selected: bool):
        super().__init__()
        self.pos = pos
        self.crop = crop
        self.setObjectName("ThumbCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(3)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setFixedSize(150, 72)
        self.image_label.setStyleSheet("QLabel { background: #202020; }")
        if not pixmap.isNull():
            self.image_label.setPixmap(pixmap)
        layout.addWidget(self.image_label)

        self.text_label = QLabel(self._label_text())
        self.text_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.text_label.setWordWrap(True)
        self.text_label.setFixedWidth(150)
        layout.addWidget(self.text_label)

        self.update_style(selected)

    def _label_text(self) -> str:
        label = self.crop.label if self.crop.label else "—"
        return f"#{self.crop.index}  {label}"

    def refresh(self, crop: CropRecord, pixmap: QPixmap, selected: bool) -> None:
        self.crop = crop
        self.image_label.clear()
        if not pixmap.isNull():
            self.image_label.setPixmap(pixmap)
        self.text_label.setText(self._label_text())
        self.update_style(selected)

    def update_style(self, selected: bool) -> None:
        if selected and not self.crop.keep:
            border = "3px solid #4687ff"
            bg = "#fff1f4"
            fg = "#111111"
        elif selected:
            border = "3px solid #4687ff"
            bg = "#eeeeee"
            fg = "#111111"
        elif not self.crop.keep:
            border = "3px solid #ffb6c1"
            bg = "#fff1f4"
            fg = "#111111"
        else:
            border = "1px solid #aaaaaa"
            bg = "#ffffff"
            fg = "#111111"
        self.setStyleSheet(
            f"#ThumbCard {{ border: {border}; border-radius: 5px; background: {bg}; }} "
            f"#ThumbCard QLabel {{ color: {fg}; }}"
        )

    def mousePressEvent(self, event) -> None:  # type: ignore[override]
        self.setFocus(Qt.FocusReason.MouseFocusReason)
        self.clicked.emit(self.pos)
        super().mousePressEvent(event)


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("OCR Word/Crop Curator")
        self.resize(1500, 950)

        self.image_file: Optional[Path] = None
        self.image: Optional[QImage] = None
        self.image_generation = 0
        self.crops: list[CropRecord] = []
        self.selected_pos: Optional[int] = None
        self.json_path: Optional[Path] = None
        # Signature of the most recently saved/exported JSON payload. Used to
        # warn before quitting when current crop/label data has not been
        # exported since the latest edits.
        self._last_export_signature: Optional[str] = None
        self.parseq_checkpoint_path: Optional[Path] = DEFAULT_CHECKPOINT_PATH.expanduser().resolve()
        self.parseq_repo_path: Optional[Path] = find_parseq_repo(DEFAULT_PARSEQ_REPO) or DEFAULT_PARSEQ_REPO.expanduser()
        if "PARSEQ_REPO" not in os.environ and _looks_like_parseq_repo(DEFAULT_PARSEQ_REPO):
            os.environ["PARSEQ_REPO"] = str(DEFAULT_PARSEQ_REPO.expanduser().resolve())
        self.parseq_model_bundle: Optional[ParseqModelBundle] = None
        self.parseq_load_worker: Optional[ParseqLoadWorker] = None
        self.parseq_predict_worker: Optional[ParseqPredictWorker] = None
        self.parseq_load_generation = 0
        self.parseq_loading_checkpoint_path: Optional[Path] = None
        self.pending_parseq_fill_after_load = False
        self.parseq_failed = False
        self.show_parseq_token_debug = False
        self.parseq_token_debug: dict[int, str] = {}
        self.parseq_topk_debug: dict[int, str] = {}

        self.craft_loading = False
        self.craft_ready = False
        self.detect_busy = False
        self.pending_detection_generation: Optional[int] = None
        self.craft_process: Optional[QProcess] = None
        self._craft_stdout_buffer = ""
        self._craft_stderr_tail = ""

        self._updating_ui = False
        self.thumb_cards: list[ThumbCard] = []
        self.thumb_columns = 3
        self.symbol_popup = None
        self.active_label_editor: Optional[QLineEdit] = None
        self.symbol_popup_row: Optional[int] = None
        self.symbol_popup_text: str = ""
        self.symbol_popup_cursor_pos: int = 0
        self.symbol_popup_selection_start: int = -1
        self.symbol_popup_selection_length: int = 0
        self._symbol_popup_restore_on_close = False
        self._app_is_closing = False

        self.build_ui()
        QApplication.instance().installEventFilter(self)  # type: ignore[union-attr]
        self.start_craft_loader()
        QTimer.singleShot(0, self.start_parseq_background_load_if_available)

    # ----- UI construction -----

    def build_ui(self) -> None:
        root = QWidget()
        self.setCentralWidget(root)
        outer = QVBoxLayout(root)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(6)

        toolbar = QHBoxLayout()
        self.open_image_btn = QPushButton("Open Image…")
        self.open_json_btn = QPushButton("Import JSON…")
        self.export_json_btn = QPushButton("Export JSON…")
        self.export_json_btn.setShortcut(QKeySequence.StandardKey.SaveAs)
        self.run_craft_btn = QPushButton("Rerun CRAFT")
        self.fit_btn = QPushButton("Fit Image")
        self.load_parseq_btn = QPushButton("Load PARSeq…")
        self.fill_parseq_btn = QPushButton("Fill Labels")
        self.fill_parseq_btn.setToolTip("Run the loaded PARSeq checkpoint on kept crops and fill blank labels.")
        self.include_empty_labels_checkbox = QCheckBox("Include empty labels")
        self.include_empty_labels_checkbox.setChecked(False)
        self.include_empty_labels_checkbox.setToolTip(
            "When checked, JSON export includes kept crops even if their label is blank."
        )
        self.overwrite_parseq_labels_checkbox = QCheckBox("Overwrite labels")
        self.overwrite_parseq_labels_checkbox.setChecked(False)
        self.overwrite_parseq_labels_checkbox.setToolTip(
            "When checked, PARSeq replaces existing labels too. Otherwise it only fills blank kept labels."
        )
        self.import_labels_only_checkbox = QCheckBox("Import labels only")
        self.import_labels_only_checkbox.setChecked(True)
        self.import_labels_only_checkbox.setToolTip(
            "When checked, Import JSON updates matching labels by index but keeps the current bounding boxes unchanged."
        )
        self.craft_status_label = QLabel("CRAFT loading…")
        self.craft_status_label.setStyleSheet("QLabel { font-weight: bold; color: #333; padding-left: 12px; }")
        self.craft_status_label.setFixedWidth(190)
        self.craft_status_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.craft_status_label.setToolTip("CRAFT loading…")
        parseq_status_text = (
            f"PARSeq: {self.parseq_checkpoint_path.name}"
            if self.parseq_checkpoint_path is not None
            else "PARSeq: no checkpoint"
        )
        self.parseq_status_label = QLabel(parseq_status_text)
        self.parseq_status_label.setStyleSheet("QLabel { font-weight: bold; color: #333; padding-left: 12px; }")
        self.parseq_status_label.setFixedWidth(260)
        self.parseq_status_label.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Preferred)
        self.parseq_status_label.setToolTip(str(self.parseq_checkpoint_path) if self.parseq_checkpoint_path else parseq_status_text)

        toolbar.addWidget(self.open_image_btn)
        toolbar.addWidget(self.open_json_btn)
        toolbar.addWidget(self.export_json_btn)
        toolbar.addWidget(self.run_craft_btn)
        toolbar.addWidget(self.fit_btn)
        toolbar.addWidget(self.load_parseq_btn)
        toolbar.addWidget(self.fill_parseq_btn)
        toolbar.addWidget(self.overwrite_parseq_labels_checkbox)
        toolbar.addWidget(self.include_empty_labels_checkbox)
        toolbar.addWidget(self.import_labels_only_checkbox)
        toolbar.addStretch(1)
        toolbar.addWidget(self.craft_status_label)
        toolbar.addWidget(self.parseq_status_label)
        outer.addLayout(toolbar)

        self.open_image_btn.clicked.connect(self.choose_image)
        self.open_json_btn.clicked.connect(self.choose_json)
        self.export_json_btn.clicked.connect(self.export_json)
        self.run_craft_btn.clicked.connect(lambda: self.request_detection(force=True))
        self.fit_btn.clicked.connect(self.canvas_zoom_to_fit_safe)
        self.load_parseq_btn.clicked.connect(self.choose_parseq_checkpoint)
        self.fill_parseq_btn.clicked.connect(self.fill_labels_with_parseq)

        splitter = QSplitter(Qt.Orientation.Horizontal)
        outer.addWidget(splitter, 1)

        self.canvas = ImageCanvas(self)
        splitter.addWidget(self.canvas)

        side = QWidget()
        side_layout = QVBoxLayout(side)
        side_layout.setContentsMargins(6, 0, 0, 0)
        side_layout.setSpacing(6)
        splitter.addWidget(side)
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 0)
        side.setMinimumWidth(430)

        self.info_label = QLabel("Open an image. Detection will run automatically when CRAFT is ready.")
        self.info_label.setWordWrap(True)
        side_layout.addWidget(self.info_label)

        self.table_controller = CropTableController(self)
        self.table_tools = self.table_controller.create_find_replace_bar(side)
        side_layout.addWidget(self.table_tools, 0)
        self.table = self.table_controller.create_table(side)
        self.label_delegate = self.table_controller.label_delegate
        side_layout.addWidget(self.table, 0)
        self.build_menus()

        self.thumb_scroll = QScrollArea()
        self.thumb_scroll.setWidgetResizable(True)
        self.thumb_container = QWidget()
        self.thumb_grid = QGridLayout(self.thumb_container)
        self.thumb_grid.setContentsMargins(4, 4, 4, 4)
        self.thumb_grid.setSpacing(8)
        self.thumb_scroll.setWidget(self.thumb_container)
        side_layout.addWidget(QLabel("Thumbnails"))
        side_layout.addWidget(self.thumb_scroll, 1)

        self.statusBar().showMessage("Ready")
        self.update_actions()

    def canvas_zoom_to_fit_safe(self) -> None:
        self.canvas.zoom_to_fit()

    def _make_action(self, text: str, triggered, shortcut: Optional[object] = None) -> QAction:
        action = QAction(text, self)
        if shortcut is not None:
            if isinstance(shortcut, QKeySequence.StandardKey):
                action.setShortcuts(shortcut)
            elif isinstance(shortcut, (list, tuple)):
                action.setShortcuts([QKeySequence(str(seq)) for seq in shortcut])
            else:
                action.setShortcut(QKeySequence(str(shortcut)))
            action.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
        action.triggered.connect(triggered)
        return action

    def build_menus(self) -> None:
        menubar = self.menuBar()
        menubar.clear()

        file_menu = menubar.addMenu("&File")
        self.action_open_image = self._make_action("Open Image…", self.choose_image, "Ctrl+Shift+O")
        self.action_import_json = self._make_action("Import JSON…", self.choose_json, QKeySequence.StandardKey.Open)
        self.action_save_json = self._make_action("Save JSON", self.save_json, QKeySequence.StandardKey.Save)
        self.action_export_json = self._make_action("Export JSON As…", self.export_json, QKeySequence.StandardKey.SaveAs)
        self.action_quit = self._make_action("Quit", self.close, QKeySequence.StandardKey.Quit)
        file_menu.addAction(self.action_open_image)
        file_menu.addAction(self.action_import_json)
        file_menu.addSeparator()
        file_menu.addAction(self.action_save_json)
        file_menu.addAction(self.action_export_json)
        file_menu.addSeparator()
        file_menu.addAction(self.action_quit)

        edit_menu = menubar.addMenu("&Edit")
        self.action_undo = self._make_action("Undo", self.table_controller.undo, QKeySequence.StandardKey.Undo)
        self.action_redo = self._make_action("Redo", self.table_controller.redo, QKeySequence.StandardKey.Redo)
        self.table_controller.set_history_actions(self.action_undo, self.action_redo)
        self.action_find = self._make_action("Find…", self.table_controller.focus_find, QKeySequence.StandardKey.Find)
        self.action_find_again = self._make_action("Find Again", self.table_controller.find_next, QKeySequence.StandardKey.FindNext)
        self.action_find_previous = self._make_action("Find Previous", self.table_controller.find_previous, QKeySequence.StandardKey.FindPrevious)
        self.action_replace = self._make_action("Replace…", self.table_controller.focus_replace, "Ctrl+H")
        self.action_copy_crop = self._make_action("Copy Selected Crop", self.copy_selected_crop_to_clipboard)
        self.action_copy_crop.setToolTip("Copy the currently selected crop image (Cmd/Ctrl+C when no text field is focused)")
        self.action_toggle_keep = self._make_action("Toggle Keep", self.table_controller.toggle_selected_keep, "Delete")
        edit_menu.addAction(self.action_undo)
        edit_menu.addAction(self.action_redo)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_find)
        edit_menu.addAction(self.action_find_again)
        edit_menu.addAction(self.action_find_previous)
        edit_menu.addAction(self.action_replace)
        edit_menu.addSeparator()
        edit_menu.addAction(self.action_copy_crop)
        edit_menu.addAction(self.action_toggle_keep)

        view_menu = menubar.addMenu("&View")
        self.action_fit_image = self._make_action("Fit Image", self.canvas_zoom_to_fit_safe, "Ctrl+0")
        self.action_keep_zoom = QAction("Keep Zoom", self)
        self.action_keep_zoom.setCheckable(True)
        self.action_keep_zoom.setChecked(False)
        self.action_keep_zoom.setToolTip(
            "When enabled, selecting/cycling crops keeps the current zoom and only pans to the selected crop."
        )
        self.action_rerun_craft = self._make_action("Rerun CRAFT", lambda: self.request_detection(force=True), "Ctrl+R")
        self.action_load_parseq = self._make_action("Load PARSeq Checkpoint…", self.choose_parseq_checkpoint)
        self.action_fill_labels = self._make_action("Fill Labels with PARSeq", self.fill_labels_with_parseq)
        view_menu.addAction(self.action_fit_image)
        view_menu.addAction(self.action_keep_zoom)
        view_menu.addSeparator()
        view_menu.addAction(self.action_rerun_craft)
        view_menu.addSeparator()
        view_menu.addAction(self.action_load_parseq)
        view_menu.addAction(self.action_fill_labels)

        parseq_menu = menubar.addMenu("&PARSeq")
        self.action_set_parseq_repo = self._make_action("Set PARSeq Repo…", self.choose_parseq_repo)
        self.action_show_parseq_token_debug = QAction("Show Raw/Top-K Token Debug", self)
        self.action_show_parseq_token_debug.setCheckable(True)
        self.action_show_parseq_token_debug.setChecked(self.show_parseq_token_debug)
        self.action_show_parseq_token_debug.setToolTip(
            "Print PARSeq raw token rows and top-k token probabilities, including direct hybrid-token watch probs."
        )
        self.action_show_parseq_token_debug.triggered.connect(self.set_parseq_token_debug_enabled)
        parseq_menu.addAction(self.action_set_parseq_repo)
        parseq_menu.addSeparator()
        parseq_menu.addAction(self.action_load_parseq)
        parseq_menu.addAction(self.action_fill_labels)
        parseq_menu.addSeparator()
        parseq_menu.addAction(self.action_show_parseq_token_debug)

    # ----- CRAFT helper-process lifecycle -----

    def start_craft_loader(self) -> None:
        """Start the separate EasyOCR/CRAFT helper process.

        The main GUI process keeps native file dialogs. The helper process owns
        the heavy EasyOCR/torch/OpenCV model initialization and all detections.
        """
        if self.craft_process is not None:
            return

        self.craft_loading = True
        self.craft_ready = False
        self.set_craft_status("CRAFT loading…")
        self.update_actions()

        worker_module = CRAFT_WORKER_MODULE
        worker_spec = importlib.util.find_spec(worker_module)
        worker_cwd: Optional[Path] = None
        if worker_spec is None:
            self.craft_loading = False
            self.craft_ready = False
            self.craft_process = None
            self.set_craft_status("CRAFT worker module missing")
            self.update_actions()
            QMessageBox.warning(
                self,
                "CRAFT worker module missing",
                "Could not import the CRAFT worker module:\n"
                f"{worker_module}\n\n"
                "Expected it to be available as inspector/craft_worker_process_v1.py.",
            )
            return

        worker_origin = getattr(worker_spec, "origin", None)
        if worker_origin and worker_origin not in ("built-in", "frozen"):
            try:
                # Run the helper from the package parent so `python -m inspector...`
                # works even when the GUI was launched by absolute path.
                worker_cwd = Path(str(worker_origin)).resolve().parents[1]
            except Exception:
                worker_cwd = None

        process = QProcess(self)
        process.setProgram(sys.executable)
        process.setArguments(["-u", "-m", worker_module])
        if worker_cwd is not None:
            process.setWorkingDirectory(str(worker_cwd))
        process.setProcessChannelMode(QProcess.ProcessChannelMode.SeparateChannels)
        process.readyReadStandardOutput.connect(self.on_craft_process_stdout)
        process.readyReadStandardError.connect(self.on_craft_process_stderr)
        process.errorOccurred.connect(self.on_craft_process_error)
        process.finished.connect(self.on_craft_process_finished)
        self.craft_process = process
        process.start()

        if not process.waitForStarted(1000):
            self.craft_loading = False
            self.craft_ready = False
            self.craft_process = None
            self.set_craft_status("CRAFT failed to start")
            self.update_actions()

    def on_craft_process_stdout(self) -> None:
        process = self.craft_process
        if process is None:
            return
        data = bytes(process.readAllStandardOutput()).decode("utf-8", errors="replace")
        if not data:
            return
        self._craft_stdout_buffer += data
        while "\n" in self._craft_stdout_buffer:
            line, self._craft_stdout_buffer = self._craft_stdout_buffer.split("\n", 1)
            line = line.strip()
            if not line:
                continue
            try:
                message = json.loads(line)
            except Exception:
                # EasyOCR/torch may occasionally print non-protocol text.
                # Ignore it rather than letting stdout noise break the GUI.
                continue
            self.handle_craft_worker_message(message)

    def on_craft_process_stderr(self) -> None:
        process = self.craft_process
        if process is None:
            return
        data = bytes(process.readAllStandardError()).decode("utf-8", errors="replace")
        if not data:
            return
        self._craft_stderr_tail = (self._craft_stderr_tail + data)[-4000:]

    def on_craft_process_error(self, error) -> None:
        self.craft_loading = False
        self.craft_ready = False
        self.detect_busy = False
        self.set_craft_status(f"CRAFT error: {error}")
        self.update_actions()

    def on_craft_process_finished(self, exit_code: int, exit_status) -> None:
        was_ready = self.craft_ready
        self.craft_loading = False
        self.craft_ready = False
        self.detect_busy = False
        self.craft_process = None
        self.update_actions()
        if was_ready:
            self.set_craft_status(f"CRAFT exited ({exit_code}). Click Rerun CRAFT to restart it.")
        else:
            details = self._craft_stderr_tail.strip()
            if details:
                self.set_craft_status("CRAFT failed to load")
                QMessageBox.warning(
                    self,
                    "CRAFT failed to load",
                    "The CRAFT exited before it became ready.\n\n"
                    f"Details:\n{details[-2500:]}",
                )
            else:
                self.set_craft_status("CRAFT exited before ready")

    def handle_craft_worker_message(self, message: dict[str, Any]) -> None:
        message_type = message.get("type")

        if message_type == "ready":
            self.craft_loading = False
            self.craft_ready = True
            self.set_craft_status("CRAFT ready")
            self.update_actions()
            if self.pending_detection_generation is not None:
                QTimer.singleShot(0, lambda: self.request_detection(force=True))
            return

        if message_type == "load_failed":
            self.craft_loading = False
            self.craft_ready = False
            self.detect_busy = False
            tb = str(message.get("traceback", ""))
            self.set_craft_status("CRAFT failed to load")
            self.update_actions()
            QMessageBox.warning(
                self,
                "CRAFT failed to load",
                "EasyOCR/CRAFT could not be loaded. "
                "You can still load/edit/export JSON manually.\n\n"
                "Install with:\npython -m pip install easyocr opencv-python numpy\n\n"
                f"Details:\n{tb[-2500:]}",
            )
            return

        if message_type == "detect_finished":
            self.on_detect_finished(
                int(message.get("generation", -1)),
                str(message.get("image_file", "")),
                message.get("result", {}),
            )
            return

        if message_type == "detect_failed":
            self.on_detect_failed(
                int(message.get("generation", -1)),
                str(message.get("image_file", "")),
                str(message.get("traceback", "")),
            )
            return

        if message_type == "protocol_error":
            extra = str(message.get("message") or message.get("traceback") or "")
            self.statusBar().showMessage(f"CRAFT protocol warning: {extra[:200]}")

    def set_craft_status(self, text: str) -> None:
        self.craft_status_label.setText(text)
        self.craft_status_label.setToolTip(text)
        self.statusBar().showMessage(text)

    def _send_craft_request(self, payload: dict[str, Any]) -> bool:
        process = self.craft_process
        if process is None or process.state() != QProcess.ProcessState.Running:
            return False
        try:
            data = (json.dumps(payload, ensure_ascii=False) + "\n").encode("utf-8")
            process.write(data)
            process.waitForBytesWritten(100)
            return True
        except Exception:
            return False

    def request_detection(self, force: bool = False) -> None:
        if self.image_file is None:
            if force:
                QMessageBox.information(self, "No image", "Open an image before running CRAFT detection.")
            return

        self.pending_detection_generation = self.image_generation

        if not self.craft_ready:
            if self.craft_process is None:
                self.start_craft_loader()
            self.set_craft_status("CRAFT loading…")
            return

        if self.detect_busy:
            self.set_craft_status("Detecting…")
            return

        if self.image is None or self.image.isNull():
            return

        generation = self.image_generation
        image_file = str(self.image_file)
        self.pending_detection_generation = None
        self.detect_busy = True
        self.set_craft_status("Detecting…")
        self.update_actions()

        ok = self._send_craft_request(
            {
                "type": "detect",
                "generation": generation,
                "image_file": image_file,
            }
        )
        if not ok:
            self.detect_busy = False
            self.pending_detection_generation = generation
            self.craft_ready = False
            self.set_craft_status("CRAFT not available; restarting…")
            self.update_actions()
            if self.craft_process is not None:
                self.craft_process.kill()
                self.craft_process = None
            self.start_craft_loader()

    def on_detect_finished(self, generation: int, image_file: str, result_obj: object) -> None:
        self.detect_busy = False
        stale = generation != self.image_generation or self.image_file is None or image_file != str(self.image_file)
        if stale:
            self.set_craft_status("Ignored stale detection result")
        else:
            result = result_obj if isinstance(result_obj, dict) else {"boxes": list(result_obj)}
            boxes = list(result.get("boxes", []))
            self.set_crops_from_detected_boxes(boxes)
            h_count = int(result.get("horizontal_count", 0) or 0)
            f_count = int(result.get("free_count", 0) or 0)
            steps = result.get("steps", []) or []
            step_text = "; ".join(str(x) for x in steps) if steps else "original image"
            self.set_craft_status(
                f"CRAFT ready — detected {len(self.crops)} candidates "
                f"(horizontal={h_count}, free={f_count}; {step_text})"
            )

        self.update_actions()
        self._maybe_run_pending_detection()

    def on_detect_failed(self, generation: int, image_file: str, tb: str) -> None:
        self.detect_busy = False
        stale = generation != self.image_generation or self.image_file is None or image_file != str(self.image_file)
        if stale:
            self.set_craft_status("Ignored stale detection error")
        else:
            self.set_craft_status("CRAFT detection failed")
            QMessageBox.warning(self, "CRAFT detection failed", tb[-2500:])
        self.update_actions()
        self._maybe_run_pending_detection()

    def _maybe_run_pending_detection(self) -> None:
        if (
            self.pending_detection_generation is not None
            and self.image_file is not None
            and self.pending_detection_generation == self.image_generation
            and self.craft_ready
            and not self.detect_busy
        ):
            QTimer.singleShot(0, lambda: self.request_detection(force=True))

    # ----- Image / JSON loading -----

    def choose_image(self) -> None:
        start = str(self.image_file.parent) if self.image_file else str(Path.cwd())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Open image",
            start,
            "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp);;All files (*)",
        )
        if path:
            self.load_image(Path(path), auto_detect=True, clear_crops=True)

    def load_image(self, path: Path, *, auto_detect: bool, clear_crops: bool) -> bool:
        if not path.exists():
            QMessageBox.warning(self, "Image not found", f"Image does not exist:\n{path}")
            return False
        img = QImage(str(path))
        if img.isNull():
            QMessageBox.warning(self, "Could not open image", f"Qt could not load this image:\n{path}")
            return False

        self.image_file = path.resolve()
        self.image = img.convertToFormat(QImage.Format.Format_RGB32)
        self.image_generation += 1
        self.canvas.set_image(self.image)
        self.info_label.setText(f"Image: {self.image_file}\nSize: {self.image.width()} × {self.image.height()}")

        if clear_crops:
            self.crops = []
            self.selected_pos = None
            self.json_path = None
            self._last_export_signature = None
            self.refresh_all_views()

        self.update_actions()

        if auto_detect:
            self.request_detection(force=False)
        return True

    def choose_json(self) -> None:
        start = str(self.json_path.parent) if self.json_path else str(Path.cwd())
        path, _ = QFileDialog.getOpenFileName(self, "Load training JSON", start, "JSON (*.json);;All files (*)")
        if path:
            self.load_json(Path(path))

    def load_json(self, path: Path) -> None:
        try:
            with path.open("r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as exc:
            QMessageBox.warning(self, "Could not read JSON", str(exc))
            return

        if not isinstance(data, dict):
            QMessageBox.warning(self, "Invalid JSON format", "Top-level JSON value must be an object.")
            return

        try:
            crops_data = data.get("crops", [])
            if not isinstance(crops_data, list):
                raise ValueError("crops must be a list")
        except Exception as exc:
            QMessageBox.warning(self, "Invalid JSON format", str(exc))
            return

        try:
            image_value = data.get("image")
            image_filename = Path(str(image_value).strip()).name if image_value not in (None, "") else ""
            if not image_filename:
                raise ValueError("JSON must contain an image field with the image filename.")
            image_file_from_json = (path.parent / image_filename).resolve()
        except Exception as exc:
            QMessageBox.warning(self, "Invalid JSON format", str(exc))
            return

        import_labels_only = bool(self.import_labels_only_checkbox.isChecked())
        if import_labels_only and (self.image is None or self.image.isNull() or not self.crops):
            QMessageBox.information(
                self,
                "No current crops",
                "'Import labels only' is selected: No crops to update."
            )
            return

        # If detections are already loaded, treat Import JSON as an overlay:
        # update only existing rows with matching index values. This lets a
        # small exported/training JSON fill labels back into a larger current
        # detection set without deleting unmatched rows. When "Import labels
        # only" is checked, keep all current boxes unchanged even if the
        # imported JSON also contains points.
        if self.image is not None and not self.image.isNull() and self.crops:
            current_by_index: dict[int, int] = {}
            for pos, crop in enumerate(self.crops):
                try:
                    current_by_index[int(crop.index)] = pos
                except Exception:
                    continue

            updated_positions: set[int] = set()
            skipped_no_match = 0
            skipped_invalid = 0

            for i, item in enumerate(crops_data, start=1):
                if not isinstance(item, dict):
                    skipped_invalid += 1
                    continue
                try:
                    idx = int(item.get("index", i))
                except Exception:
                    skipped_invalid += 1
                    continue

                pos = current_by_index.get(idx)
                if pos is None:
                    skipped_no_match += 1
                    continue

                crop = self.crops[pos]
                crop.index = idx
                crop.label = str(item.get("label", ""))
                crop.keep = True

                # Replace geometry too when requested and the imported JSON
                # provides points. In labels-only mode, keep the current box
                # exactly as-is and import only the label/keep state.
                if not import_labels_only and "points" in item:
                    try:
                        pts = clean_points(item.get("points"))
                        crop.points = constrain_points_to_image_by_translation(pts, self.image.size())
                    except Exception:
                        skipped_invalid += 1

                updated_positions.add(pos)

            self.json_path = path.resolve()
            if updated_positions:
                self.selected_pos = min(updated_positions)
            elif self.selected_pos is not None and not (0 <= self.selected_pos < len(self.crops)):
                self.selected_pos = 0 if self.crops else None

            self.refresh_all_views()
            self.mark_current_json_state_exported()
            if self.selected_pos is not None:
                self.select_crop(self.selected_pos, focus=True)

            if import_labels_only:
                message = f"Imported labels only — updated {len(updated_positions)} matching label(s) by index"
            else:
                message = f"Imported JSON — updated {len(updated_positions)} matching crop(s) by index"
            if skipped_no_match:
                message += f"; skipped {skipped_no_match} unmatched"
            if skipped_invalid:
                message += f"; skipped/partially ignored {skipped_invalid} invalid entry/field(s)"
            self.set_craft_status(message)
            return

        # If no current detection set exists, load this JSON as the current
        # crop list and open its referenced image from the JSON directory.
        image_file = image_file_from_json
        if not image_file.exists():
            QMessageBox.warning(
                self,
                "Image not found",
                f"Could not find image named:\n{image_filename}\n\nExpected it next to the JSON here:\n{image_file}",
            )
            return

        if not self.load_image(image_file, auto_detect=False, clear_crops=True):
            return

        try:
            loaded: list[CropRecord] = []
            for i, item in enumerate(crops_data, start=1):
                if not isinstance(item, dict):
                    raise ValueError(f"crop {i} is not an object")
                pts = clean_points(item.get("points"))
                clean_clamped_points = constrain_points_to_image_by_translation(
                    pts, self.image.size() if self.image else QSize(1, 1)
                )
                if points_to_rect(clean_clamped_points).width() < 1 or points_to_rect(clean_clamped_points).height() < 1:
                    raise ValueError(f"crop {i} has an invalid or empty points polygon")
                loaded.append(
                    CropRecord(
                        index=int(item.get("index", i)),
                        label=str(item.get("label", "")),
                        points=clean_clamped_points,
                        keep=True,
                    )
                )
        except Exception as exc:
            QMessageBox.warning(self, "Invalid JSON format", str(exc))
            return

        self.crops = loaded
        self.selected_pos = 0 if self.crops else None
        self.json_path = path.resolve()
        self.refresh_all_views()
        self.mark_current_json_state_exported()
        if self.selected_pos is not None:
            self.select_crop(self.selected_pos, focus=True)
        self.set_craft_status(f"Loaded JSON — {len(self.crops)} crops")

    def ask_for_image_file(self, start_dir: Path) -> Optional[Path]:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose image for this JSON",
            str(start_dir),
            "Images (*.png *.jpg *.jpeg *.bmp *.tif *.tiff *.webp);;All files (*)",
        )
        return Path(path).resolve() if path else None

    def set_crops_from_detected_boxes(self, boxes: list[list[list[float]]]) -> None:
        if self.image is None:
            return
        image_size = self.image.size()
        new_crops: list[CropRecord] = []
        for i, pts in enumerate(boxes, start=1):
            try:
                cleaned = clamp_points_to_image(clean_points(pts), image_size)
                rect = points_to_rect(cleaned)
                if rect.width() < 1 or rect.height() < 1:
                    continue
            except Exception:
                continue
            new_crops.append(CropRecord(index=i, points=cleaned, label="", keep=True))
        self.crops = new_crops
        self.selected_pos = 0 if self.crops else None
        self.refresh_all_views()
        if self.selected_pos is not None:
            self.select_crop(self.selected_pos, focus=False)

    # ----- PARSeq label filling -----

    def set_parseq_token_debug_enabled(self, checked: bool) -> None:
        self.show_parseq_token_debug = bool(checked)
        state = "on" if self.show_parseq_token_debug else "off"
        self.statusBar().showMessage(f"PARSeq raw/top-k token debug: {state}")

    def choose_parseq_repo(self) -> bool:
        # Keep the menu browser anchored at the project repo by default, even if
        # the app was launched from another working directory.
        start = str(DEFAULT_PARSEQ_REPO.expanduser())

        path = QFileDialog.getExistingDirectory(
            self,
            "Set PARSeq repo",
            start,
        )
        if not path:
            return False

        repo = Path(path).expanduser().resolve()
        if repo.name == "strhub":
            repo = repo.parent

        if not _looks_like_parseq_repo(repo):
            QMessageBox.warning(
                self,
                "Not a PARSeq repo",
                "The selected folder does not look like a PARSeq repo.\n\n"
                "Expected to find:\n"
                "  strhub/\n"
                "  strhub/models/\n\n"
                f"Selected:\n{repo}",
            )
            return False

        latex_tokenizer = repo / "strhub" / "data" / "latex_tokenizer.py"
        if not latex_tokenizer.exists():
            QMessageBox.warning(
                self,
                "Hybrid tokenizer file not found",
                "The selected repo is importable, but it does not contain the hybrid tokenizer file:\n\n"
                f"{latex_tokenizer}\n\n"
                "Character-level checkpoints may still work, but hybrid-tokenizer checkpoints need the patched repo.",
            )

        self.parseq_repo_path = repo
        os.environ["PARSEQ_REPO"] = str(repo)
        self.invalidate_parseq_model_bundle()
        self.set_parseq_status(f"PARSeq repo: {repo}")
        if self.parseq_checkpoint_path is not None and self.parseq_checkpoint_path.exists():
            self.start_parseq_background_load(self.parseq_checkpoint_path)
        self.update_actions()
        return True

    def set_parseq_status(self, text: str) -> None:
        self.parseq_status_label.setText(text)
        self.parseq_status_label.setToolTip(text)
        self.statusBar().showMessage(text)

    def choose_parseq_checkpoint(self) -> bool:
        # start = str(self.parseq_checkpoint_path.parent) if self.parseq_checkpoint_path else str(Path.cwd())
        
        start = str(self.parseq_checkpoint_path) if self.parseq_checkpoint_path else str(Path.cwd())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Load PARSeq checkpoint",
            start,
            "PARSeq checkpoints (*.ckpt);;All files (*)",
        )
        if not path:
            return False
        ckpt = Path(path).expanduser().resolve()
        if not ckpt.exists():
            QMessageBox.warning(self, "Checkpoint not found", f"Checkpoint does not exist:\n{ckpt}")
            return False
        self.parseq_checkpoint_path = ckpt
        self.invalidate_parseq_model_bundle()
        self.start_parseq_background_load(ckpt)
        self.update_actions()
        return True

    def normalize_parseq_checkpoint_path(self, path: Optional[Path]) -> Optional[Path]:
        if path is None:
            return None
        try:
            return path.expanduser().resolve()
        except Exception:
            return path.expanduser()

    def invalidate_parseq_model_bundle(self) -> None:
        self.parseq_model_bundle = None
        self.parseq_failed = False
        self.parseq_token_debug.clear()
        self.parseq_topk_debug.clear()

    def parseq_loaded_for_current_checkpoint(self) -> bool:
        current = self.normalize_parseq_checkpoint_path(self.parseq_checkpoint_path)
        return (
            self.parseq_model_bundle is not None
            and current is not None
            and self.normalize_parseq_checkpoint_path(self.parseq_model_bundle.checkpoint_path) == current
        )

    def parseq_is_loading_current_checkpoint(self) -> bool:
        current = self.normalize_parseq_checkpoint_path(self.parseq_checkpoint_path)
        return (
            self.parseq_load_worker is not None
            and self.parseq_load_worker.isRunning()
            and current is not None
            and self.normalize_parseq_checkpoint_path(self.parseq_loading_checkpoint_path) == current
        )

    def start_parseq_background_load_if_available(self) -> None:
        if self.parseq_checkpoint_path is None:
            self.set_parseq_status("PARSeq: no checkpoint")
            return
        ckpt = self.normalize_parseq_checkpoint_path(self.parseq_checkpoint_path)
        if ckpt is None or not ckpt.exists():
            self.invalidate_parseq_model_bundle()
            self.set_parseq_status("PARSeq: default checkpoint missing")
            self.update_actions()
            return
        self.start_parseq_background_load(ckpt)

    def start_parseq_background_load(self, checkpoint_path: Path) -> bool:
        ckpt = self.normalize_parseq_checkpoint_path(checkpoint_path)
        if ckpt is None:
            self.set_parseq_status("PARSeq: no checkpoint")
            return False
        if not ckpt.exists():
            self.invalidate_parseq_model_bundle()
            self.set_parseq_status(f"PARSeq checkpoint missing: {ckpt.name}")
            self.update_actions()
            return False
        if self.parseq_loaded_for_current_checkpoint() and self.parseq_model_bundle is not None:
            self.set_parseq_status(f"PARSeq ready: {self.parseq_model_bundle.checkpoint_path.name}")
            return True
        if self.parseq_is_loading_current_checkpoint():
            self.set_parseq_status(f"PARSeq: loading {ckpt.name}…")
            return True
        if self.parseq_load_worker is not None and self.parseq_load_worker.isRunning():
            self.set_parseq_status("PARSeq: already loading another checkpoint…")
            return False

        self.invalidate_parseq_model_bundle()
        self.parseq_load_generation += 1
        generation = self.parseq_load_generation
        self.parseq_loading_checkpoint_path = ckpt
        worker = ParseqLoadWorker(ckpt, generation)
        self.parseq_load_worker = worker
        worker.progress.connect(self.on_parseq_load_progress)
        worker.loaded.connect(self.on_parseq_model_loaded)
        worker.failed.connect(self.on_parseq_load_failed)
        worker.load_finished.connect(self.on_parseq_load_finished)
        worker.start()
        self.set_parseq_status(f"PARSeq: loading {ckpt.name}…")
        self.update_actions()
        return True

    def on_parseq_load_progress(self, generation: int, message: str) -> None:
        if generation != self.parseq_load_generation:
            return
        self.set_parseq_status(message)

    def on_parseq_model_loaded(self, generation: int, bundle_obj: object) -> None:
        if generation != self.parseq_load_generation:
            return
        if not isinstance(bundle_obj, ParseqModelBundle):
            self.set_parseq_status("PARSeq load returned an unexpected object")
            return
        current = self.normalize_parseq_checkpoint_path(self.parseq_checkpoint_path)
        loaded = self.normalize_parseq_checkpoint_path(bundle_obj.checkpoint_path)
        if current is None or loaded != current:
            self.set_parseq_status("PARSeq: ignored stale loaded checkpoint")
            return

        self.parseq_model_bundle = bundle_obj
        self.parseq_failed = False
        if bundle_obj.repo_summary:
            print(f"PARSeq repo: {bundle_obj.repo_summary}", flush=True)
        if bundle_obj.tokenizer_summary:
            print(f"PARSeq tokenizer: {bundle_obj.tokenizer_summary}", flush=True)
        if bundle_obj.tokenizer_warning:
            print(f"PARSeq warning: {bundle_obj.tokenizer_warning}", flush=True)
            self.set_parseq_status(f"PARSeq warning: {bundle_obj.tokenizer_warning}")
        else:
            self.set_parseq_status(f"PARSeq ready: {bundle_obj.checkpoint_path.name}")

    def on_parseq_load_failed(self, generation: int, traceback_text: str) -> None:
        if generation != self.parseq_load_generation:
            return
        self.parseq_failed = True
        self.parseq_model_bundle = None
        self.pending_parseq_fill_after_load = False
        self.set_parseq_status("PARSeq failed to load")
        QMessageBox.warning(self, "PARSeq failed to load", traceback_text[-4000:])
        self.update_actions()

    def on_parseq_load_finished(self, generation: int) -> None:
        if generation != self.parseq_load_generation:
            return
        self.parseq_load_worker = None
        self.parseq_loading_checkpoint_path = None
        should_fill = bool(self.pending_parseq_fill_after_load and self.parseq_model_bundle is not None)
        self.pending_parseq_fill_after_load = False
        self.update_actions()
        if should_fill:
            QTimer.singleShot(0, self.fill_labels_with_parseq)

    def fill_labels_with_parseq(self) -> None:
        if self.image is None or self.image.isNull() or self.image_file is None:
            QMessageBox.information(self, "No image", "Open an image before running PARSeq.")
            return
        if not self.crops:
            QMessageBox.information(self, "No crops", "Run CRAFT or import JSON before running PARSeq.")
            return
        if self.parseq_predict_worker is not None and self.parseq_predict_worker.isRunning():
            return
        if self.parseq_checkpoint_path is None and not self.choose_parseq_checkpoint():
            return
        if self.parseq_checkpoint_path is None:
            return

        current_ckpt = self.normalize_parseq_checkpoint_path(self.parseq_checkpoint_path)
        if current_ckpt is None or not current_ckpt.exists():
            QMessageBox.warning(self, "Checkpoint not found", f"Checkpoint does not exist:\n{current_ckpt}")
            return

        if not self.parseq_loaded_for_current_checkpoint():
            self.pending_parseq_fill_after_load = True
            if self.parseq_is_loading_current_checkpoint():
                self.set_parseq_status(f"PARSeq: still loading {current_ckpt.name}; fill queued")
            else:
                if not self.start_parseq_background_load(current_ckpt):
                    self.pending_parseq_fill_after_load = False
                    return
                self.set_parseq_status(f"PARSeq: loading {current_ckpt.name}; fill queued")
            self.update_actions()
            return

        bundle = self.parseq_model_bundle
        if bundle is None:
            return

        overwrite = bool(self.overwrite_parseq_labels_checkbox.isChecked())
        fillable = [c for c in self.crops if c.keep and (overwrite or not c.label.strip())]
        if not fillable:
            self.set_parseq_status("PARSeq: no blank kept labels to fill")
            return

        try:
            source_rgb = qimage_to_numpy_rgb(self.image)
        except Exception as exc:
            QMessageBox.warning(self, "Image conversion failed", str(exc))
            return

        jobs = [
            ParseqCropJob(
                row=pos,
                index=int(crop.index),
                points=[[float(x), float(y)] for x, y in crop.points],
                label=str(crop.label),
                keep=bool(crop.keep),
            )
            for pos, crop in enumerate(self.crops)
        ]

        worker = ParseqPredictWorker(
            bundle,
            source_rgb,
            jobs,
            overwrite_labels=overwrite,
            batch_size=PARSEQ_BATCH_SIZE,
            debug_tokens=self.show_parseq_token_debug,
        )
        self.parseq_predict_worker = worker
        self.parseq_failed = False
        self.parseq_token_debug.clear()
        self.parseq_topk_debug.clear()
        worker.progress.connect(self.on_parseq_progress)
        worker.prediction_ready.connect(self.on_parseq_prediction_ready)
        worker.token_debug_ready.connect(self.on_parseq_token_debug_ready)
        worker.topk_debug_ready.connect(self.on_parseq_topk_debug_ready)
        worker.failed.connect(self.on_parseq_failed)
        worker.fill_finished.connect(self.on_parseq_fill_finished)
        worker.start()
        self.set_parseq_status(f"PARSeq: starting fill with {bundle.checkpoint_path.name}")
        self.update_actions()

    def on_parseq_progress(self, message: str, done: int, total: int) -> None:
        if total > 0 and done > 0 and "filled" not in message.lower():
            message = f"{message} ({done}/{total})"
        self.set_parseq_status(message)

    def on_parseq_prediction_ready(self, row: int, prediction: str, confidence: float) -> None:
        if not (0 <= row < len(self.crops)):
            return
        self.table_controller.set_label_text(row, prediction)
        self.refresh_crop_visuals(row)

    def on_parseq_token_debug_ready(self, row: int, index: int, prediction: str, tokens: str, confidence: float) -> None:
        message = f"PARSeq tokens #{index}: {tokens} -> {prediction!r}"
        if not math.isnan(float(confidence)):
            message += f"  conf={confidence:.3f}"
        self.parseq_token_debug[row] = message
        print("=" * 40, flush=True)
        print(message, flush=True)
        # Show the most recent token row briefly in the status bar, but do not
        # replace the actual crop label with debug text.
        self.statusBar().showMessage(message)

    def on_parseq_topk_debug_ready(self, row: int, index: int, topk_text: str) -> None:
        message = f"PARSeq top-k #{index}: {topk_text}"
        self.parseq_topk_debug[row] = message
        print(message, flush=True)

    def on_parseq_failed(self, traceback_text: str) -> None:
        self.parseq_failed = True
        self.set_parseq_status("PARSeq failed")
        QMessageBox.warning(self, "PARSeq failed", traceback_text[-4000:])

    def on_parseq_fill_finished(self, updated: int, total: int, cancelled: bool) -> None:
        if not self.parseq_failed:
            if cancelled:
                self.set_parseq_status(f"PARSeq cancelled — filled {updated}/{total}")
            elif total == 0:
                self.set_parseq_status("PARSeq: no blank kept labels to fill")
            else:
                self.set_parseq_status(f"PARSeq filled {updated}/{total} label(s)")
        self.parseq_predict_worker = None
        self.update_info_text()
        self.update_actions()

    # ----- Export -----

    def build_export_data(self) -> dict[str, Any]:
        """Build the minimal training JSON payload.

        By default, export includes only crops that are both kept and labeled.
        When "Include empty labels" is checked, kept crops with blank labels are
        included too, using "label": "".
        """
        include_empty_labels = bool(self.include_empty_labels_checkbox.isChecked())
        export_crops = []
        for crop in self.crops:
            label = crop.label.strip()
            if not crop.keep:
                continue
            if not include_empty_labels and not label:
                continue
            export_crops.append(
                {
                    "index": int(crop.index),
                    "label": label,
                    "points": points_to_export(crop.points),
                }
            )

        return {
            "image": self.image_file.name if self.image_file is not None else "",
            "crops": export_crops,
        }

    def current_json_export_signature(self) -> Optional[str]:
        """Stable signature for the JSON payload that would be exported now."""
        if self.image_file is None:
            return None
        try:
            return json.dumps(self.build_export_data(), sort_keys=True, ensure_ascii=False)
        except Exception:
            return None

    def mark_current_json_state_exported(self) -> None:
        """Treat the current crop/label export payload as saved/exported."""
        self._last_export_signature = self.current_json_export_signature()

    def has_unexported_json_changes(self) -> bool:
        """Return True when closing should warn about unexported JSON work."""
        if self.image_file is None or not self.crops:
            return False
        current_signature = self.current_json_export_signature()
        if current_signature is None:
            return False
        return self._last_export_signature != current_signature

    def confirm_quit_if_unexported(self) -> bool:
        """Ask before quitting when crop/label JSON has not been exported."""
        try:
            if hasattr(self, "table_controller"):
                self.table_controller.commit_active_label_editor()
        except Exception:
            pass

        if not self.has_unexported_json_changes():
            return True

        box = QMessageBox(self)
        box.setIcon(QMessageBox.Icon.Warning)
        box.setWindowTitle("Quit without exporting?")
        box.setText("The current crop/label JSON has not been exported since the latest changes.")
        box.setInformativeText("Quit anyway?")
        quit_button = box.addButton("Quit", QMessageBox.ButtonRole.DestructiveRole)
        cancel_button = box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(cancel_button)
        box.exec()
        return box.clickedButton() is quit_button

    def write_json_to_path(self, path: Path, *, status_verb: str) -> bool:
        if self.image_file is None:
            QMessageBox.information(self, "No image", "Open an image before saving/exporting.")
            return False

        data = self.build_export_data()

        try:
            with path.open("w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as exc:
            QMessageBox.warning(self, "Save failed", str(exc))
            return False

        self.json_path = path.resolve()
        self._last_export_signature = json.dumps(data, sort_keys=True, ensure_ascii=False)
        crop_desc = "kept crops" if self.include_empty_labels_checkbox.isChecked() else "kept labeled crops"
        self.statusBar().showMessage(f"{status_verb} {len(data['crops'])} {crop_desc} to {self.json_path}")
        return True

    def save_json(self) -> None:
        """Cmd+S behavior: save to the active JSON path, or Save As if none exists."""
        if self.image_file is None:
            QMessageBox.information(self, "No image", "Open an image before saving.")
            return

        if self.json_path is None:
            self.export_json()
            return

        self.write_json_to_path(self.json_path, status_verb="Saved")

    def export_json(self) -> None:
        """Save As / Export behavior: always ask for an output JSON path."""
        if self.image_file is None:
            QMessageBox.information(self, "No image", "Open an image before exporting.")
            return

        default_path = self.json_path
        if default_path is None:
            default_path = self.image_file.with_name(f"{self.image_file.stem}_training.json")

        path_str, _ = QFileDialog.getSaveFileName(
            self,
            "Export training JSON",
            str(default_path),
            "JSON (*.json);;All files (*)",
        )
        if not path_str:
            return
        path = Path(path_str)
        if path.suffix.lower() != ".json":
            path = path.with_suffix(".json")

        self.write_json_to_path(path, status_verb="Exported")

    # ----- View refresh / selection -----

    def refresh_all_views(self) -> None:
        self.table_controller.populate()
        self.populate_thumbnails()
        self.canvas.rebuild_crop_items()
        self.update_info_text()
        self.update_actions()

    def update_info_text(self) -> None:
        if self.image_file is None or self.image is None:
            self.info_label.setText("Open an image. Detection will run automatically when CRAFT is ready.")
            return
        kept = sum(1 for c in self.crops if c.keep)
        dropped = len(self.crops) - kept
        labeled = sum(1 for c in self.crops if c.label.strip())
        self.info_label.setText(
            f"Image: {self.image_file}\n"
            f"Size: {self.image.width()} × {self.image.height()}\n"
            f"Crops: {len(self.crops)}  kept: {kept}  dropped: {dropped}  labeled: {labeled}"
        )

    def populate_thumbnails(self) -> None:
        while self.thumb_grid.count():
            item = self.thumb_grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        self.thumb_cards = []

        max_size = QSize(148, 70)
        for pos, crop in enumerate(self.crops):
            pixmap = qimage_crop_pixmap(self.image, crop.points, max_size)
            card = ThumbCard(pos, crop, pixmap, selected=(pos == self.selected_pos))
            card.clicked.connect(lambda _clicked_pos, p=pos: self.select_crop(p, focus=True))
            row = pos // self.thumb_columns
            col = pos % self.thumb_columns
            self.thumb_grid.addWidget(card, row, col)
            self.thumb_cards.append(card)
        self.thumb_grid.setRowStretch((len(self.crops) // self.thumb_columns) + 1, 1)
        if self.selected_pos is not None:
            QTimer.singleShot(0, self.ensure_selected_thumbnail_visible)

    def ensure_selected_thumbnail_visible(self) -> None:
        if self.selected_pos is None or not (0 <= self.selected_pos < len(self.thumb_cards)):
            return
        card = self.thumb_cards[self.selected_pos]
        self.thumb_scroll.ensureWidgetVisible(card, 16, 16)

    def refresh_thumbnail_card(self, pos: int) -> None:
        if not (0 <= pos < len(self.crops)):
            return
        if not (0 <= pos < len(self.thumb_cards)):
            self.populate_thumbnails()
            return
        max_size = QSize(148, 70)
        crop = self.crops[pos]
        pixmap = qimage_crop_pixmap(self.image, crop.points, max_size)
        self.thumb_cards[pos].refresh(crop, pixmap, selected=(pos == self.selected_pos))

    def refresh_crop_visuals(self, pos: int) -> None:
        if not (0 <= pos < len(self.crops)):
            return
        self.refresh_thumbnail_card(pos)
        self.table_controller.refresh_row_color(pos)
        self.canvas.update_crop_item(pos)
        self.update_info_text()

    def keep_zoom_enabled(self) -> bool:
        action = getattr(self, "action_keep_zoom", None)
        return bool(action is not None and action.isChecked())

    def select_crop(self, pos: int, *, focus: bool) -> None:
        if not (0 <= pos < len(self.crops)):
            return
        old_pos = self.selected_pos
        if old_pos == pos:
            if focus:
                self.canvas.focus_on_crop(self.crops[pos], preserve_zoom=self.keep_zoom_enabled())
            self.ensure_selected_thumbnail_visible()
            self.statusBar().showMessage(f"Selected crop #{self.crops[pos].index}")
            return

        self.selected_pos = pos
        self.table_controller.set_current_cell(pos, 2)

        if old_pos is not None:
            self.table_controller.refresh_row_color(old_pos)
            if 0 <= old_pos < len(self.thumb_cards):
                self.thumb_cards[old_pos].update_style(False)
        self.table_controller.refresh_row_color(pos)
        if 0 <= pos < len(self.thumb_cards):
            self.thumb_cards[pos].update_style(True)
        self.canvas.set_selected_pos(old_pos, pos)
        self.ensure_selected_thumbnail_visible()
        if focus:
            self.canvas.focus_on_crop(self.crops[pos], preserve_zoom=self.keep_zoom_enabled())
        self.statusBar().showMessage(f"Selected crop #{self.crops[pos].index}")

    def set_crop_rect(self, pos: int, rect: QRectF, *, refresh_thumbnail: bool, update_canvas_item: bool = True) -> None:
        if self.image is None or not (0 <= pos < len(self.crops)):
            return
        rect = clamp_rect_to_image(rect, self.image.size())
        self.crops[pos].set_rect(rect)
        if update_canvas_item:
            self.canvas.update_crop_item(pos)
        if refresh_thumbnail:
            self.refresh_crop_visuals(pos)

    def set_crop_points(self, pos: int, points: Any, *, refresh_thumbnail: bool, update_canvas_item: bool = True) -> None:
        if self.image is None or not (0 <= pos < len(self.crops)):
            return
        cleaned = constrain_points_to_image_by_translation(clean_points(points), self.image.size())
        self.crops[pos].set_points(cleaned)
        if update_canvas_item:
            self.canvas.update_crop_item(pos)
        if refresh_thumbnail:
            self.refresh_crop_visuals(pos)

    # ----- Clipboard helpers -----

    @staticmethod
    def _is_cmd_copy_event(event: object) -> bool:
        """Return True for Cmd/Ctrl+C without Alt/Shift modifiers."""
        try:
            mods = event.modifiers()  # type: ignore[attr-defined]
            return (
                event.key() == Qt.Key.Key_C  # type: ignore[attr-defined]
                and bool(mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier))
                and not bool(mods & (Qt.KeyboardModifier.AltModifier | Qt.KeyboardModifier.ShiftModifier))
            )
        except Exception:
            return False

    @staticmethod
    def _thumbnail_friendly_clipboard_image(crop_image: QImage) -> QImage:
        """Return a padded square copy so chat/app thumbnails show the full crop.

        Some apps display pasted images in square-ish attachment previews using
        a center-crop/cover rule. Very wide handwriting crops can therefore look
        zoomed into only one section even though the full image is preserved when
        opened. Padding the crop onto a square white canvas makes those previews
        show the entire crop instead of cropping the preview.
        """
        if crop_image.isNull():
            return crop_image

        src = crop_image.convertToFormat(QImage.Format.Format_RGB888)
        src_w = max(1, int(src.width()))
        src_h = max(1, int(src.height()))

        base_side = max(src_w, src_h)
        margin = max(12, int(round(base_side * 0.08)))
        canvas_side = base_side + 2 * margin

        # Keep clipboard images reasonably sized while avoiding unnecessary
        # downsampling for normal small crops.
        max_canvas_side = 2048
        scale = min(1.0, float(max_canvas_side) / float(canvas_side))
        draw_w = max(1, int(round(src_w * scale)))
        draw_h = max(1, int(round(src_h * scale)))
        out_side = max(1, int(round(canvas_side * scale)))

        out = QImage(out_side, out_side, QImage.Format.Format_RGB888)
        out.fill(QColor(255, 255, 255))

        painter = QPainter(out)
        painter.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform, True)
        target = QRect((out_side - draw_w) // 2, (out_side - draw_h) // 2, draw_w, draw_h)
        painter.drawImage(target, src)
        painter.end()
        return out

    def copy_selected_crop_to_clipboard(self) -> bool:
        """Copy the selected crop image to the system clipboard.

        This is intended for Cmd/Ctrl+C when selection is on the main canvas or
        thumbnail list. Text fields keep their normal copy behavior because the
        event filter only calls this when focus is not in a QLineEdit. The copied
        image is padded to a square canvas so attachment thumbnails in chat apps
        show the full crop instead of zooming/cropping the preview.
        """
        if self.image is None or self.image.isNull():
            QApplication.beep()
            self.statusBar().showMessage("No image loaded to copy")
            return False
        if self.selected_pos is None or not (0 <= self.selected_pos < len(self.crops)):
            QApplication.beep()
            self.statusBar().showMessage("No crop selected to copy")
            return False

        crop = self.crops[self.selected_pos]
        try:
            crop_image = warped_crop_qimage(self.image, crop.points)
        except Exception:
            crop_image = axis_aligned_crop_qimage(self.image, crop.points)

        if crop_image.isNull():
            QApplication.beep()
            self.statusBar().showMessage(f"Could not copy crop #{crop.index}")
            return False

        clipboard_image = self._thumbnail_friendly_clipboard_image(crop_image)
        QApplication.clipboard().setImage(clipboard_image)
        self.statusBar().showMessage(f"Copied crop #{crop.index} to clipboard with preview padding")
        return True

    # ----- Keyboard / label editing behavior -----

    def eventFilter(self, obj: QObject, event: QEvent) -> bool:  # type: ignore[override]
        if event.type() != QEvent.Type.KeyPress or not self.isActiveWindow():
            return super().eventFilter(obj, event)

        key_event = event  # type: ignore[assignment]

        if LabelLineEdit.is_cmd_s(key_event):  # type: ignore[arg-type]
            self.save_json()
            return True
        if LabelLineEdit.is_cmd_o(key_event):  # type: ignore[arg-type]
            self.choose_json()
            return True

        # When SymbolPopup is open, only intercept Cmd+I so it can toggle/close
        # the popup. Let arrows, Enter, Escape, and printable keys continue to
        # the popup's own event filters/widgets instead of restarting label edit.
        if self._symbol_popup_is_visible():
            if LabelLineEdit.is_cmd_i(key_event):  # type: ignore[arg-type]
                self.close_symbol_popup()
                return True
            return False

        focus_widget = QApplication.focusWidget()
        if isinstance(focus_widget, LabelLineEdit):
            if self.table_controller.handle_global_key(key_event):  # type: ignore[arg-type]
                return True
            return super().eventFilter(obj, event)

        if self._text_editor_has_focus():
            # Keep normal QLineEdit editing shortcuts available in find/replace
            # boxes, but still support app-level find/find-again/replace.
            if (
                LabelLineEdit.is_cmd_f(key_event)
                or LabelLineEdit.is_cmd_g(key_event)
                or LabelLineEdit.is_cmd_h(key_event)
            ):  # type: ignore[arg-type]
                return self.table_controller.handle_global_key(key_event)  # type: ignore[arg-type]
            return super().eventFilter(obj, event)

        if self.table_controller.handle_global_key(key_event):  # type: ignore[arg-type]
            return True

        if self.selected_pos is None or not (0 <= self.selected_pos < len(self.crops)):
            return super().eventFilter(obj, event)

        if self._is_cmd_copy_event(key_event):
            return self.copy_selected_crop_to_clipboard()

        if LabelLineEdit.is_cmd_v(key_event):  # type: ignore[arg-type]
            self.table_controller.paste_clipboard_into_selected_label()
            return True

        key = key_event.key()  # type: ignore[attr-defined]
        mods = key_event.modifiers()  # type: ignore[attr-defined]

        if key in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier | Qt.KeyboardModifier.AltModifier)):
            self.table_controller.begin_label_edit(select_all=True)
            return True

        if key in (Qt.Key.Key_Delete, Qt.Key.Key_Backspace):
            self.table_controller.toggle_selected_keep()
            return True

        if key in (Qt.Key.Key_Left, Qt.Key.Key_Right, Qt.Key.Key_Up, Qt.Key.Key_Down):
            self.table_controller.navigate_selection_by_key(key, columns=self.thumb_columns)
            return True

        text = key_event.text()  # type: ignore[attr-defined]
        if text and len(text) == 1 and text.isprintable() and not (mods & (Qt.KeyboardModifier.ControlModifier | Qt.KeyboardModifier.MetaModifier | Qt.KeyboardModifier.AltModifier)):
            self.table_controller.begin_label_edit(initial_text=text, select_all=False)
            return True

        return super().eventFilter(obj, event)

    def _symbol_popup_is_visible(self) -> bool:
        popup = self.symbol_popup
        return popup is not None and popup.isVisible()

    def close_symbol_popup(self) -> None:
        popup = self.symbol_popup
        if popup is not None and popup.isVisible():
            popup.close()
        else:
            self.symbol_popup = None

    def on_symbol_popup_closed(self) -> None:
        self.symbol_popup = None
        if self._app_is_closing or not self._symbol_popup_restore_on_close:
            self._symbol_popup_restore_on_close = False
            return
        self._symbol_popup_restore_on_close = False
        self.restore_label_editor_after_popup_cancel()

    def restore_label_editor_after_popup_cancel(self) -> None:
        row = self.symbol_popup_row
        if row is None or not (0 <= row < len(self.crops)):
            row = self.selected_pos
        if row is None or not (0 <= row < len(self.crops)):
            return

        item = self.table.item(row, 2)
        text = self.symbol_popup_text
        if text == "" and item is not None:
            text = item.text()
        cursor_pos = max(0, min(int(self.symbol_popup_cursor_pos), len(text)))
        selection_start = int(self.symbol_popup_selection_start)
        selection_length = max(0, int(self.symbol_popup_selection_length))

        # Preserve any uncommitted text that existed when Cmd+I opened the
        # popup. Qt may delete/commit the delegate editor when focus moves into
        # a Qt.Popup, so restoring from the saved text prevents a cancel from
        # losing the in-progress label. Do not add a separate undo action here:
        # this is focus restoration, not a new user edit.
        self.table_controller.set_label_text(row, text, record_undo=False, refresh=True)
        self.selected_pos = row

        def reopen_editor() -> None:
            if not (0 <= row < len(self.crops)):
                return
            item2 = self.table.item(row, 2)
            if item2 is None:
                return
            self.table.setFocus(Qt.FocusReason.PopupFocusReason)
            self.table.setCurrentCell(row, 2)
            self.table.editItem(item2)

            def restore_cursor_or_selection() -> None:
                fw = QApplication.focusWidget()
                if isinstance(fw, QLineEdit):
                    fw.setFocus(Qt.FocusReason.PopupFocusReason)
                    if selection_start >= 0 and selection_length > 0:
                        start = max(0, min(selection_start, len(fw.text())))
                        length = max(0, min(selection_length, len(fw.text()) - start))
                        fw.setSelection(start, length)
                    else:
                        fw.setCursorPosition(max(0, min(cursor_pos, len(fw.text()))))
                    self.active_label_editor = fw
                    try:
                        self.symbol_popup_row = int(fw.property("row"))
                    except Exception:
                        self.symbol_popup_row = row

            QTimer.singleShot(0, restore_cursor_or_selection)

        QTimer.singleShot(0, reopen_editor)

    def _text_editor_has_focus(self) -> bool:
        fw = QApplication.focusWidget()
        return isinstance(fw, QLineEdit)

    def show_symbol_popup_for_editor(self, editor: object) -> None:
        if SymbolPopup is None:
            QMessageBox.warning(
                self,
                "Symbol popup unavailable",
                "Could not import SymbolPopup_v9_focus_restore.py. Keep it in the same folder as this script.",
            )
            return
        if not isinstance(editor, QLineEdit):
            return

        try:
            row = int(editor.property("row"))
        except Exception:
            row = int(self.selected_pos) if self.selected_pos is not None else -1
        if not (0 <= row < len(self.crops)):
            return

        # Do not capture the delegate editor in the popup callback. Opening a
        # Qt.Popup usually moves focus to the popup search box, and the table's
        # delegate editor may be committed/deleted before the user clicks a
        # symbol. Store the row/text/cursor instead, then insert into the row.
        self.active_label_editor = editor
        self.symbol_popup_row = row
        self.symbol_popup_text = editor.text()
        self.symbol_popup_cursor_pos = editor.cursorPosition()
        self.symbol_popup_selection_start = editor.selectionStart()
        self.symbol_popup_selection_length = len(editor.selectedText())

        if self.symbol_popup is not None and self.symbol_popup.isVisible():
            self.close_symbol_popup()
            return

        self._symbol_popup_restore_on_close = True
        self.symbol_popup = SymbolPopup(
            insert_callback=self.insert_symbol_from_popup,
            parent=self,
        )
        try:
            self.symbol_popup.closed.connect(self.on_symbol_popup_closed)
        except Exception:
            pass
        global_pos = editor.mapToGlobal(QPoint(0, editor.height()))
        self.symbol_popup.move(global_pos)
        self.symbol_popup.resize(max(420, editor.width()), self.symbol_popup.sizeHint().height())
        self.symbol_popup.show()
        self.symbol_popup.search_box.setFocus()

    def insert_symbol_from_popup(self, symbol: str) -> None:
        # A symbol selection has its own refocus path below. Do not also run
        # the cancel/close refocus path from the popup's closed signal.
        self._symbol_popup_restore_on_close = False
        row = self.symbol_popup_row
        if row is None or not (0 <= row < len(self.crops)):
            row = self.selected_pos
        if row is None or not (0 <= row < len(self.crops)):
            return

        editor = self.active_label_editor
        editor_alive = isinstance(editor, QLineEdit) and not qt_object_is_deleted(editor)

        if editor_alive:
            try:
                text = editor.text()
                cursor_pos = editor.cursorPosition()
                selection_start = editor.selectionStart()
                selection_length = len(editor.selectedText())
            except RuntimeError:
                editor_alive = False

        if not editor_alive:
            # Prefer the stored editor text from the moment Cmd+I opened the
            # popup. It includes uncommitted edits even if the delegate editor
            # was deleted when focus moved into the popup.
            text = self.symbol_popup_text
            cursor_pos = self.symbol_popup_cursor_pos
            selection_start = self.symbol_popup_selection_start
            selection_length = self.symbol_popup_selection_length
            item = self.table.item(row, 2)
            if not text and item is not None:
                text = item.text()

        cursor_pos = max(0, min(int(cursor_pos), len(text)))
        if selection_start is not None and int(selection_start) >= 0 and selection_length > 0:
            start = max(0, min(int(selection_start), len(text)))
            end = max(start, min(start + int(selection_length), len(text)))
            new_text = text[:start] + symbol + text[end:]
            new_cursor_pos = start + len(symbol)
        else:
            new_text = text[:cursor_pos] + symbol + text[cursor_pos:]
            new_cursor_pos = cursor_pos + len(symbol)

        self.table_controller.set_label_text(row, new_text)
        self.refresh_crop_visuals(row)
        self.selected_pos = row

        def reopen_editor() -> None:
            if not (0 <= row < len(self.crops)):
                return
            item2 = self.table.item(row, 2)
            if item2 is None:
                return
            self.table.setFocus(Qt.FocusReason.PopupFocusReason)
            self.table.setCurrentCell(row, 2)
            self.table.editItem(item2)

            def place_cursor() -> None:
                fw = QApplication.focusWidget()
                if isinstance(fw, QLineEdit):
                    fw.setCursorPosition(max(0, min(new_cursor_pos, len(fw.text()))))
                    fw.setFocus(Qt.FocusReason.PopupFocusReason)
                    self.active_label_editor = fw
                    try:
                        self.symbol_popup_row = int(fw.property("row"))
                    except Exception:
                        self.symbol_popup_row = row

            QTimer.singleShot(0, place_cursor)

        # SymbolPopup closes immediately after the callback. Re-open/refocus the
        # table editor on the next event cycle so focus does not bounce back into
        # the closing popup.
        QTimer.singleShot(0, reopen_editor)

    # ----- Misc -----

    def update_actions(self) -> None:
        can_request_detection = (
            self.image_file is not None
            and not self.detect_busy
            and (self.craft_ready or self.craft_loading or self.craft_process is None)
        )
        parseq_predict_busy = self.parseq_predict_worker is not None and self.parseq_predict_worker.isRunning()
        parseq_load_busy = self.parseq_load_worker is not None and self.parseq_load_worker.isRunning()
        self.run_craft_btn.setEnabled(can_request_detection and not parseq_predict_busy)
        self.export_json_btn.setEnabled(self.image_file is not None and not parseq_predict_busy)
        self.load_parseq_btn.setEnabled(not parseq_predict_busy and not parseq_load_busy)
        self.fill_parseq_btn.setEnabled(
            self.image_file is not None
            and bool(self.crops)
            and not parseq_predict_busy
        )
        self.overwrite_parseq_labels_checkbox.setEnabled(not parseq_predict_busy)
        for name, enabled in (
            ("action_rerun_craft", can_request_detection and not parseq_predict_busy),
            ("action_export_json", self.image_file is not None and not parseq_predict_busy),
            ("action_save_json", self.image_file is not None and not parseq_predict_busy),
            ("action_load_parseq", not parseq_predict_busy and not parseq_load_busy),
            ("action_set_parseq_repo", not parseq_predict_busy and not parseq_load_busy),
            ("action_fill_labels", self.image_file is not None and bool(self.crops) and not parseq_predict_busy),
            ("action_fit_image", self.image_file is not None),
            ("action_keep_zoom", self.image_file is not None),
        ):
            action = getattr(self, name, None)
            if action is not None:
                action.setEnabled(bool(enabled))

    def closeEvent(self, event) -> None:  # type: ignore[override]
        if not self.confirm_quit_if_unexported():
            event.ignore()
            return

        self._app_is_closing = True
        self._symbol_popup_restore_on_close = False

        if self.parseq_predict_worker is not None and self.parseq_predict_worker.isRunning():
            self.parseq_predict_worker.cancel()
            self.parseq_predict_worker.wait(2000)
        if self.parseq_load_worker is not None and self.parseq_load_worker.isRunning():
            self.parseq_load_worker.wait(3000)
            if self.parseq_load_worker.isRunning():
                self.parseq_load_worker.terminate()
                self.parseq_load_worker.wait(1000)
        if self.symbol_popup is not None:
            self.symbol_popup.close()
        if self.craft_process is not None:
            self._send_craft_request({"type": "shutdown"})
            self.craft_process.closeWriteChannel()
            if not self.craft_process.waitForFinished(1000):
                self.craft_process.kill()
                self.craft_process.waitForFinished(1000)
            self.craft_process = None
        super().closeEvent(event)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> int:
    app = QApplication(sys.argv)
    win = MainWindow()
    win.show()

    # Optional positional argument: image or JSON.
    if len(sys.argv) > 1:
        path = Path(sys.argv[1]).expanduser()
        if path.suffix.lower() == ".json":
            QTimer.singleShot(0, lambda: win.load_json(path))
        elif path.suffix.lower() in IMAGE_SUFFIXES:
            QTimer.singleShot(0, lambda: win.load_image(path, auto_detect=True, clear_crops=True))

    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
