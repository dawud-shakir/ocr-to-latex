#!/usr/bin/env python3
from __future__ import annotations

import csv
import json
import math
import os
import re
import sys
import traceback
import importlib.util
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any, Iterable

from PIL import Image, ImageOps

from PyQt6.QtCore import Qt, QThread, pyqtSignal
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QFileDialog,
    QFormLayout,
    QGridLayout,
    QGroupBox,
    QHeaderView,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMainWindow,
    QMessageBox,
    QProgressBar,
    QPushButton,
    QSpinBox,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)


APP_TITLE = "PARSeq Label Evaluator"
DEFAULT_PARSEQ_REPO = Path("/Users/macintosh/UNM/Demos/ocr-to-latex/code/parseq/")
DEFAULT_CHECKPOINT_PATH = Path(
    "/Users/macintosh/Library/CloudStorage/GoogleDrive-dsshakir@gmail.com/My Drive/Parseq/Training/"
    "total occurances_5_41/runs/2026-05-29_04-32-58/checkpoints/last.ckpt"
)
DEFAULT_JSON_DIR = Path("/Users/macintosh/UNM/Demos/ocr-to-latex/data/LaTeX version/")

PRETRAINED_MODELS = {
    "parseq-tiny": "parseq_tiny",
    "parseq": "parseq",
    "parseq-patch16-224": "parseq_patch16_224",
}


@dataclass(frozen=True)
class EvalParams:
    json_path: Path
    image_override: Path | None
    repo_path: Path | None
    model_source: str
    pretrained_name: str
    checkpoint_path: Path | None
    device_choice: str
    batch_size: int
    margin_percent: float
    ignore_spaces: bool
    case_insensitive: bool


@dataclass
class CropSample:
    index: int
    label: str
    points: list[tuple[float, float]]
    crop: Image.Image
    json_path: Path
    image_path: Path


@dataclass
class EvalRow:
    index: int
    label: str
    prediction: str
    exact: bool
    ned: float
    edit_distance: int
    confidence: float | None
    crop: Image.Image
    json_path: Path
    image_path: Path
    error: str = ""


def levenshtein(a: str, b: str) -> int:
    if a == b:
        return 0
    if not a:
        return len(b)
    if not b:
        return len(a)
    if len(a) < len(b):
        a, b = b, a

    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a, 1):
        cur = [i]
        for j, cb in enumerate(b, 1):
            insert_cost = cur[j - 1] + 1
            delete_cost = prev[j] + 1
            replace_cost = prev[j - 1] + (ca != cb)
            cur.append(min(insert_cost, delete_cost, replace_cost))
        prev = cur
    return prev[-1]


def ned_score(label: str, prediction: str) -> tuple[float, int]:
    ed = levenshtein(label, prediction)
    denom = max(len(label), len(prediction), 1)
    return max(0.0, 1.0 - (ed / denom)), ed


def normalize_for_compare(text: str, ignore_spaces: bool, case_insensitive: bool) -> str:
    if ignore_spaces:
        text = re.sub(r"\s+", "", text)
    if case_insensitive:
        text = text.lower()
    return text


def distance(p: tuple[float, float], q: tuple[float, float]) -> float:
    return math.hypot(p[0] - q[0], p[1] - q[1])


def expand_quad(points: list[tuple[float, float]], margin_percent: float) -> list[tuple[float, float]]:
    if margin_percent <= 0:
        return points
    scale = 1.0 + (margin_percent / 100.0)
    cx = sum(p[0] for p in points) / len(points)
    cy = sum(p[1] for p in points) / len(points)
    return [(cx + (x - cx) * scale, cy + (y - cy) * scale) for x, y in points]


def crop_from_points(image: Image.Image, points: list[tuple[float, float]], margin_percent: float = 0.0) -> Image.Image:
    if len(points) == 4:
        pts = expand_quad(points, margin_percent)

        width = max(distance(pts[0], pts[1]), distance(pts[3], pts[2]))
        height = max(distance(pts[0], pts[3]), distance(pts[1], pts[2]))
        out_w = max(1, int(round(width)))
        out_h = max(1, int(round(height)))

        quad_for_pil = [pts[0], pts[3], pts[2], pts[1]]
        data = tuple(v for point in quad_for_pil for v in point)

        return image.transform(
            (out_w, out_h),
            Image.Transform.QUAD,
            data,
            resample=Image.Resampling.BICUBIC,
        ).convert("RGB")

    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    x0, y0, x1, y1 = min(xs), min(ys), max(xs), max(ys)

    if margin_percent > 0:
        dx = (x1 - x0) * margin_percent / 100.0
        dy = (y1 - y0) * margin_percent / 100.0
        x0, y0, x1, y1 = x0 - dx, y0 - dy, x1 + dx, y1 + dy

    return image.crop((math.floor(x0), math.floor(y0), math.ceil(x1), math.ceil(y1))).convert("RGB")


def parse_points(crop_entry: dict[str, Any]) -> list[tuple[float, float]]:
    if "points" in crop_entry:
        raw = crop_entry["points"]
        points = [(float(p[0]), float(p[1])) for p in raw]
        if len(points) < 2:
            raise ValueError("points must contain at least 2 points")
        return points

    for key in ("bbox", "box", "rect"):
        if key in crop_entry:
            raw = crop_entry[key]
            if len(raw) == 4:
                x, y, w, h = [float(v) for v in raw]
                return [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]

    raise ValueError("crop entry needs either 'points' or a 4-value bbox/box/rect")


def resolve_image_path(json_path: Path, image_ref: str, image_override: Path | None) -> Path:
    if image_override is not None:
        return image_override.expanduser().resolve()

    raw = Path(image_ref).expanduser()
    candidates = []
    if raw.is_absolute():
        candidates.append(raw)
    else:
        candidates.extend(
            [
                json_path.parent / raw,
                json_path.parent / raw.name,
                json_path.parent / "images" / raw.name,
                json_path.parent.parent / raw.name,
            ]
        )

    for candidate in candidates:
        if candidate.exists():
            return candidate.resolve()

    tried = "\n".join(f"  - {p}" for p in candidates)
    raise FileNotFoundError(f"Could not find image '{image_ref}'. Tried:\n{tried}")


def resolve_json_paths(path: Path) -> list[Path]:
    path = path.expanduser()
    if path.is_file():
        if path.suffix.lower() != ".json":
            raise ValueError("Choose a .json label file or a folder containing .json files.")
        return [path.resolve()]

    if path.is_dir():
        json_paths = sorted(
            (child.resolve() for child in path.iterdir() if child.is_file() and child.suffix.lower() == ".json"),
            key=lambda p: p.name.lower(),
        )
        if not json_paths:
            raise ValueError(f"Folder contains no top-level .json files: {path}")
        return json_paths

    raise FileNotFoundError("Choose a valid JSON label file or folder.")


def load_samples_from_json(
    json_path: Path,
    image_override: Path | None,
    margin_percent: float,
) -> tuple[list[CropSample], Path]:
    json_path = json_path.expanduser().resolve()
    with json_path.open("r", encoding="utf-8") as f:
        payload = json.load(f)

    crops_data = payload.get("crops")
    if not isinstance(crops_data, list):
        raise ValueError("JSON must contain a top-level 'crops' list")

    image_ref = str(payload.get("image", "")).strip()
    if not image_ref and image_override is None:
        raise ValueError("JSON has no top-level 'image'. Choose an image override.")

    image_path = resolve_image_path(json_path, image_ref, image_override)
    image = ImageOps.exif_transpose(Image.open(image_path)).convert("RGB")

    samples: list[CropSample] = []
    for row_num, entry in enumerate(crops_data, 1):
        if not isinstance(entry, dict):
            continue
        label = str(entry.get("label", ""))
        idx = int(entry.get("index", row_num))
        points = parse_points(entry)
        crop = crop_from_points(image, points, margin_percent)
        samples.append(
            CropSample(
                index=idx,
                label=label,
                points=points,
                crop=crop,
                json_path=json_path,
                image_path=image_path,
            )
        )

    if not samples:
        raise ValueError("No valid crop entries were found in the JSON file.")

    return samples, image_path


def load_samples(params: EvalParams) -> tuple[list[CropSample], dict[str, Any]]:
    json_paths = resolve_json_paths(params.json_path)

    all_samples: list[CropSample] = []
    per_json_counts: dict[str, int] = {}
    image_paths: dict[str, str] = {}

    for json_path in json_paths:
        try:
            samples, image_path = load_samples_from_json(json_path, params.image_override, params.margin_percent)
        except Exception as exc:
            raise RuntimeError(f"Failed loading {json_path}: {exc}") from exc
        all_samples.extend(samples)
        per_json_counts[str(json_path)] = len(samples)
        image_paths[str(json_path)] = str(image_path)

    if not all_samples:
        raise ValueError("No valid crop entries were found.")

    info = {
        "json_paths": [str(p) for p in json_paths],
        "json_count": len(json_paths),
        "per_json_counts": per_json_counts,
        "image_paths": image_paths,
        "input_path": str(params.json_path.expanduser().resolve()),
    }
    return all_samples, info


def confidence_to_float(value: Any) -> float | None:
    if value is None:
        return None

    try:
        import torch

        if isinstance(value, torch.Tensor):
            value = value.detach().float().cpu()
            if value.numel() == 0:
                return None
            return float(value.mean().item())
    except Exception:
        pass

    if isinstance(value, (list, tuple)):
        vals = [confidence_to_float(v) for v in value]
        vals = [v for v in vals if v is not None]
        return float(mean(vals)) if vals else None

    try:
        return float(value)
    except Exception:
        return None


def hparam(model: Any, name: str, default: Any = None) -> Any:
    hp = getattr(model, "hparams", None)
    if isinstance(hp, dict):
        return hp.get(name, default)
    return getattr(hp, name, default)


def _path_is_relative_to(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except Exception:
        return False


def _looks_like_parseq_repo(path: Path) -> bool:
    path = path.expanduser()
    return (path / "strhub").is_dir() and (path / "strhub" / "models").is_dir()


def _purge_imported_strhub_if_not_from(repo: Path) -> None:
    loaded = sys.modules.get("strhub")
    if loaded is None:
        return
    loaded_file = getattr(loaded, "__file__", None)
    if not loaded_file:
        return
    try:
        loaded_path = Path(str(loaded_file)).resolve()
    except Exception:
        return
    if _path_is_relative_to(loaded_path, repo):
        return

    for name in list(sys.modules):
        if name == "strhub" or name.startswith("strhub."):
            sys.modules.pop(name, None)


def _imported_strhub_path() -> str:
    loaded = sys.modules.get("strhub")
    loaded_file = getattr(loaded, "__file__", None) if loaded is not None else None
    if loaded_file:
        return str(loaded_file)
    spec = importlib.util.find_spec("strhub")
    origin = getattr(spec, "origin", None) if spec is not None else None
    return str(origin) if origin else "not found"


def add_parseq_repo_to_path(repo_path: Path | None, *, authoritative: bool = False) -> str:
    """Put the selected PARSeq repo first and optionally purge stale strhub modules."""
    if repo_path is None:
        return "none selected"
    repo = repo_path.expanduser().resolve()
    if not repo.exists():
        raise FileNotFoundError(f"PARSeq repo folder does not exist: {repo}")
    if not _looks_like_parseq_repo(repo):
        raise FileNotFoundError(f"PARSeq repo folder does not look valid; missing strhub/: {repo}")

    repo_str = str(repo)
    sys.path[:] = [p for p in sys.path if p != repo_str]
    sys.path.insert(0, repo_str)
    os.environ["PARSEQ_REPO"] = repo_str
    if authoritative:
        _purge_imported_strhub_if_not_from(repo)
    return repo_str


def ensure_strhub_importable(torch_module: Any, repo_path: Path | None, *, authoritative: bool = False) -> str:
    repo_summary = add_parseq_repo_to_path(repo_path, authoritative=authoritative) if repo_path is not None else "none selected"

    try:
        import strhub  # noqa: F401
        return _imported_strhub_path()
    except ModuleNotFoundError:
        pass

    hub_dir = Path(torch_module.hub.get_dir()).expanduser()
    for candidate in hub_dir.glob("baudm_parseq*"):
        if (candidate / "strhub").is_dir() and str(candidate) not in sys.path:
            sys.path.insert(0, str(candidate))

    import strhub  # noqa: F401
    return _imported_strhub_path() if repo_summary == "none selected" else repo_summary


def load_pretrained_model(torch_module: Any, hub_id: str) -> Any:
    try:
        return torch_module.hub.load("baudm/parseq", hub_id, pretrained=True, trust_repo=True)
    except TypeError:
        return torch_module.hub.load("baudm/parseq", hub_id, pretrained=True)


def load_empty_architecture(torch_module: Any, arch_name: str) -> Any:
    hub_id = PRETRAINED_MODELS[arch_name]
    try:
        return torch_module.hub.load("baudm/parseq", hub_id, pretrained=False, trust_repo=True)
    except TypeError:
        return torch_module.hub.load("baudm/parseq", hub_id, pretrained=False)


def clean_state_dict_keys(state_dict: dict[str, Any]) -> dict[str, Any]:
    cleaned = {}
    for key, value in state_dict.items():
        new_key = key
        for prefix in ("model.", "module."):
            if new_key.startswith(prefix):
                new_key = new_key[len(prefix) :]
        cleaned[new_key] = value
    return cleaned


def _checkpoint_hparams(obj: Any) -> dict[str, Any]:
    if not isinstance(obj, dict):
        return {}
    for key in ("hyper_parameters", "hparams", "hparams_name", "cfg", "config"):
        value = obj.get(key)
        if isinstance(value, dict):
            return value
    return {}


def _extract_state_dict(obj: Any) -> dict[str, Any]:
    if isinstance(obj, dict) and "state_dict" in obj and isinstance(obj["state_dict"], dict):
        return obj["state_dict"]
    if isinstance(obj, dict):
        return obj
    raise TypeError("checkpoint is not a state_dict-like object")


def _find_text_in_hparams(value: Any) -> str:
    if isinstance(value, dict):
        return " ".join(_find_text_in_hparams(v) for v in value.values())
    if isinstance(value, (list, tuple)):
        return " ".join(_find_text_in_hparams(v) for v in value)
    return str(value)


def infer_raw_architecture(torch_module: Any, checkpoint_path: Path, obj: Any | None = None) -> str:
    """Infer which stock PARSeq architecture should receive raw .pt/.pth weights."""
    checkpoint_path = checkpoint_path.expanduser().resolve()
    if obj is None:
        obj = torch_module.load(str(checkpoint_path), map_location="cpu")

    hp_text = _find_text_in_hparams(_checkpoint_hparams(obj)).lower()
    filename = checkpoint_path.name.lower()
    combined = f"{filename} {hp_text}"

    if "parseq-patch16-224" in combined or "patch16_224" in combined or "patch16-224" in combined:
        return "parseq-patch16-224"
    if "parseq-tiny" in combined or "parseq_tiny" in combined:
        return "parseq-tiny"
    if re.search(r"\bparseq\b", combined):
        return "parseq"

    state_dict = clean_state_dict_keys(_extract_state_dict(obj))

    # Patch-16 checkpoints usually expose a 16x16 patch embedding kernel.
    for key, tensor in state_dict.items():
        if key.endswith("patch_embed.proj.weight") and hasattr(tensor, "shape"):
            shape = tuple(int(x) for x in tensor.shape)
            if len(shape) >= 4 and shape[-1] == 16 and shape[-2] == 16:
                return "parseq-patch16-224"

    # Tiny models normally have a smaller transformer width.
    for key in ("pos_queries", "text_embed.embedding.weight", "decoder.layers.0.self_attn.in_proj_weight"):
        tensor = state_dict.get(key)
        if tensor is not None and hasattr(tensor, "shape"):
            shape = tuple(int(x) for x in tensor.shape)
            embed_dim = shape[-1] if key != "decoder.layers.0.self_attn.in_proj_weight" else shape[1]
            if embed_dim <= 256:
                return "parseq-tiny"
            return "parseq"

    return "parseq"


def describe_parseq_tokenizer(model: Any) -> str:
    tokenizer = getattr(model, "tokenizer", None)
    if tokenizer is None:
        return "tokenizer=none"

    pieces = [f"tokenizer={type(tokenizer).__name__}"]
    try:
        pieces.append(f"vocab={len(tokenizer)}")
    except Exception:
        pass

    hp = getattr(model, "hparams", None)
    tokenizer_type = None
    if hp is not None:
        try:
            tokenizer_type = hp.get("tokenizer_type", None)
        except Exception:
            tokenizer_type = getattr(hp, "tokenizer_type", None)
    if tokenizer_type is not None:
        pieces.append(f"tokenizer_type={tokenizer_type}")

    latex_tokens = getattr(tokenizer, "latex_tokens", None)
    if latex_tokens is not None:
        try:
            token_list = [str(x) for x in list(latex_tokens)]
            preview = repr(token_list[:12])
            if len(token_list) > 12:
                preview += "..."
            pieces.append(f"latex_tokens={len(token_list)} {preview}")
        except Exception:
            pieces.append("latex_tokens=?")

    return ", ".join(pieces)


def warn_if_hybrid_checkpoint_looks_unpatched(model: Any) -> str | None:
    hp = getattr(model, "hparams", None)
    tokenizer_type = None
    if hp is not None:
        try:
            tokenizer_type = hp.get("tokenizer_type", None)
        except Exception:
            tokenizer_type = getattr(hp, "tokenizer_type", None)

    tokenizer = getattr(model, "tokenizer", None)
    tokenizer_name = type(tokenizer).__name__ if tokenizer is not None else "none"
    if str(tokenizer_type) == "latex_hybrid" and "Hybrid" not in tokenizer_name:
        return (
            "Checkpoint hparams say tokenizer_type=latex_hybrid, but the loaded tokenizer is "
            f"{tokenizer_name}. Make sure the PARSeq repo folder is the patched repo."
        )
    return None


def _load_raw_state_dict_model(torch_module: Any, checkpoint_path: Path, obj: Any, info: dict[str, Any]) -> Any:
    arch_name = infer_raw_architecture(torch_module, checkpoint_path, obj)
    info["raw_architecture"] = arch_name
    info["loader"] = "raw state_dict fallback"

    model = load_empty_architecture(torch_module, arch_name)
    model_state = model.state_dict()
    raw_state = clean_state_dict_keys(_extract_state_dict(obj))

    compatible: dict[str, Any] = {}
    skipped_shape: list[str] = []
    unexpected: list[str] = []
    for key, value in raw_state.items():
        if key not in model_state:
            unexpected.append(key)
            continue
        if hasattr(value, "shape") and hasattr(model_state[key], "shape") and tuple(value.shape) != tuple(model_state[key].shape):
            skipped_shape.append(key)
            continue
        compatible[key] = value

    missing, unexpected_from_load = model.load_state_dict(compatible, strict=False)
    info["missing"] = len(missing)
    info["unexpected"] = len(unexpected) + len(unexpected_from_load)
    info["skipped_shape"] = len(skipped_shape)

    if skipped_shape:
        info["warning"] = (
            f"Raw weights had {len(skipped_shape)} tensor shape mismatch(es), so those layers were skipped. "
            "For Lightning .ckpt files, use checkpoint mode/direct PARSeq.load_from_checkpoint instead."
        )
    return model


def load_checkpoint_model(torch_module: Any, checkpoint_path: Path, repo_path: Path | None) -> tuple[Any, dict[str, Any]]:
    checkpoint_path = checkpoint_path.expanduser().resolve()
    info: dict[str, Any] = {}

    if repo_path is not None:
        repo = add_parseq_repo_to_path(repo_path, authoritative=True)
        info["parseq_repo"] = repo

    obj: Any | None = None
    try:
        obj = torch_module.load(str(checkpoint_path), map_location="cpu")
    except Exception:
        obj = None

    suffix = checkpoint_path.suffix.lower()
    looks_lightning = isinstance(obj, dict) and "state_dict" in obj and "hyper_parameters" in obj

    if suffix == ".ckpt" or looks_lightning:
        try:
            from strhub.models.parseq.system import PARSeq

            model = PARSeq.load_from_checkpoint(str(checkpoint_path))
            info["loader"] = "PARSeq.load_from_checkpoint"
            info["strhub_source"] = _imported_strhub_path()
            info["tokenizer"] = describe_parseq_tokenizer(model)
            warning = warn_if_hybrid_checkpoint_looks_unpatched(model)
            if warning:
                info["warning"] = warning
            return model, info
        except Exception as exc:
            raise RuntimeError(
                "Could not load the Lightning PARSeq checkpoint with PARSeq.load_from_checkpoint.\n\n"
                "This evaluator intentionally does not fall back to raw state_dict loading for .ckpt files, "
                "because that can silently create a wrong model/tokenizer.\n\n"
                f"strhub source: {_imported_strhub_path()}\n"
                f"Error: {exc}"
            ) from exc

    if obj is None:
        obj = torch_module.load(str(checkpoint_path), map_location="cpu")
    model = _load_raw_state_dict_model(torch_module, checkpoint_path, obj, info)
    info["strhub_source"] = _imported_strhub_path()
    info["tokenizer"] = describe_parseq_tokenizer(model)
    return model, info


def choose_device(torch_module: Any, choice: str) -> str:
    normalized = choice.lower()
    if normalized == "cpu":
        return "cpu"
    if normalized == "cuda":
        if not torch_module.cuda.is_available():
            raise RuntimeError("CUDA was selected, but torch.cuda.is_available() is false.")
        return "cuda"
    if normalized == "mps":
        mps = getattr(torch_module.backends, "mps", None)
        if mps is None or not mps.is_available():
            raise RuntimeError("MPS was selected, but torch.backends.mps.is_available() is false.")
        return "mps"

    if torch_module.cuda.is_available():
        return "cuda"
    mps = getattr(torch_module.backends, "mps", None)
    if mps is not None and mps.is_available():
        return "mps"
    return "cpu"


class EvalWorker(QThread):
    progress = pyqtSignal(int, int)
    status = pyqtSignal(str)
    finished_ok = pyqtSignal(object, object)
    failed = pyqtSignal(str)

    def __init__(self, params: EvalParams) -> None:
        super().__init__()
        self.params = params

    def run(self) -> None:
        try:
            self.status.emit("Loading JSON(s) and crops...")
            samples, data_info = load_samples(self.params)
            json_count = int(data_info.get("json_count", 1))
            self.status.emit(f"Loaded {len(samples)} crop(s) from {json_count} JSON file(s).")
            if self.params.image_override is not None and json_count > 1:
                self.status.emit("Image override is set; the same source image will be used for every JSON file.")

            self.status.emit("Importing torch and loading PARSeq...")
            import torch

            load_info: dict[str, Any] = {}

            hub_id = PRETRAINED_MODELS[self.params.pretrained_name]
            if self.params.model_source == "Pretrained":
                add_parseq_repo_to_path(self.params.repo_path)
                model = load_pretrained_model(torch, hub_id)
                model_name = self.params.pretrained_name
                load_info["loader"] = f"torch.hub pretrained {hub_id}"
                ensure_strhub_importable(torch, self.params.repo_path)
            else:
                if self.params.checkpoint_path is None:
                    raise ValueError("Choose a checkpoint file.")
                model, load_info = load_checkpoint_model(torch, self.params.checkpoint_path, self.params.repo_path)
                model_name = self.params.checkpoint_path.name

            from strhub.data.module import SceneTextDataModule

            device = choose_device(torch, self.params.device_choice)
            model = model.eval().to(device)

            img_size = hparam(model, "img_size", [32, 128])
            load_info["img_size"] = img_size
            if "strhub_source" not in load_info:
                load_info["strhub_source"] = _imported_strhub_path()
            if "tokenizer" not in load_info:
                load_info["tokenizer"] = describe_parseq_tokenizer(model)

            for key in ("loader", "parseq_repo", "strhub_source", "raw_architecture", "tokenizer", "img_size", "warning"):
                value = load_info.get(key)
                if value:
                    self.status.emit(f"{key}: {value}")

            transform = SceneTextDataModule.get_transform(img_size)

            rows: list[EvalRow] = []
            batch_size = max(1, int(self.params.batch_size))

            for start in range(0, len(samples), batch_size):
                batch_samples = samples[start : start + batch_size]
                tensors = [transform(sample.crop) for sample in batch_samples]
                batch = torch.stack(tensors).to(device)

                with torch.inference_mode():
                    logits = model(batch)
                    probs = logits.softmax(-1)
                    decoded = model.tokenizer.decode(probs)

                if isinstance(decoded, tuple):
                    predictions = list(decoded[0])
                    confidences = list(decoded[1]) if len(decoded) > 1 else [None] * len(predictions)
                else:
                    predictions = list(decoded)
                    confidences = [None] * len(predictions)

                for sample, pred_text, conf in zip(batch_samples, predictions, confidences):
                    label_cmp = normalize_for_compare(
                        sample.label,
                        self.params.ignore_spaces,
                        self.params.case_insensitive,
                    )
                    pred_cmp = normalize_for_compare(
                        str(pred_text),
                        self.params.ignore_spaces,
                        self.params.case_insensitive,
                    )
                    ned, ed = ned_score(label_cmp, pred_cmp)
                    rows.append(
                        EvalRow(
                            index=sample.index,
                            label=sample.label,
                            prediction=str(pred_text),
                            exact=label_cmp == pred_cmp,
                            ned=ned,
                            edit_distance=ed,
                            confidence=confidence_to_float(conf),
                            crop=sample.crop,
                            json_path=sample.json_path,
                            image_path=sample.image_path,
                        )
                    )

                self.progress.emit(min(start + batch_size, len(samples)), len(samples))

            summary = {
                "input_path": data_info.get("input_path", ""),
                "json_paths": data_info.get("json_paths", []),
                "json_count": data_info.get("json_count", 1),
                "per_json_counts": data_info.get("per_json_counts", {}),
                "image_paths": data_info.get("image_paths", {}),
                "image_path": next(iter(data_info.get("image_paths", {}).values()), ""),
                "model_name": model_name,
                "device": device,
                "count": len(rows),
                "accuracy": mean([1.0 if row.exact else 0.0 for row in rows]) if rows else 0.0,
                "mean_ned": mean([row.ned for row in rows]) if rows else 0.0,
                "mean_confidence": mean([row.confidence for row in rows if row.confidence is not None])
                if any(row.confidence is not None for row in rows)
                else None,
                "load_info": load_info,
            }
            self.finished_ok.emit(rows, summary)
        except Exception:
            self.failed.emit(traceback.format_exc())


def pil_to_pixmap(image: Image.Image, max_w: int = 400, max_h: int = 260) -> QPixmap:
    img = ImageOps.contain(image.convert("RGB"), (max_w, max_h), Image.Resampling.LANCZOS)
    data = img.tobytes("raw", "RGB")
    qimg = QImage(data, img.width, img.height, img.width * 3, QImage.Format.Format_RGB888)
    return QPixmap.fromImage(qimg.copy())


def natural_sort_key(text: str) -> tuple[tuple[int, int | str], ...]:
    """Return a stable natural-sort key so text_9 sorts before text_10."""
    parts = re.split(r"([0-9]+)", text)
    key: list[tuple[int, int | str]] = []
    for part in parts:
        if not part:
            continue
        if part.isascii() and part.isdecimal():
            key.append((0, int(part)))
        else:
            key.append((1, part.casefold()))
    return tuple(key)


class SortableTableWidgetItem(QTableWidgetItem):
    """QTableWidgetItem with a typed sort value separate from display text.

    Plain QTableWidgetItem sorts by the visible text, which makes numeric text
    sort lexicographically: 1, 10, 100, 1000, 101, 2. This item displays the
    same text to the user but compares a stored int/float/natural-sort key when
    the user clicks a column header.
    """

    def __init__(self, text: str, sort_value: object | None = None) -> None:
        super().__init__(text)
        self.sort_value = natural_sort_key(text) if sort_value is None else sort_value

    def __lt__(self, other: QTableWidgetItem) -> bool:
        left = self.sort_value
        right = getattr(other, "sort_value", natural_sort_key(other.text()))
        try:
            return left < right  # type: ignore[operator]
        except TypeError:
            return str(left) < str(right)


class MainWindow(QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1280, 820)

        self.worker: EvalWorker | None = None
        self.results: list[EvalRow] = []
        self.summary: dict[str, Any] = {}

        self.model_source = QComboBox()
        self.model_source.addItems(["Pretrained", "Checkpoint"])
        self.model_source.setCurrentText("Checkpoint")
        self.pretrained_combo = QComboBox()
        self.pretrained_combo.addItems(PRETRAINED_MODELS.keys())
        self.checkpoint_edit = QLineEdit()
        self.checkpoint_edit.setText(str(DEFAULT_CHECKPOINT_PATH))
        self.checkpoint_browse = QPushButton("Browse...")
        self.repo_edit = QLineEdit()
        self.repo_edit.setText(str(DEFAULT_PARSEQ_REPO))
        self.repo_browse = QPushButton("Browse...")

        self.json_edit = QLineEdit()
        self.json_edit.setText(str(DEFAULT_JSON_DIR))
        self.json_browse = QPushButton("File...")
        self.json_folder_browse = QPushButton("Folder...")
        self.image_edit = QLineEdit()
        self.image_browse = QPushButton("Browse...")

        self.device_combo = QComboBox()
        self.device_combo.addItems(["Auto", "CPU", "MPS", "CUDA"])
        self.batch_spin = QSpinBox()
        self.batch_spin.setRange(1, 512)
        self.batch_spin.setValue(64)
        self.margin_spin = QSpinBox()
        self.margin_spin.setRange(0, 50)
        self.margin_spin.setSuffix("%")
        self.margin_spin.setValue(0)

        self.ignore_spaces = QCheckBox("Ignore spaces for scoring")
        self.case_insensitive = QCheckBox("Case-insensitive scoring")

        self.run_button = QPushButton("Run Evaluation")
        self.export_button = QPushButton("Export CSV")
        self.export_button.setEnabled(False)

        self.progress = QProgressBar()
        self.status_label = QLabel("Ready.")
        self.stats_label = QLabel("Accuracy: —     Mean NED: —     Samples: —")
        self.stats_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)

        self.table = QTableWidget(0, 9)
        self.table.setHorizontalHeaderLabels(["", "JSON", "#", "Label", "Prediction", "Exact", "NED", "ED", "Conf"])
        self.table.verticalHeader().setVisible(True)
        self.table.setSortingEnabled(True)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QTableWidget.SelectionMode.SingleSelection)
        header = self.table.horizontalHeader()
        header.setStretchLastSection(False)
        header.setDefaultSectionSize(120)
        header.setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        header.setSectionResizeMode(5, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(7, QHeaderView.ResizeMode.ResizeToContents)
        header.setSectionResizeMode(8, QHeaderView.ResizeMode.ResizeToContents)

        self.details = QLabel("Select a row to see crop details.")
        self.details.setWordWrap(True)
        self.details.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.details.setStyleSheet("QLabel { padding: 6px; }")

        self.preview = QLabel("Select a row to preview the crop.")
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setMinimumSize(260, 180)
        self.preview.setMaximumSize(420, 280)
        self.preview.setStyleSheet("QLabel { border: 1px solid #c8c8c8; background: #fafafa; }")

        self.log_toggle = QPushButton("Show log")
        self.log_toggle.setCheckable(True)

        self.log = QTextEdit()
        self.log.setReadOnly(True)
        self.log.setMaximumHeight(160)
        self.log.setVisible(False)

        self._build_layout()
        self._connect()
        self._sync_model_source_visibility()

    def _build_layout(self) -> None:
        central = QWidget()
        root = QVBoxLayout(central)

        model_box = QGroupBox("Model")
        model_layout = QGridLayout(model_box)
        model_layout.addWidget(QLabel("Source"), 0, 0)
        model_layout.addWidget(self.model_source, 0, 1)
        model_layout.addWidget(QLabel("Pretrained"), 0, 2)
        model_layout.addWidget(self.pretrained_combo, 0, 3)
        model_layout.addWidget(QLabel("Checkpoint"), 1, 0)
        model_layout.addWidget(self.checkpoint_edit, 1, 1, 1, 2)
        model_layout.addWidget(self.checkpoint_browse, 1, 3)
        model_layout.addWidget(QLabel("PARSeq repo folder"), 2, 0)
        model_layout.addWidget(self.repo_edit, 2, 1, 1, 2)
        model_layout.addWidget(self.repo_browse, 2, 3)

        data_box = QGroupBox("Data")
        data_layout = QGridLayout(data_box)
        data_layout.addWidget(QLabel("JSON file or folder"), 0, 0)
        data_layout.addWidget(self.json_edit, 0, 1)
        data_layout.addWidget(self.json_browse, 0, 2)
        data_layout.addWidget(self.json_folder_browse, 0, 3)
        data_layout.addWidget(QLabel("Image override"), 1, 0)
        data_layout.addWidget(self.image_edit, 1, 1, 1, 2)
        data_layout.addWidget(self.image_browse, 1, 3)

        options_box = QGroupBox("Options")
        options_layout = QHBoxLayout(options_box)
        form = QFormLayout()
        form.addRow("Device", self.device_combo)
        form.addRow("Batch size", self.batch_spin)
        form.addRow("Crop margin", self.margin_spin)
        options_layout.addLayout(form)
        options_layout.addWidget(self.ignore_spaces)
        options_layout.addWidget(self.case_insensitive)
        options_layout.addStretch(1)
        options_layout.addWidget(self.run_button)
        options_layout.addWidget(self.export_button)

        top = QHBoxLayout()
        top.addWidget(model_box, 1)
        top.addWidget(data_box, 1)

        root.addLayout(top)
        root.addWidget(options_box)
        root.addWidget(self.stats_label)
        root.addWidget(self.progress)
        root.addWidget(self.status_label)

        results_splitter = QSplitter(Qt.Orientation.Horizontal)
        results_splitter.addWidget(self.table)

        preview_panel = QWidget()
        preview_layout = QVBoxLayout(preview_panel)
        preview_layout.setContentsMargins(8, 0, 0, 0)
        preview_layout.addWidget(self.details)
        preview_layout.addWidget(self.preview, 0, Qt.AlignmentFlag.AlignHCenter | Qt.AlignmentFlag.AlignTop)
        preview_layout.addStretch(1)

        results_splitter.addWidget(preview_panel)
        results_splitter.setStretchFactor(0, 5)
        results_splitter.setStretchFactor(1, 2)
        results_splitter.setSizes([920, 320])

        root.addWidget(results_splitter, 1)

        log_row = QHBoxLayout()
        log_row.addWidget(self.log_toggle)
        log_row.addStretch(1)
        root.addLayout(log_row)
        root.addWidget(self.log)

        self.setCentralWidget(central)

    def _connect(self) -> None:
        self.model_source.currentTextChanged.connect(self._sync_model_source_visibility)
        self.checkpoint_browse.clicked.connect(self._browse_checkpoint)
        self.repo_browse.clicked.connect(self._browse_repo)
        self.json_browse.clicked.connect(self._browse_json)
        self.json_folder_browse.clicked.connect(self._browse_json_folder)
        self.image_browse.clicked.connect(self._browse_image)
        self.run_button.clicked.connect(self._start_eval)
        self.export_button.clicked.connect(self._export_csv)
        self.log_toggle.toggled.connect(self._toggle_log)
        self.table.itemSelectionChanged.connect(self._update_preview)

    def _toggle_log(self, checked: bool) -> None:
        self.log.setVisible(checked)
        self.log_toggle.setText("Hide log" if checked else "Show log")

    def _sync_model_source_visibility(self) -> None:
        is_checkpoint = self.model_source.currentText() == "Checkpoint"
        for widget in (self.checkpoint_edit, self.checkpoint_browse):
            widget.setEnabled(is_checkpoint)
        self.pretrained_combo.setEnabled(not is_checkpoint)

    def _browse_checkpoint(self) -> None:
        start_dir = str(DEFAULT_CHECKPOINT_PATH.parent if DEFAULT_CHECKPOINT_PATH.parent.exists() else Path.home())
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose PARSeq checkpoint",
            start_dir,
            "Checkpoints (*.ckpt *.pt *.pth);;All files (*)",
        )
        if path:
            self.checkpoint_edit.setText(path)

    def _browse_repo(self) -> None:
        path = QFileDialog.getExistingDirectory(self, "Choose PARSeq repo folder")
        if path:
            self.repo_edit.setText(path)

    def _browse_json(self) -> None:
        start_dir = str(DEFAULT_JSON_DIR if DEFAULT_JSON_DIR.exists() else Path.home())
        path, _ = QFileDialog.getOpenFileName(self, "Choose JSON label file", start_dir, "JSON files (*.json);;All files (*)")
        if path:
            self.json_edit.setText(path)

    def _browse_json_folder(self) -> None:
        start_dir = str(DEFAULT_JSON_DIR if DEFAULT_JSON_DIR.exists() else Path.home())
        path = QFileDialog.getExistingDirectory(self, "Choose folder containing JSON label files", start_dir)
        if path:
            self.json_edit.setText(path)

    def _browse_image(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Choose source image",
            "",
            "Images (*.png *.jpg *.jpeg *.tif *.tiff *.bmp *.webp);;All files (*)",
        )
        if path:
            self.image_edit.setText(path)

    def _append_run_separator(self) -> None:
        if self.log.toPlainText().strip():
            self.log.append("")
        self.log.append("=" * 80)

    def _params_from_ui(self) -> EvalParams:
        if not self.json_edit.text().strip():
            raise FileNotFoundError("Choose a valid JSON label file or folder.")
        json_path = Path(self.json_edit.text()).expanduser()
        if not json_path.exists():
            raise FileNotFoundError("Choose a valid JSON label file or folder.")
        if json_path.is_file() and json_path.suffix.lower() != ".json":
            raise ValueError("Choose a .json label file or a folder containing .json files.")

        image_override = Path(self.image_edit.text()).expanduser() if self.image_edit.text().strip() else None
        if image_override is not None and not image_override.exists():
            raise FileNotFoundError("The image override path does not exist.")

        repo_path = Path(self.repo_edit.text()).expanduser() if self.repo_edit.text().strip() else None
        if repo_path is not None and not repo_path.exists():
            raise FileNotFoundError("The PARSeq repo folder does not exist.")

        checkpoint_path = None
        if self.model_source.currentText() == "Checkpoint":
            checkpoint_path = Path(self.checkpoint_edit.text()).expanduser()
            if not checkpoint_path.exists():
                raise FileNotFoundError("Choose a valid checkpoint file.")

        return EvalParams(
            json_path=json_path,
            image_override=image_override,
            repo_path=repo_path,
            model_source=self.model_source.currentText(),
            pretrained_name=self.pretrained_combo.currentText(),
            checkpoint_path=checkpoint_path,
            device_choice=self.device_combo.currentText(),
            batch_size=int(self.batch_spin.value()),
            margin_percent=float(self.margin_spin.value()),
            ignore_spaces=self.ignore_spaces.isChecked(),
            case_insensitive=self.case_insensitive.isChecked(),
        )

    def _start_eval(self) -> None:
        try:
            params = self._params_from_ui()
        except Exception as exc:
            QMessageBox.warning(self, APP_TITLE, str(exc))
            return

        self.results = []
        self.summary = {}
        self.table.setRowCount(0)
        self.preview.setPixmap(QPixmap())
        self.preview.setText("Evaluation running...")
        self.details.setText("Evaluation running...")
        self.progress.setValue(0)
        self.export_button.setEnabled(False)
        self.run_button.setEnabled(False)
        self.status_label.setText("Starting...")
        self._append_run_separator()
        self.log.append("Run started.")
        self.log.append(f"Input: {params.json_path}")
        self.log.append(f"Model source: {params.model_source}")

        self.worker = EvalWorker(params)
        self.worker.progress.connect(self._on_progress)
        self.worker.status.connect(self._on_status)
        self.worker.finished_ok.connect(self._on_finished)
        self.worker.failed.connect(self._on_failed)
        self.worker.start()

    def _on_status(self, text: str) -> None:
        self.status_label.setText(text)
        self.log.append(text)

    def _on_progress(self, done: int, total: int) -> None:
        self.progress.setMaximum(total)
        self.progress.setValue(done)
        self.status_label.setText(f"Evaluating crops... {done}/{total}")

    def _on_finished(self, rows: object, summary: object) -> None:
        self.results = list(rows)
        self.summary = dict(summary)
        self._fill_table()
        self._update_stats()
        self.run_button.setEnabled(True)
        self.export_button.setEnabled(bool(self.results))
        self.status_label.setText("Done.")
        self.log.append(
            f"Done. Evaluated {self.summary.get('count', len(self.results))} crop(s) "
            f"from {self.summary.get('json_count', 1)} JSON file(s)."
        )
        acc = 100.0 * float(self.summary.get("accuracy", 0.0))
        mean_ned = 100.0 * float(self.summary.get("mean_ned", 0.0))
        conf = self.summary.get("mean_confidence")
        conf_text = "—" if conf is None else f"{100.0 * float(conf):.2f}%"
        self.log.append(
            f"Metrics: accuracy={acc:.2f}%, mean_NED={mean_ned:.2f}%, "
            f"mean_confidence={conf_text}, samples={self.summary.get('count', len(self.results))}"
        )
        self.log.append(f"Input: {self.summary.get('input_path', '')}")
        self.log.append(f"Model: {self.summary.get('model_name', '')} on {self.summary.get('device', '')}")
        load_info = self.summary.get("load_info") or {}
        if isinstance(load_info, dict):
            for key in ("loader", "parseq_repo", "strhub_source", "raw_architecture", "tokenizer", "img_size", "warning"):
                value = load_info.get(key)
                if value:
                    self.log.append(f"{key}: {value}")
        if self.table.rowCount() > 0:
            self.table.selectRow(0)

    def _on_failed(self, message: str) -> None:
        self.run_button.setEnabled(True)
        self.export_button.setEnabled(False)
        self.status_label.setText("Failed.")
        self.preview.setPixmap(QPixmap())
        self.preview.setText("Evaluation failed.")
        self.details.setText("Evaluation failed.")
        self.log_toggle.setChecked(True)
        self._toggle_log(True)
        self.log.append("Run failed.")
        self.log.append(message)
        QMessageBox.critical(self, APP_TITLE, "Evaluation failed. See the log panel for details.")

    def _fill_table(self) -> None:
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(self.results))

        for r, row in enumerate(self.results):
            result_number = r + 1
            confidence_text = "—" if row.confidence is None else f"{row.confidence:.4f}"
            confidence_sort = (1, 0.0) if row.confidence is None else (0, float(row.confidence))
            cells: list[tuple[str, object]] = [
                (str(result_number), result_number),
                (row.json_path.name, natural_sort_key(row.json_path.name)),
                (str(row.index), row.index),
                (row.label, natural_sort_key(row.label)),
                (row.prediction, natural_sort_key(row.prediction)),
                ("✓" if row.exact else "✕", 1 if row.exact else 0),
                (f"{row.ned:.4f}", float(row.ned)),
                (str(row.edit_distance), int(row.edit_distance)),
                (confidence_text, confidence_sort),
            ]
            for c, (value, sort_value) in enumerate(cells):
                item = SortableTableWidgetItem(value, sort_value)
                item.setData(Qt.ItemDataRole.UserRole, r)
                item.setFlags(item.flags() ^ Qt.ItemFlag.ItemIsEditable)
                if c == 1:
                    item.setToolTip(str(row.json_path))
                if c in (0, 2, 6, 7, 8):
                    item.setTextAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
                elif c == 5:
                    item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(r, c, item)

        self.table.setSortingEnabled(True)
        self.table.resizeRowsToContents()

    def _update_stats(self) -> None:
        n = self.summary.get("count", len(self.results))
        acc = 100.0 * float(self.summary.get("accuracy", 0.0))
        mean_ned = 100.0 * float(self.summary.get("mean_ned", 0.0))
        conf = self.summary.get("mean_confidence")
        conf_text = "—" if conf is None else f"{100.0 * float(conf):.2f}%"
        self.stats_label.setText(
            f"Accuracy: {acc:.2f}%     Mean NED score: {mean_ned:.2f}%     "
            f"Mean confidence: {conf_text}     Samples: {n}"
        )

    def _update_preview(self) -> None:
        selected = self.table.selectedItems()
        if not selected:
            return
        row_number = selected[0].row()
        index_item = self.table.item(row_number, 0)
        if index_item is None:
            return

        result_index = index_item.data(Qt.ItemDataRole.UserRole)
        result = self.results[result_index] if isinstance(result_index, int) and 0 <= result_index < len(self.results) else None
        if result is None:
            crop_index_item = self.table.item(row_number, 2)
            if crop_index_item is None:
                return
            index_value = int(crop_index_item.text())
            result = next((row for row in self.results if row.index == index_value), None)
        if result is None:
            return

        conf_text = "—" if result.confidence is None else f"{result.confidence:.4f}"
        self.details.setText(
            f"JSON: {result.json_path.name}\n"
            f"Crop #{result.index}\n"
            f"Label: {result.label}\n"
            f"Prediction: {result.prediction}\n"
            f"Exact: {'yes' if result.exact else 'no'}\n"
            f"NED: {result.ned:.4f}    ED: {result.edit_distance}\n"
            f"Confidence: {conf_text}\n"
            f"Crop size: {result.crop.width} × {result.crop.height}\n"
            f"Image: {result.image_path.name}"
        )
        self.preview.setPixmap(pil_to_pixmap(result.crop))
        self.preview.setToolTip(f"Label: {result.label}\nPrediction: {result.prediction}")

    def _export_csv(self) -> None:
        if not self.results:
            return

        default_name = "parseq_label_eval_results.csv"
        if self.summary.get("model_name"):
            safe = re.sub(r"[^A-Za-z0-9_.-]+", "_", str(self.summary["model_name"])).strip("_")
            default_name = f"parseq_label_eval_{safe}.csv"

        path, _ = QFileDialog.getSaveFileName(self, "Export CSV", default_name, "CSV files (*.csv);;All files (*)")
        if not path:
            return

        with open(path, "w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=[
                    "json_path",
                    "json_name",
                    "index",
                    "label",
                    "prediction",
                    "exact",
                    "ned_score",
                    "edit_distance",
                    "confidence",
                    "image_path",
                    "model_name",
                    "device",
                ],
            )
            writer.writeheader()
            for row in self.results:
                writer.writerow(
                    {
                        "json_path": str(row.json_path),
                        "json_name": row.json_path.name,
                        "index": row.index,
                        "label": row.label,
                        "prediction": row.prediction,
                        "exact": int(row.exact),
                        "ned_score": f"{row.ned:.8f}",
                        "edit_distance": row.edit_distance,
                        "confidence": "" if row.confidence is None else f"{row.confidence:.8f}",
                        "image_path": str(row.image_path),
                        "model_name": self.summary.get("model_name", ""),
                        "device": self.summary.get("device", ""),
                    }
                )

        QMessageBox.information(self, APP_TITLE, f"Exported:\n{path}")


def main() -> int:
    app = QApplication(sys.argv)
    win = MainWindow()

    if len(sys.argv) > 1:
        first = Path(sys.argv[1]).expanduser()
        if first.exists() and (first.is_dir() or first.suffix.lower() == ".json"):
            win.json_edit.setText(str(first.resolve()))

    win.show()
    return app.exec()


if __name__ == "__main__":
    raise SystemExit(main())
